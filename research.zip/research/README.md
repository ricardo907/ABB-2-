# 机械臂：现有视频的算法改进实验（探索版）

后续的**可变关节数完整算法原型**见 `general_algorithm/README.md`。它增加时间偏移情景、帧间运动模型、逐关节可观测度、拒答、URDF 串联关节适配和多视频专家库；现有真实视频尚未证明优于本页的简单基线，也未证明跨机器人泛化。

本目录只使用现有素材：`Exp001` 和 `Exp002` 的原始视频与 Excel 角度日志，以及桌面 `机械臂` 文件夹中的 9 段无标签视频。原始文件未修改。**当前视频和日志缺少独立同步标记，下面所有角度误差都是基于暂定配对标签的开发指标，不能作为真实估角精度或论文最终结果。**

## 已实现的方法

1. 从两段视频各自的无标签帧求中值背景；用 ORB 特征和 RANSAC 把 Exp002 画面配准到 Exp001 坐标。实测 460 个合格匹配、352 个内点，尺度约 1.298。
2. 在共同 ROI `(20, 30, 600, 560)` 提取 32×32 灰度特征；在训练视频拟合标准化器，输入标准化值限幅到 ±5。
3. 用 `Ridge(alpha=100)` 回归六轴角；输出按训练视频每轴角度范围裁剪，防止线性模型给出数弧度到十余弧度的失控外推。裁剪也意味着模型**无法**估出训练角度范围以外的真实值。

配准用到目标视频的完整无标签帧，因此这是**离线、转导式**方法，要求两段视频有可匹配的静态场景。它不是可直接部署到任意机位的实时模型。推理脚本在配准内点不足时会拒绝输出。

## 两段视频的开发对照

同一特征与回归配置、同一暂定标签，在两方向分别训练和评估；两段视频都用于比较与选参，**没有未触碰的测试集**。

| 训练 → 评估 | 训练均值基线 MAE | 不配准 MAE | 配准后 MAE |
| --- | ---: | ---: | ---: |
| Exp001 → Exp002 | 0.488 rad | 0.538 rad | **0.423 rad** |
| Exp002 → Exp001 | 0.415 rad | 0.497 rad | **0.372 rad** |

两方向平均为：训练均值 0.451、未配准 0.518、配准后 0.397 rad（约 22.8°）。这里同时使用了输入限幅和输出裁剪；不能把相对最早无保护模型的全部改善归因于背景配准。完整逐轴结果和所有候选见 `comparison_results.json`。在 Exp001→Exp002 方向，Exp002 六轴中有多轴大量角度超出 Exp001 训练范围（第 3/5 轴约 91%/90%），因此训练范围裁剪也设置了明显的性能上限。

作为失败对照，原简版 CNN 在 Exp001 时间尾段验证的 MAE 为 0.307 rad，冻结 ResNet18 和未经输入限制的灰度岭回归在跨视频时分别出现 3.67 和 4.90 rad 的错误。加入视角增强后微调的 ResNet18 在 Exp002 上为 0.482 rad，接近训练均值基线 0.488 rad。这些数字仍受下述同步问题影响，相关 JSON 保存在本目录。

## 标签同步审计

目前的 CSV 把第一帧直接配到 Excel 的 0 秒；附件没有相机触发信号或共同时间戳。Exp001 视频约 8.417 秒、日志 9.880 秒；Exp002 视频约 9.083 秒、日志 9.536 秒。Exp002 第 198–217 帧中机械臂画面近乎静止，但暂定标签第 1 轴变化约 −0.972 rad、第 6 轴变化约 −0.725 rad，六轴总变化量约 1.230 rad。

图像运动量与编码器运动量的相关峰提示 Exp002 可能有约 `+1.333 s` 的日志偏移，Exp001 约 `+1.0 s`，但这**不是已验证的同步校准**。`offset_sensitivity.py` 只做固定偏移的敏感性分析，Exp002 保留日志覆盖的第 0–196 帧；在该假设下，Exp001→Exp002 的模型/均值为 0.416/0.506 rad，反向为 0.392/0.437 rad。结果并未证明偏移值准确。正式评估前必须由原始采集记录或新的同步事件确认配对；当前 Exp002 末段不能用于精度结论。

## 9 段无标签视频

9 段共 10,658 帧、约 355 秒，画面与 Exp001/Exp002 的木板场景有明显机位、背景与遮挡差别。冻结 ResNet18 特征的最近邻余弦距离：Exp001 内部中位 0.0082、Exp002 对 Exp001 为 0.0647、9 段分别为 0.1978–0.2275。该距离只提示外观分布变化，**不是角度误差**。9 段没有同步六轴角度，不能计算 MAE。

![现有视频抽帧对照](sample_contact_sheet.jpg)

## 复现

在 `ABB_Cup_2` 目录运行：

```powershell
python -m pip install -r research/requirements.txt
python research/audit_sync.py
python research/lag_scan.py
python research/compare_two_videos.py
python research/offset_sensitivity.py
python research/predict_registered.py --train Exp001 --target Exp002
python research/audit_unlabeled_videos.py
```

`predict_registered.py` 输出逐帧预测、每轴裁剪标记和配准元数据，文件名带 `provisional`；这些数值不能用于控制机械臂。无标签视频审计脚本读取用户桌面 `机械臂` 文件夹，需要本地缓存的 ImageNet ResNet18 权重。

下一步要达到 Transactions 论文所需的可验证证据，需要先建立真实相机/编码器同步、记录机械臂型号和运动学参数，再采集独立轨迹与不同机位的带真值视频；随后固定算法，与现有视觉估角方法按完整轨迹和机位划分比较逐轴 MAE、P95、末端运动学误差和失败率。[RoboPose](https://openaccess.thecvf.com/content/CVPR2021/html/Labbe_Single-View_Robot_Pose_and_Joint_Angle_Estimation_via_Render__CVPR_2021_paper.html)、[六轴 UR10 多视角方法](https://pmc.ncbi.nlm.nih.gov/articles/PMC10781322/)和 [RoboPEPP](https://openaccess.thecvf.com/content/CVPR2025/html/Goswami_RoboPEPP_Vision-Based_Robot_Pose_and_Joint_Angle_Estimation_through_Embedding_CVPR_2025_paper.html) 已研究视觉估角相关问题；当前背景配准加岭回归应视为基线，而非已证明的新方法。[IEEE T-RO 作者指南](https://www.ieee-ras.org/publications/t-ro/t-ro-information-for-authors/)要求原创且推动现有水平的结果。当前原型是算法改进的起点，不构成已达到投稿标准的证明。
