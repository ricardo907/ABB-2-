"""Synthetic pass/fail checks for the capture-manifest validator."""

from __future__ import annotations

import csv
import json
import tempfile
from pathlib import Path

from validate_dataset import validate_manifest


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def session(base: Path, robot_id: str, session_id: str) -> dict:
    folder = base / session_id
    folder.mkdir()
    (folder / "video.mp4").write_bytes(f"synthetic video {session_id}".encode("utf-8"))
    start = 10_000_000_000 + 1_000_000_000 * sum(map(ord, session_id))
    step = 10_000_000
    frame_rows = [{"frame_index": index, "camera_time_ns": start + step * index,
                   "trigger_id": index} for index in range(101)]
    encoder_rows = [{"controller_time_ns": start - 1_000_000 + 5_000_000 * index,
                     "joint_1": index * 0.001, "joint_2": index * 0.002}
                    for index in range(205)]
    sync_rows = [{"event_id": index, "camera_time_ns": start + step * index,
                  "controller_time_ns": start - 1_000_000 + step * index}
                 for index in (0, 50, 100)]
    write_csv(folder / "frames.csv", ["frame_index", "camera_time_ns", "trigger_id"], frame_rows)
    write_csv(folder / "encoder.csv", ["controller_time_ns", "joint_1", "joint_2"], encoder_rows)
    write_csv(folder / "sync.csv", ["event_id", "camera_time_ns", "controller_time_ns"], sync_rows)
    return {
        "session_id": session_id, "robot_id": robot_id,
        "scene_id": "scene_1", "camera_id": "camera_1",
        "trajectory_id": f"trajectory_{session_id}", "fps": 100,
        "video_path": f"{session_id}/video.mp4",
        "frame_timestamps_path": f"{session_id}/frames.csv",
        "encoder_path": f"{session_id}/encoder.csv",
        "sync_events_path": f"{session_id}/sync.csv",
        "joint_columns": ["joint_1", "joint_2"],
        "sync_status": "hardware_trigger",
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        base = Path(temporary)
        first = session(base, "arm_a", "train_a")
        second = session(base, "arm_b", "test_b")
        manifest = {
            "protocol_version": "1.0",
            "robots": [
                {"robot_id": "arm_a", "joint_names": ["joint_1", "joint_2"],
                 "joint_types": ["revolute", "revolute"]},
                {"robot_id": "arm_b", "joint_names": ["joint_1", "joint_2"],
                 "joint_types": ["revolute", "prismatic"]},
            ],
            "sessions": [first, second],
            "evaluation_folds": [{
                "fold_id": "holdout_b", "mode": "zero_shot",
                "holdout_robot_ids": ["arm_b"],
                "pretrain_session_ids": ["train_a"],
                "adaptation_session_ids": [],
                "validation_session_ids": [],
                "test_session_ids": ["test_b"],
            }],
        }
        path = base / "manifest.json"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        report = validate_manifest(path)
        assert report["valid"], report
        assert report["sessions"][0]["stats"]["sync_residual_ms_p95"] < 1e-9
        manifest["evaluation_folds"][0]["pretrain_session_ids"].append("test_b")
        path.write_text(json.dumps(manifest), encoding="utf-8")
        report = validate_manifest(path)
        assert not report["valid"]
        assert any("leaks" in error for error in report["folds"][0]["errors"])
        manifest["evaluation_folds"][0]["pretrain_session_ids"].remove("test_b")
        path.write_text(json.dumps(manifest), encoding="utf-8")
        bad_sync = base / "test_b" / "sync.csv"
        rows = list(csv.DictReader(bad_sync.open(encoding="utf-8", newline="")))
        rows[1]["camera_time_ns"] = str(int(rows[1]["camera_time_ns"]) + 10_000_000)
        write_csv(bad_sync, ["event_id", "camera_time_ns", "controller_time_ns"], rows)
        report = validate_manifest(path)
        assert not report["valid"]
        assert any("sync p95 residual" in error for error in report["sessions"][1]["errors"])
        print("capture manifest selfcheck passed: valid capture, leakage, bad sync")


if __name__ == "__main__":
    main()
