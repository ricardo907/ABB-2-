# 跨机械臂视频估角：采集与测试协议草案

这份协议服务于可复现的论文实验。它不是 IEEE T-RO 的官方数据集最低数量或精度门槛，也不能保证录用。现有 Exp001/Exp002 的相机与编码器零点没有硬件证据；桌面另 9 段视频没有关节真值，不能支撑跨机械臂结论。软件已有可变关节数接口，但当前真实跨视频安全输出覆盖率为 0%。

## 先界定实验主张

1. **每台机器人重新标定的通用算法**：新机器人提供少量预先限定的标定轨迹、编码器和 URDF，再在完全不同轨迹与场景上测试。对应 `few_shot` fold。当前算法最接近这一主张。
2. **未见机器人零样本**：新机器人的任何图像与编码器均不用于训练、调参、背景模板或专家库。对应 `zero_shot` fold。当前算法没有这种能力，不能以少量标定结果代替零样本结果。

论文应分别给出这两个设定；若只做第一项，标题、摘要和结论应明确标定需求。“所有机械臂、所有关节和所有画面都能精确恢复”在遮挡、轴对称和相同图像对应不同关节态时无法成立，应报告逐关节拒答率。

## 采集设计

- **机器人**：优先覆盖不同制造商与结构，至少包含不同关节数（例如 3/4/6/7）、不同关节类型（若宣称支持直线关节）、不同连杆外观/长度。台数和轨迹数是研究设计，不能冒充 T-RO 官方门槛。每台机器人的实体 ID、URDF、关节顺序、关节类型、限位、控制器版本和相机标定独立记录。
- **轨迹**：为每台机器人分别采静态定位、单关节激励、多关节耦合、速度变化、方向反转、遮挡及接近限位；训练与测试使用不同执行轨迹，避免同一程序重复执行造成近似帧泄漏。记录目标轨迹 ID 和实际执行 ID。
- **场景**：每台机器人预设多个机位、背景、照度、曝光、载荷和遮挡等级。单独留出相机/场景测试。强外观变化下允许拒答，但必须报告覆盖率与有效预测误差。
- **同步**：相机时间戳必须是曝光时间（最好曝光中点），编码器为控制器采样时刻。两路均保存纳秒时间戳与同步事件 ID。至少在开始、中段、结束捕获共同触发脉冲，用脉冲拟合相机→控制器仿射时钟映射，公开残差和漂移。推荐记录每帧曝光、滚动快门读出、丢帧 ID 与控制器采样频率。仅凭画面运动与关节速度相关性估偏移，不可标为硬件同步。
- **时间误差预算**：阈值应由测试速度与目标角度误差推导，例如 `允许时间误差 ≤ 目标角误差 / 关节角速度上界`。本校验器默认同步拟合 p95 ≤ 2 ms、最近编码器采样 p95 ≤ 10 ms，仅为可调示例阈值，不是期刊要求；快速轨迹可能需要更严格设置。
- **不可观测真值**：编码器可提供关节角真值，但不是末端空间位姿的独立真值。若声称末端定位精度，应另用标定的外部测量或验证过的几何模型；URDF FK 与同一编码器的比较只能衡量角度误差映射后的几何差异。

## 数据文件格式

每段录制有 4 个原始文件，全部不依赖算法输出：

| 文件 | 必需列/内容 | 约定 |
| --- | --- | --- |
| `video.mp4` | 原始视频 | 不重复编码后覆盖；保存 SHA-256 |
| `frame_timestamps.csv` | `frame_index,camera_time_ns,trigger_id` | 每个实际保存的帧一行；`camera_time_ns` 为曝光时刻 |
| `encoder.csv` | `controller_time_ns` 加逐关节列 | 角度 rad、移动关节 m；按机器人 `joint_names` 显式映射 |
| `sync_events.csv` | `event_id,camera_time_ns,controller_time_ns` | 同一个物理脉冲在两时钟上的时刻；至少 3 次且覆盖录制 |

所有时间戳都是整数纳秒；允许不同时间原点，由同步脉冲估仿射映射。`trigger_id` 应连续；断号说明丢帧或触发缺失。每次录制独立目录，不要覆盖原始文件。另保存相机内参、外参、曝光模式、URDF、机械臂状态、采集程序版本和原始文件哈希。

`manifest.json` 示例（路径相对 manifest 所在目录）：

```json
{
  "protocol_version": "1.0",
  "robots": [
    {"robot_id": "arm_a", "joint_names": ["j1", "j2"], "joint_types": ["revolute", "prismatic"], "urdf_path": "robots/arm_a.urdf"},
    {"robot_id": "arm_b", "joint_names": ["j1", "j2"], "joint_types": ["revolute", "revolute"], "urdf_path": "robots/arm_b.urdf"}
  ],
  "sessions": [
    {
      "session_id": "a_train_01", "robot_id": "arm_a", "scene_id": "lab_light_1",
      "camera_id": "cam_front", "trajectory_id": "motion_a_01", "fps": 30,
      "video_path": "sessions/a_train_01/video.mp4",
      "frames_path": "sessions/a_train_01/images",
      "frame_timestamps_path": "sessions/a_train_01/frame_timestamps.csv",
      "encoder_path": "sessions/a_train_01/encoder.csv",
      "sync_events_path": "sessions/a_train_01/sync_events.csv",
      "sync_status": "hardware_trigger", "joint_columns": ["axis_1", "axis_2"]
    },
    {
      "session_id": "b_test_01", "robot_id": "arm_b", "scene_id": "lab_light_2",
      "camera_id": "cam_side", "trajectory_id": "motion_b_01", "fps": 30,
      "video_path": "sessions/b_test_01/video.mp4",
      "frames_path": "sessions/b_test_01/images",
      "frame_timestamps_path": "sessions/b_test_01/frame_timestamps.csv",
      "encoder_path": "sessions/b_test_01/encoder.csv",
      "sync_events_path": "sessions/b_test_01/sync_events.csv",
      "sync_status": "hardware_trigger", "joint_columns": ["axis_1", "axis_2"]
    }
  ],
  "evaluation_folds": [
    {
      "fold_id": "holdout_arm_b", "mode": "zero_shot",
      "holdout_robot_ids": ["arm_b"],
      "pretrain_session_ids": ["a_train_01"],
      "adaptation_session_ids": [], "validation_session_ids": [],
      "test_session_ids": ["b_test_01"]
    }
  ]
}
```

同一 session 可以在不同 fold 中担任不同角色，所以 `split` 只存在于 fold 的 4 个 session ID 列表中。`few_shot` 的 `adaptation_session_ids` 必须提前指定、全属留出的机器人，且与测试轨迹不同；样本时长/帧数也要在论文实验设计中预先固定。

## 运行采集完整性校验

```powershell
python research/general_algorithm/protocol/validate_dataset.py path/to/manifest.json `
  --max-sync-residual-ms 2 --max-label-gap-ms 10 `
  --output path/to/validation_report.json
python research/general_algorithm/protocol/selfcheck.py
```

校验器检查：机器人/关节映射、文件存在与可选 SHA-256、帧/触发/编码器时间单调性、丢触发、同步事件拟合残差和跨度、帧时间映射后的编码器覆盖、采样间隔、跨 fold 机器人与轨迹泄漏。同一类原始文件即使复制到不同路径、改用不同 `trajectory_id`，内容 SHA-256 相同也会被判为泄漏。旧 manifest 可继续做采集格式校验；严格 fold 评分要求 test session 具有 `frames_path`。`--strict-sync` 使同步事件未覆盖第一帧或最后一帧成为错误；严格评分始终启用此规则。**校验器不解码视频，不能确认脉冲来自正确的物理线，不能证明 URDF 或相机标定准确，也不测算法精度。**

预测 CSV 必须保留 `pipeline.py infer` 输出的 `frame_index,image,pred__...,safe__...,reliable__...`。生成正式预测时传入 `--capture-manifest path/to/manifest.json --session-id b_test_01`，并使 `--frames` 与 manifest 的 `frames_path` 解析后为同一目录。推理完成会在 CSV 旁写入同名 `.provenance.json`，例如 `predictions.csv` 对应 `predictions.provenance.json`。严格 fold 评估必须有此文件，并从原始编码器和同步事件重新生成每帧真值：

```powershell
python research/general_algorithm/protocol/evaluate_fold.py `
  --manifest path/to/manifest.json --fold-id holdout_arm_b `
  --prediction b_test_01=path/to/predictions.csv `
  --output path/to/fold_report.json
python research/general_algorithm/protocol/selfcheck_evaluator.py
```

每个 test session 都要提供一条 `--prediction`，不可添加训练/标定 session。评分前重新计算 sidecar 的 `session_id`、`robot_id`、帧数、图片名和图片内容、原视频、帧时间戳、编码器、同步事件、模型文件、预测 CSV 的哈希。即使两个 session 使用相同的 `frame_0000.jpg` 命名和相同帧数，交换预测也会失败。

哈希编码规范：`image_names_sha256` 是按 CSV 原顺序读取 `image` 字符串列表，对 `json.dumps(names, ensure_ascii=False, separators=(',', ':')).encode('utf-8')` 取 SHA-256；`frames_sha256` 先按同一顺序为每张图片构造 `{"image": name, "sha256": SHA256(图片原始字节)}`，再对这个对象列表作相同 canonical JSON 编码并取 SHA-256。`session_sha256` 对完整 session 对象使用相同编码并加 `sort_keys=True`，锁定轨迹、场景等元数据。其他文件哈希均对原始字节取 SHA-256。sidecar 的 `schema` 固定为 `robot-angle-prediction-provenance-v1`，`model_path` 保存绝对路径，校验时文件必须存在且字节不变。该绑定用于检查实验文件的一致性，不能单独证明采集过程或训练集没有被隐瞒。

严格评分还要求同步事件覆盖所有曝光；每帧按最近编码器采样间隔以及 `|dq/dt| × (同步事件最大残差 + 最近采样间隔)` 筛选标签。默认上限分别为 10 ms、转动关节 0.02 rad、直线关节 0.005 m，可用 `--max-label-gap-ms`、`--max-timing-error-rad`、`--max-timing-error-m` 按实验设计预先调整。这是保守的筛选代理量，不是经过标定的置信区间。报告给出剔除帧数和原因，误差与可靠覆盖率仅在通过时间质量筛选的帧上计算。前端拒答时 `pred__` 和 `safe__` 可为空，但相应 `reliable__` 必须为 `False`；原始角度误差仅在有数值的单元格上统计，报告同时给出逐关节原始覆盖率与整帧覆盖率。汇总先按 session，再按独立 `(robot_id, trajectory_id)`，最后对机器人等权平均；不能用相邻帧数充当独立样本量。若没有真实 URDF 则不报告末端 FK 误差。仍需独立核查触发接线与曝光时间定义。

## 投稿实验报告最小结构

1. 固定数据集版本、机器人留出 fold、标定预算和所有超参数。测试标签只在冻结模型与方法后读取。
2. 同时运行原始基线、最接近的公开方法和各关键模块消融；报告每台机器人及每个场景，而不仅总体平均值。
3. 分别报告转动关节角度误差（连续关节用周期距离）、直线关节位置误差、每关节 P95、末端位置/姿态误差、可靠输出覆盖率及覆盖条件下的误差。混合 rad/m 不能直接合成一个 MAE。
4. 统计区间按独立机器人和轨迹重采样，不能把同一视频的相邻帧当作独立样本。报告失败案例、运行时间、显存/内存、相机标定开销及数据采集开销。
5. 明确离线/在线设置。现有中值背景使用完整测试视频，是离线转导步骤；若声称在线，应改为仅用过去帧并重新测试。

