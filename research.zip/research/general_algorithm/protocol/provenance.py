"""Canonical hashes linking a fold prediction to its capture and model files."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Sequence


SCHEMA = "robot-angle-prediction-provenance-v1"
RAW_FIELDS = (
    ("video_path", "video_sha256"),
    ("frame_timestamps_path", "frame_timestamps_sha256"),
    ("encoder_path", "encoder_sha256"),
    ("sync_events_path", "sync_events_sha256"),
)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_sha256(value: object) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _check_names(names: Sequence[str]) -> list[str]:
    values = list(names)
    if not values or any(not isinstance(name, str) or not name or
                         Path(name).name != name or name in (".", "..") for name in values):
        raise ValueError("Prediction image names must be nonempty basenames")
    if len(values) != len(set(values)):
        raise ValueError("Prediction image names must be unique")
    return values


def hash_image_names(names: Sequence[str]) -> str:
    return _canonical_sha256(_check_names(names))


def hash_frames(frame_dir: str | Path, names: Sequence[str]) -> str:
    folder = Path(frame_dir)
    records = []
    for name in _check_names(names):
        image = folder / name
        if not image.is_file():
            raise ValueError(f"Prediction image does not exist: {image}")
        records.append({"image": name, "sha256": sha256_file(image)})
    return _canonical_sha256(records)


def provenance_path(prediction_path: str | Path) -> Path:
    return Path(prediction_path).with_suffix(".provenance.json")


def _resolve(base: Path, value: str) -> Path:
    path = Path(value)
    return (path if path.is_absolute() else base / path).resolve()


def build_provenance(session: dict, manifest_dir: str | Path, frame_dir: str | Path,
                     model_path: str | Path, prediction_path: str | Path,
                     names: Sequence[str]) -> dict:
    """Build the sidecar after the prediction CSV has been completely written."""
    base = Path(manifest_dir)
    if not session.get("frames_path"):
        raise ValueError("Strict prediction provenance requires session.frames_path")
    expected_frames = _resolve(base, session["frames_path"])
    actual_frames = Path(frame_dir).resolve()
    if expected_frames != actual_frames:
        raise ValueError(f"--frames differs from manifest frames_path: {actual_frames} != {expected_frames}")
    if not actual_frames.is_dir():
        raise ValueError(f"frames_path is not a directory: {actual_frames}")
    names = _check_names(names)
    result = {
        "schema": SCHEMA,
        "session_id": session["session_id"],
        "robot_id": session["robot_id"],
        "session_sha256": _canonical_sha256(session),
        "frame_count": len(names),
        "image_names_sha256": hash_image_names(names),
        "frames_sha256": hash_frames(actual_frames, names),
        "model_path": str(Path(model_path).resolve()),
        "model_sha256": sha256_file(model_path),
        "prediction_csv_sha256": sha256_file(prediction_path),
    }
    for source_field, hash_field in RAW_FIELDS:
        result[hash_field] = sha256_file(_resolve(base, session[source_field]))
    return result


def verify_provenance(session: dict, manifest_dir: str | Path,
                      prediction_path: str | Path, names: Sequence[str]) -> dict:
    """Recompute every hash; reject swapped or edited captures, models and CSVs."""
    sidecar = provenance_path(prediction_path)
    if not sidecar.is_file():
        raise ValueError(f"Prediction provenance sidecar is missing: {sidecar}")
    try:
        provided = json.loads(sidecar.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        raise ValueError(f"Cannot read prediction provenance: {sidecar}") from exc
    if not isinstance(provided, dict) or provided.get("schema") != SCHEMA:
        raise ValueError(f"Unsupported prediction provenance schema in {sidecar}")
    if not isinstance(provided.get("model_path"), str) or not provided["model_path"]:
        raise ValueError("Prediction provenance is missing model_path")
    model = Path(provided["model_path"])
    if not model.is_absolute():
        raise ValueError("Prediction provenance model_path must be absolute")
    expected = build_provenance(
        session, manifest_dir, _resolve(Path(manifest_dir), session.get("frames_path", "")),
        model, prediction_path, names,
    )
    for field, value in expected.items():
        if provided.get(field) != value:
            raise ValueError(f"Prediction provenance {field} mismatch for {session['session_id']}")
    return provided
