"""Synthetic fold scoring and negative provenance/synchronization checks."""

import csv
import json
from pathlib import Path
import tempfile

import numpy as np
import pandas as pd

from evaluate_fold import _timing_quality, evaluate_fold
from provenance import build_provenance, provenance_path, sha256_file
from selfcheck import session, write_csv
from validate_dataset import validate_manifest


def _prediction(base: Path, capture: dict, model: Path) -> Path:
    sid = capture["session_id"]
    frame_dir = base / sid / "images"
    frame_dir.mkdir()
    i = np.arange(101)
    names = [f"frame_{index:04d}.jpg" for index in i]
    for name in names:
        (frame_dir / name).write_bytes(f"{sid}:{name}".encode("utf-8"))
    capture["frames_path"] = f"{sid}/images"
    reliable = i % 2 == 0
    predicted = base / f"{sid}.csv"
    pd.DataFrame({
        "frame_index": i,
        "image": names,
        "pred__joint_1": 2 * i * 0.001 + 0.01,
        "pred__joint_2": 2 * i * 0.002 + 0.02,
        "safe__joint_1": np.where(reliable, 2 * i * 0.001 + 0.01, np.nan),
        "safe__joint_2": 2 * i * 0.002 + 0.02,
        "reliable__joint_1": reliable,
        "reliable__joint_2": True,
    }).to_csv(predicted, index=False)
    provenance_path(predicted).write_text(json.dumps(build_provenance(
        capture, base, frame_dir, model, predicted, names
    )), encoding="utf-8")
    return predicted


def _reject(action, expected: str) -> None:
    try:
        action()
    except ValueError as error:
        assert expected in str(error), error
    else:
        raise AssertionError(f"Expected rejection containing {expected!r}")


with tempfile.TemporaryDirectory() as folder:
    base = Path(folder)
    train = session(base, "arm_a", "train_a")
    test_b = session(base, "arm_b", "test_b")
    test_c = session(base, "arm_b", "test_c")
    model = base / "model.joblib"
    model.write_bytes(b"frozen synthetic checkpoint")
    pred_b = _prediction(base, test_b, model)
    pred_c = _prediction(base, test_c, model)
    manifest = {
        "protocol_version": "1.0",
        "robots": [
            {"robot_id": "arm_a", "joint_names": ["joint_1", "joint_2"],
             "joint_types": ["revolute", "revolute"]},
            {"robot_id": "arm_b", "joint_names": ["joint_1", "joint_2"],
             "joint_types": ["revolute", "prismatic"]},
        ],
        "sessions": [train, test_b, test_c],
        "evaluation_folds": [{
            "fold_id": "holdout_b", "mode": "zero_shot",
            "holdout_robot_ids": ["arm_b"],
            "pretrain_session_ids": ["train_a"],
            "adaptation_session_ids": [],
            "validation_session_ids": [],
            "test_session_ids": ["test_b", "test_c"],
        }],
    }
    manifest_path = base / "manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    predictions = {"test_b": pred_b, "test_c": pred_c}
    report = evaluate_fold(manifest_path, "holdout_b", predictions)
    item = report["sessions"][0]
    assert abs(item["raw_mae_rad"] - 0.01) < 1e-10, item
    assert abs(item["raw_mae_m"] - 0.02) < 1e-10, item
    assert item["reliable_fraction_by_joint"] == [51 / 101, 1.0], item
    assert report["independent_trajectory_count"] == 2, report
    assert report["independent_robot_count"] == 1, report
    original_pred_b = pred_b.read_bytes()
    original_sidecar_b = provenance_path(pred_b).read_bytes()
    table_b = pd.read_csv(pred_b)
    table_b.loc[0, ["pred__joint_1", "pred__joint_2",
                    "safe__joint_1", "safe__joint_2"]] = np.nan
    table_b.loc[0, ["reliable__joint_1", "reliable__joint_2"]] = False
    table_b.to_csv(pred_b, index=False)
    sidecar_b = json.loads(original_sidecar_b)
    sidecar_b["prediction_csv_sha256"] = sha256_file(pred_b)
    provenance_path(pred_b).write_text(json.dumps(sidecar_b), encoding="utf-8")
    refused = evaluate_fold(manifest_path, "holdout_b", predictions)["sessions"][0]
    assert refused["raw_complete_frames"] == 100, refused
    assert refused["raw_complete_frame_fraction"] == 100 / 101, refused
    assert abs(refused["raw_mae_rad"] - 0.01) < 1e-10, refused
    table_b.loc[0, "reliable__joint_1"] = True
    table_b.to_csv(pred_b, index=False)
    sidecar_b["prediction_csv_sha256"] = sha256_file(pred_b)
    provenance_path(pred_b).write_text(json.dumps(sidecar_b), encoding="utf-8")
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", predictions),
            "Raw predictions must be finite wherever reliable__ is true")
    pred_b.write_bytes(original_pred_b)
    provenance_path(pred_b).write_bytes(original_sidecar_b)
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", {"train_a": pred_b}),
            "exactly match test")
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b",
                                  {"test_b": pred_c, "test_c": pred_b}),
            "provenance session_id mismatch")
    test_c["trajectory_id"] = "renamed_after_prediction"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", predictions),
            "provenance session_sha256 mismatch")
    test_c["trajectory_id"] = "trajectory_test_c"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    sidecar_c = provenance_path(pred_c)
    original_sidecar = sidecar_c.read_bytes()
    sidecar_c.unlink()
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", predictions),
            "sidecar is missing")
    sidecar_c.write_bytes(original_sidecar)
    original_model = model.read_bytes()
    model.write_bytes(b"changed checkpoint")
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", predictions),
            "provenance model_sha256 mismatch")
    model.write_bytes(original_model)

    # Identical raw bytes in different paths and trajectory IDs still leak.
    video_c = base / test_c["video_path"]
    original_video_c = video_c.read_bytes()
    video_c.write_bytes((base / test_b["video_path"]).read_bytes())
    validation = validate_manifest(manifest_path)
    assert not validation["valid"]
    assert any("duplicates video_path bytes" in issue for issue in validation["errors"])
    video_c.write_bytes(original_video_c)

    # Full scoring rejects clock extrapolation at the first exposure.
    sync_c = base / test_c["sync_events_path"]
    original_sync_c = sync_c.read_bytes()
    with sync_c.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    rows[0]["camera_time_ns"] = str(int(rows[0]["camera_time_ns"]) + 10_000_000)
    rows[0]["controller_time_ns"] = str(int(rows[0]["controller_time_ns"]) + 10_000_000)
    write_csv(sync_c, ["event_id", "camera_time_ns", "controller_time_ns"], rows)
    _reject(lambda: evaluate_fold(manifest_path, "holdout_b", predictions),
            "failed validation")
    sync_c.write_bytes(original_sync_c)

    valid, timing = _timing_quality(
        np.array([0.005, 0.015]), np.array([0.0, 0.01, 0.02]),
        np.array([[0.0], [1.0], [1.0]]), ["revolute"],
        residual_ms_max=1.0, max_label_gap_ms=10.0,
        max_timing_error_rad=0.02, max_timing_error_m=0.005,
    )
    assert valid.tolist() == [False, True], timing
    assert timing["frames_excluded_motion_timing_bound"] == 1, timing
    valid, timing = _timing_quality(
        np.array([0.005, 0.015]), np.array([0.0, 0.01, 0.02]),
        np.array([[0.0], [1.0], [1.0]]), ["revolute"],
        residual_ms_max=1.0, max_label_gap_ms=4.0,
        max_timing_error_rad=0.02, max_timing_error_m=0.005,
    )
    assert valid.tolist() == [False, False], timing
print("hardware fold evaluation, provenance, leakage and timing guards: PASS")
