"""Score predeclared test sessions against hardware-timestamped encoder logs.

This evaluator derives labels from each session's timestamped raw files. It
checks the manifest's robot/trajectory holdout rules before reading predictions.
It cannot certify physical trigger wiring or the accuracy of a URDF.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

from validate_dataset import validate_manifest
from provenance import verify_provenance


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from spec.urdf_chain import load_serial_chain  # noqa: E402
from sync.hardware_sync import aligned_frame_times, fit_clock_events, read_hardware_encoder  # noqa: E402


def _path(base: Path, value: str) -> Path:
    target = Path(value)
    return target if target.is_absolute() else base / target


def _bool_column(table: pd.DataFrame, name: str) -> np.ndarray:
    if name not in table:
        raise ValueError(f"Missing prediction column {name}")
    values = table[name].astype(str).str.strip().str.lower()
    if not values.isin(("true", "false", "1", "0")).all():
        raise ValueError(f"{name} must contain true/false values")
    return values.isin(("true", "1")).to_numpy()


def _errors(actual: np.ndarray, predicted: np.ndarray, joint_types: list[str]) -> np.ndarray:
    error = np.abs(actual - predicted)
    for joint, kind in enumerate(joint_types):
        if kind == "continuous":
            delta = actual[:, joint] - predicted[:, joint]
            error[:, joint] = np.abs(np.arctan2(np.sin(delta), np.cos(delta)))
    return error


def _mean_or_none(value: np.ndarray) -> float | None:
    finite = np.asarray(value)[np.isfinite(value)]
    return float(np.mean(finite)) if finite.size else None


def _timing_quality(mapped: np.ndarray, encoder_times: np.ndarray,
                    encoder_values: np.ndarray, joint_types: list[str],
                    residual_ms_max: float, max_label_gap_ms: float,
                    max_timing_error_rad: float,
                    max_timing_error_m: float) -> tuple[np.ndarray, dict]:
    """Conservatively bound each interpolated label's timing error."""
    right = np.clip(np.searchsorted(encoder_times, mapped, side="left"),
                    1, len(encoder_times) - 1)
    left = right - 1
    nearest_gap_ms = np.minimum(np.abs(mapped - encoder_times[left]),
                                np.abs(mapped - encoder_times[right])) * 1000.0
    intervals = encoder_times[right] - encoder_times[left]
    local_speed = np.abs(encoder_values[right] - encoder_values[left]) / intervals[:, None]
    uncertainty_s = (residual_ms_max + nearest_gap_ms) / 1000.0
    error_bound = local_speed * uncertainty_s[:, None]
    limits = np.array([max_timing_error_m if kind == "prismatic"
                       else max_timing_error_rad for kind in joint_types])
    gap_ok = nearest_gap_ms <= max_label_gap_ms
    motion_ok = np.all(error_bound <= limits[None, :], axis=1)
    valid = gap_ok & motion_ok
    return valid, {
        "frames_total": int(len(mapped)),
        "frames_valid": int(valid.sum()),
        "frames_excluded_encoder_gap": int((~gap_ok).sum()),
        "frames_excluded_motion_timing_bound": int((~motion_ok).sum()),
        "nearest_encoder_gap_ms_max": float(nearest_gap_ms.max()),
        "timing_uncertainty_ms_max": float((uncertainty_s * 1000).max()),
        "timing_error_bound_by_joint_max": error_bound.max(axis=0).tolist(),
        "max_label_gap_ms": max_label_gap_ms,
        "max_timing_error_rad": max_timing_error_rad,
        "max_timing_error_m": max_timing_error_m,
        "bound_note": "Local encoder speed multiplied by max sync-event residual plus nearest-sample time gap; this is a screening proxy, not a calibrated uncertainty interval",
    }


def _score_session(session: dict, robot: dict, prediction_file: Path,
                   manifest_dir: Path, max_sync_residual_ms: float,
                   max_label_gap_ms: float, max_timing_error_rad: float,
                   max_timing_error_m: float) -> dict:
    table = pd.read_csv(prediction_file)
    required = {"frame_index", "image"}
    if not required <= set(table) or table.empty:
        raise ValueError("Prediction CSV needs frame_index,image and at least one row")
    indices = pd.to_numeric(table["frame_index"], errors="raise").to_numpy()
    if not np.array_equal(indices, np.arange(len(table))):
        raise ValueError("Prediction frame_index must be complete and ordered 0..N-1")
    if table["image"].isna().any() or not table["image"].is_unique:
        raise ValueError("Prediction image names must be present and unique")
    image_names = table["image"].tolist()
    provenance = verify_provenance(session, manifest_dir, prediction_file, image_names)
    names = list(robot["joint_names"])
    types = list(robot["joint_types"])
    pred_columns = [f"pred__{name}" for name in names]
    safe_columns = [f"safe__{name}" for name in names]
    reliable_columns = [f"reliable__{name}" for name in names]
    missing = sorted(set(pred_columns + safe_columns + reliable_columns) - set(table))
    if missing:
        raise ValueError(f"Missing prediction columns: {missing}")
    predicted = table[pred_columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    safe = table[safe_columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    reliable = np.column_stack([_bool_column(table, name) for name in reliable_columns])
    if np.isinf(predicted).any():
        raise ValueError("Raw predictions must not contain infinity")
    if np.isnan(predicted)[reliable].any():
        raise ValueError("Raw predictions must be finite wherever reliable__ is true")
    if not np.isfinite(safe[reliable]).all() or not np.isnan(safe[~reliable]).all():
        raise ValueError("safe__ cells must be finite exactly where reliable__ is true")
    encoder_times, encoder_values, controller_origin = read_hardware_encoder(
        _path(manifest_dir, session["encoder_path"]), list(session["joint_columns"])
    )
    for joint, kind in enumerate(types):
        if kind == "continuous":
            encoder_values[:, joint] = np.unwrap(encoder_values[:, joint])
    clock = fit_clock_events(_path(manifest_dir, session["sync_events_path"]))
    frame_csv = _path(manifest_dir, session["frame_timestamps_path"])
    if "fps" in session:
        fps = float(session["fps"])
    else:
        stamps = pd.read_csv(frame_csv, usecols=["camera_time_ns"])["camera_time_ns"].to_numpy(dtype=np.int64)
        fps = 1e9 / float(np.median(np.diff(stamps)))
    mapped, sync_report = aligned_frame_times(
        frame_csv, image_names, encoder_times, controller_origin,
        clock, fps, max_fit_residual_ms=max_sync_residual_ms,
        max_label_gap_ms=max_label_gap_ms,
    )
    if sync_report["extrapolated_frame_edges"]:
        raise ValueError("Sync events do not bracket all frames; strict fold scoring forbids extrapolation")
    valid, timing_report = _timing_quality(
        mapped, encoder_times, encoder_values, types, clock.residual_ms_max,
        max_label_gap_ms, max_timing_error_rad, max_timing_error_m,
    )
    if not valid.any():
        raise ValueError(f"No timing-valid frames in session {session['session_id']}")
    actual = np.column_stack([
        np.interp(mapped, encoder_times, encoder_values[:, joint])
        for joint in range(len(names))
    ])
    valid_predicted = predicted[valid]
    raw_present = np.isfinite(valid_predicted)
    error = _errors(actual[valid], valid_predicted, types)
    valid_reliable = reliable[valid]
    unit = ["m" if kind == "prismatic" else "rad" for kind in types]
    conditional_mae = [
        _mean_or_none(error[valid_reliable[:, joint], joint]) for joint in range(len(names))
    ]
    conditional_p95 = [
        float(np.percentile(error[valid_reliable[:, joint], joint], 95))
        if valid_reliable[:, joint].any() else None for joint in range(len(names))
    ]
    rotational = np.array([kind != "prismatic" for kind in types])
    prismatic = ~rotational
    report = {
        "session_id": session["session_id"],
        "robot_id": session["robot_id"],
        "scene_id": session["scene_id"],
        "camera_id": session["camera_id"],
        "trajectory_id": session["trajectory_id"],
        "prediction_csv": str(prediction_file),
        "prediction_provenance": str(prediction_file.with_suffix(".provenance.json")),
        "model_sha256": provenance["model_sha256"],
        "frames": len(table),
        "evaluated_frames": int(valid.sum()),
        "excluded_frames": int((~valid).sum()),
        "joint_names": names,
        "joint_types": types,
        "joint_units": unit,
        "raw_mae_by_joint": [_mean_or_none(error[:, joint])
                             for joint in range(len(names))],
        "raw_p95_by_joint": [
            float(np.percentile(error[raw_present[:, joint], joint], 95))
            if raw_present[:, joint].any() else None for joint in range(len(names))
        ],
        "raw_coverage_by_joint": raw_present.mean(axis=0).tolist(),
        "raw_complete_frames": int(raw_present.all(axis=1).sum()),
        "raw_complete_frame_fraction": float(raw_present.all(axis=1).mean()),
        "reliable_fraction_by_joint": valid_reliable.mean(axis=0).tolist(),
        "reliable_only_mae_by_joint": conditional_mae,
        "reliable_only_p95_by_joint": conditional_p95,
        "raw_mae_rad": _mean_or_none(error[:, rotational]),
        "raw_mae_m": _mean_or_none(error[:, prismatic]),
        "sync_fit": sync_report,
        "timing_quality": timing_report,
    }
    if robot.get("urdf_path"):
        spec = load_serial_chain(
            _path(manifest_dir, robot["urdf_path"]),
            base_link=robot.get("base_link"), tip_link=robot.get("tip_link"),
            allow_branches=bool(robot.get("allow_branches", False)),
        )
        if list(spec.joint_names) != names:
            raise ValueError(f"Robot {session['robot_id']} URDF order differs from manifest joint_names")
        distances = []
        orientations = []
        complete = valid & np.isfinite(predicted).all(axis=1)
        for truth, estimate in zip(actual[complete], predicted[complete]):
            true_pose = spec.forward_kinematics(truth)
            estimated_pose = spec.forward_kinematics(estimate)
            distances.append(float(np.linalg.norm(true_pose[:3, 3] - estimated_pose[:3, 3])))
            relative = true_pose[:3, :3].T @ estimated_pose[:3, :3]
            orientations.append(float(np.arccos(np.clip((np.trace(relative) - 1) / 2, -1, 1))))
        report["end_effector_fk"] = {
            "evaluated_frames": len(distances),
            "position_mae_m": float(np.mean(distances)) if distances else None,
            "position_p95_m": float(np.percentile(distances, 95)) if distances else None,
            "orientation_mae_rad": float(np.mean(orientations)) if orientations else None,
            "orientation_p95_rad": float(np.percentile(orientations, 95)) if orientations else None,
            "note": "FK is derived from encoder angles and URDF, not an independent end-effector measurement",
        }
    return report


def evaluate_fold(manifest_file: Path, fold_id: str, predictions: dict[str, Path],
                  *, max_sync_residual_ms: float = 2.0,
                  max_label_gap_ms: float = 10.0,
                  max_timing_error_rad: float = 0.02,
                  max_timing_error_m: float = 0.005) -> dict:
    if not np.isfinite(max_timing_error_rad) or max_timing_error_rad <= 0:
        raise ValueError("max_timing_error_rad must be positive and finite")
    if not np.isfinite(max_timing_error_m) or max_timing_error_m <= 0:
        raise ValueError("max_timing_error_m must be positive and finite")
    validation = validate_manifest(
        manifest_file, max_sync_residual_ms=max_sync_residual_ms,
        max_label_gap_ms=max_label_gap_ms, strict_sync=True,
    )
    if not validation["valid"]:
        issues = list(validation["errors"])
        issues.extend(f"{row['session_id']}: {error}" for row in validation["sessions"]
                      for error in row["errors"])
        issues.extend(f"{row['fold_id']}: {error}" for row in validation["folds"]
                      for error in row["errors"])
        raise ValueError("Capture manifest failed validation: " + "; ".join(issues[:5]))
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    folds = [fold for fold in manifest["evaluation_folds"] if fold["fold_id"] == fold_id]
    if len(folds) != 1:
        raise ValueError(f"Exactly one fold must match {fold_id!r}")
    fold = folds[0]
    test_ids = set(fold["test_session_ids"])
    if set(predictions) != test_ids:
        raise ValueError(f"Prediction sessions must exactly match test sessions: {sorted(test_ids)}")
    sessions = {session["session_id"]: session for session in manifest["sessions"]}
    robots = {robot["robot_id"]: robot for robot in manifest["robots"]}
    reports = [
        _score_session(sessions[sid], robots[sessions[sid]["robot_id"]],
                       predictions[sid], manifest_file.parent,
                       max_sync_residual_ms, max_label_gap_ms,
                       max_timing_error_rad, max_timing_error_m)
        for sid in sorted(test_ids)
    ]
    trajectory_reports = []
    for robot_id, trajectory_id in sorted({(row["robot_id"], row["trajectory_id"])
                                           for row in reports}):
        rows = [row for row in reports if row["robot_id"] == robot_id
                and row["trajectory_id"] == trajectory_id]
        trajectory_reports.append({
            "robot_id": robot_id,
            "trajectory_id": trajectory_id,
            "session_count": len(rows),
            "raw_mae_rad_session_macro": _mean_or_none(np.array([
                row["raw_mae_rad"] for row in rows if row["raw_mae_rad"] is not None
            ])),
            "raw_mae_m_session_macro": _mean_or_none(np.array([
                row["raw_mae_m"] for row in rows if row["raw_mae_m"] is not None
            ])),
            "reliable_fraction_session_macro": float(np.mean([
                np.mean(row["reliable_fraction_by_joint"]) for row in rows
            ])),
            "raw_complete_fraction_session_macro": float(np.mean([
                row["raw_complete_frame_fraction"] for row in rows
            ])),
        })
    robot_reports = []
    for robot_id in sorted({row["robot_id"] for row in trajectory_reports}):
        rows = [row for row in trajectory_reports if row["robot_id"] == robot_id]
        robot_reports.append({
            "robot_id": robot_id,
            "test_trajectories": len(rows),
            "raw_mae_rad_trajectory_macro": _mean_or_none(np.array([
                row["raw_mae_rad_session_macro"] for row in rows
                if row["raw_mae_rad_session_macro"] is not None
            ])),
            "raw_mae_m_trajectory_macro": _mean_or_none(np.array([
                row["raw_mae_m_session_macro"] for row in rows
                if row["raw_mae_m_session_macro"] is not None
            ])),
            "reliable_fraction_trajectory_macro": float(np.mean([
                row["reliable_fraction_session_macro"] for row in rows
            ])),
            "raw_complete_fraction_trajectory_macro": float(np.mean([
                row["raw_complete_fraction_session_macro"] for row in rows
            ])),
        })
    return {
        "fold_id": fold_id,
        "mode": fold["mode"],
        "heldout_robot_ids": fold["holdout_robot_ids"],
        "manifest": str(manifest_file),
        "dataset_validation": {"valid": True,
                               "max_sync_residual_ms": max_sync_residual_ms,
                               "max_label_gap_ms": max_label_gap_ms,
                               "strict_sync": True},
        "sessions": reports,
        "trajectories": trajectory_reports,
        "robots": robot_reports,
        "independent_robot_count": len(robot_reports),
        "independent_trajectory_count": len(trajectory_reports),
        "robot_macro_raw_mae_rad": _mean_or_none(np.array([
            row["raw_mae_rad_trajectory_macro"] for row in robot_reports
            if row["raw_mae_rad_trajectory_macro"] is not None
        ])),
        "robot_macro_raw_mae_m": _mean_or_none(np.array([
            row["raw_mae_m_trajectory_macro"] for row in robot_reports
            if row["raw_mae_m_trajectory_macro"] is not None
        ])),
        "robot_macro_reliable_fraction": float(np.mean([
            row["reliable_fraction_trajectory_macro"] for row in robot_reports
        ])),
        "robot_macro_raw_complete_fraction": float(np.mean([
            row["raw_complete_fraction_trajectory_macro"] for row in robot_reports
        ])),
        "aggregation": "session -> (robot_id, trajectory_id) -> robot_id -> equal-weight robot macro; adjacent frames are not independent replicates",
        "warning": "Manifest validation checks file consistency only; physical trigger wiring and labels need independent audit",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--fold-id", required=True)
    parser.add_argument("--prediction", action="append", required=True,
                        help="Repeat SESSION_ID=prediction.csv once for each test session")
    parser.add_argument("--max-sync-residual-ms", type=float, default=2.0)
    parser.add_argument("--max-label-gap-ms", type=float, default=10.0)
    parser.add_argument("--max-timing-error-rad", type=float, default=0.02)
    parser.add_argument("--max-timing-error-m", type=float, default=0.005)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    predictions = {}
    for item in args.prediction:
        if "=" not in item:
            parser.error("--prediction needs SESSION_ID=path")
        session_id, filename = item.split("=", 1)
        if not session_id or not filename or session_id in predictions:
            parser.error("Prediction session ID must be nonempty and unique")
        predictions[session_id] = Path(filename)
    report = evaluate_fold(args.manifest, args.fold_id, predictions,
                           max_sync_residual_ms=args.max_sync_residual_ms,
                           max_label_gap_ms=args.max_label_gap_ms,
                           max_timing_error_rad=args.max_timing_error_rad,
                           max_timing_error_m=args.max_timing_error_m)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), "fold_id": args.fold_id,
                      "test_sessions": len(report["sessions"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
