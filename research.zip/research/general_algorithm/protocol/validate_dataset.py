"""Validate a capture manifest for robot vision/encoder research.

This checks file structure, timestamp integrity, clock-pulse alignment, and
declared robot-held-out folds. It cannot certify that a trigger was wired
correctly, that the URDF is physically accurate, or that an algorithm works.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any


REQUIRED_SESSION = (
    "session_id", "robot_id", "scene_id", "camera_id", "trajectory_id",
    "video_path", "frame_timestamps_path", "encoder_path",
    "sync_events_path", "joint_columns", "sync_status",
)
REQUIRED_FOLD = (
    "fold_id", "mode", "holdout_robot_ids", "pretrain_session_ids",
    "adaptation_session_ids", "validation_session_ids", "test_session_ids",
)
SPLITS = ("pretrain", "adaptation", "validation", "test")
SYNC_STATUS = ("hardware_trigger", "ptp_verified", "unsynced")


def _quantile(values: list[float], fraction: float) -> float:
    if not values:
        return float("nan")
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lo = math.floor(position)
    hi = math.ceil(position)
    return ordered[lo] * (hi - position) + ordered[hi] * (position - lo) if lo != hi else ordered[lo]


def _read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def _number(value: str, label: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} is not numeric: {value!r}") from exc
    if not math.isfinite(number):
        raise ValueError(f"{label} is nonfinite: {value!r}")
    return number


def _integer(value: str, label: str) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} is not an integer: {value!r}") from exc
    return number


def _strict_increasing(values: list[int], label: str) -> None:
    if any(right <= left for left, right in zip(values, values[1:])):
        raise ValueError(f"{label} must be strictly increasing")


def _resolved(base: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _clock_fit(events: list[dict[str, str]]) -> dict[str, Any]:
    """Fit camera_time = camera_ref + slope*(ctrl-ctrl_ref) + intercept."""
    ids = [row["event_id"] for row in events]
    if len(ids) != len(set(ids)):
        raise ValueError("sync event_id values must be unique")
    camera = [_integer(row["camera_time_ns"], "sync camera_time_ns") for row in events]
    controller = [_integer(row["controller_time_ns"], "sync controller_time_ns") for row in events]
    _strict_increasing(camera, "sync camera_time_ns")
    _strict_increasing(controller, "sync controller_time_ns")
    if len(camera) < 3:
        raise ValueError("At least three paired sync events are required")
    camera_ref, controller_ref = camera[0], controller[0]
    x = [float(value - controller_ref) for value in controller]
    y = [float(value - camera_ref) for value in camera]
    x_mean = sum(x) / len(x)
    y_mean = sum(y) / len(y)
    spread = sum((value - x_mean) ** 2 for value in x)
    if spread == 0:
        raise ValueError("Sync events have no controller-time span")
    slope = sum((a - x_mean) * (b - y_mean) for a, b in zip(x, y)) / spread
    if slope <= 0:
        raise ValueError("Sync clock fit has nonpositive slope")
    intercept = y_mean - slope * x_mean
    residual_ms = [abs(b - slope * a - intercept) / 1e6 for a, b in zip(x, y)]
    return {
        "camera_ref_ns": camera_ref,
        "controller_ref_ns": controller_ref,
        "slope": slope,
        "intercept_ns": intercept,
        "residual_ms_p95": _quantile(residual_ms, 0.95),
        "residual_ms_max": max(residual_ms),
        "clock_drift_ppm": (slope - 1.0) * 1e6,
        "first_camera_event_ns": camera[0],
        "last_camera_event_ns": camera[-1],
    }


def _validate_session(session: dict[str, Any], robot: dict[str, Any], base: Path,
                      max_sync_residual_ms: float, max_label_gap_ms: float,
                      strict_sync: bool = False) -> dict[str, Any]:
    sid = session.get("session_id", "<unnamed>")
    errors: list[str] = []
    warnings: list[str] = []
    stats: dict[str, Any] = {}
    for key in REQUIRED_SESSION:
        if key not in session or session[key] in (None, "", []):
            errors.append(f"missing {key}")
    if errors:
        return {"session_id": sid, "errors": errors, "warnings": warnings, "stats": stats}
    if session["sync_status"] not in SYNC_STATUS:
        errors.append(f"sync_status must be one of {SYNC_STATUS}")
    elif session["sync_status"] == "unsynced":
        errors.append("unsynced session cannot support verified angle accuracy")
    columns = session["joint_columns"]
    names = robot.get("joint_names", [])
    if not isinstance(columns, list) or len(columns) != len(names) or len(set(columns)) != len(columns):
        errors.append("joint_columns must map one-to-one in robot joint_names order")
    paths = {}
    if session.get("frames_path") and not _resolved(base, session["frames_path"]).is_dir():
        errors.append(f"frames_path does not exist: {_resolved(base, session['frames_path'])}")
    for key in ("video_path", "frame_timestamps_path", "encoder_path", "sync_events_path"):
        path = _resolved(base, session[key])
        paths[key] = path
        if not path.is_file():
            errors.append(f"{key} does not exist: {path}")
        expected = session.get("sha256", {}).get(key)
        if path.is_file() and expected and _sha256(path).lower() != expected.lower():
            errors.append(f"{key} sha256 mismatch")
    if errors:
        return {"session_id": sid, "errors": errors, "warnings": warnings, "stats": stats}
    try:
        frame_header, frames = _read_csv(paths["frame_timestamps_path"])
        encoder_header, encoder = _read_csv(paths["encoder_path"])
        event_header, events = _read_csv(paths["sync_events_path"])
        for required, present, label in (
            (("frame_index", "camera_time_ns", "trigger_id"), frame_header, "frames"),
            (("controller_time_ns", *columns), encoder_header, "encoder"),
            (("event_id", "camera_time_ns", "controller_time_ns"), event_header, "events"),
        ):
            missing = sorted(set(required) - set(present))
            if missing:
                raise ValueError(f"{label} CSV missing columns: {missing}")
        if len(frames) < 2 or len(encoder) < 3:
            raise ValueError("Need at least two frames and three encoder samples")
        frame_ids = [_integer(row["frame_index"], "frame_index") for row in frames]
        frame_t = [_integer(row["camera_time_ns"], "camera_time_ns") for row in frames]
        trigger_ids = [_integer(row["trigger_id"], "trigger_id") for row in frames]
        controller_t = [_integer(row["controller_time_ns"], "controller_time_ns") for row in encoder]
        _strict_increasing(frame_ids, "frame_index")
        _strict_increasing(frame_t, "camera_time_ns")
        _strict_increasing(trigger_ids, "trigger_id")
        _strict_increasing(controller_t, "controller_time_ns")
        if any(right - left != 1 for left, right in zip(frame_ids, frame_ids[1:])):
            errors.append("frame_index has a gap")
        if any(right - left != 1 for left, right in zip(trigger_ids, trigger_ids[1:])):
            errors.append("trigger_id has a gap: dropped capture or missing trigger")
        for row in encoder:
            for column in columns:
                _number(row[column], f"encoder {column}")
        fit = _clock_fit(events)
        stats.update({
            "frame_count": len(frames),
            "encoder_samples": len(encoder),
            "duration_s": (frame_t[-1] - frame_t[0]) / 1e9,
            "sync_event_count": len(events),
            "sync_residual_ms_p95": fit["residual_ms_p95"],
            "sync_residual_ms_max": fit["residual_ms_max"],
            "clock_drift_ppm": fit["clock_drift_ppm"],
        })
        if fit["residual_ms_p95"] > max_sync_residual_ms:
            errors.append(f"sync p95 residual {fit['residual_ms_p95']:.3f} ms exceeds {max_sync_residual_ms:g} ms")
        span = (frame_t[-1] - frame_t[0]) * 0.8
        if fit["last_camera_event_ns"] - fit["first_camera_event_ns"] < span:
            errors.append("sync events do not span at least 80% of the frame interval")
        if fit["first_camera_event_ns"] > frame_t[0] or fit["last_camera_event_ns"] < frame_t[-1]:
            message = "sync events do not bracket all frames; edge clock mapping extrapolates"
            (errors if strict_sync else warnings).append(message)
        camera_ref = fit["camera_ref_ns"]
        controller_ref = fit["controller_ref_ns"]
        slope = fit["slope"]
        intercept = fit["intercept_ns"]
        # Keep values relative to the sync reference so epoch-sized ns integers
        # do not lose precision when converted to floats for the affine fit.
        mapped = [(t - camera_ref - intercept) / slope for t in frame_t]
        controller_relative = [t - controller_ref for t in controller_t]
        if mapped[0] < controller_relative[0] or mapped[-1] > controller_relative[-1]:
            errors.append("encoder timestamps do not cover all mapped frame exposure times")
        gaps = []
        for timestamp in mapped:
            index = bisect.bisect_left(controller_relative, timestamp)
            candidates = []
            if index < len(controller_relative):
                candidates.append(abs(controller_relative[index] - timestamp))
            if index:
                candidates.append(abs(controller_relative[index - 1] - timestamp))
            gaps.append(min(candidates) / 1e6)
        stats["nearest_encoder_gap_ms_p95"] = _quantile(gaps, 0.95)
        stats["nearest_encoder_gap_ms_max"] = max(gaps)
        if stats["nearest_encoder_gap_ms_p95"] > max_label_gap_ms:
            errors.append(f"encoder p95 gap {stats['nearest_encoder_gap_ms_p95']:.3f} ms exceeds {max_label_gap_ms:g} ms")
        intervals = [(b - a) / 1e6 for a, b in zip(frame_t, frame_t[1:])]
        stats["median_frame_interval_ms"] = _quantile(intervals, 0.5)
        if max(intervals) > 1.5 * stats["median_frame_interval_ms"]:
            warnings.append("frame timestamps have a large interval; inspect dropped frames")
        if "fps" in session:
            expected = 1000.0 / _number(str(session["fps"]), "fps")
            if abs(stats["median_frame_interval_ms"] - expected) > max(0.5, 0.02 * expected):
                errors.append("measured frame interval disagrees with declared fps")
    except (ValueError, KeyError, OSError) as exc:
        errors.append(str(exc))
    return {"session_id": sid, "errors": errors, "warnings": warnings, "stats": stats}


def _validate_fold(fold: dict[str, Any], sessions: dict[str, dict[str, Any]],
                   robots: set[str]) -> dict[str, Any]:
    fid = fold.get("fold_id", "<unnamed>")
    errors: list[str] = []
    for key in REQUIRED_FOLD:
        if key not in fold:
            errors.append(f"missing {key}")
    if errors:
        return {"fold_id": fid, "errors": errors}
    if fold["mode"] not in ("zero_shot", "few_shot"):
        errors.append("mode must be zero_shot or few_shot")
    held = set(fold["holdout_robot_ids"])
    if not held or not held <= robots:
        errors.append("holdout_robot_ids must name at least one declared robot")
    sets = {key: set(fold[f"{key}_session_ids"]) for key in SPLITS}
    for key, ids in sets.items():
        if len(ids) != len(fold[f"{key}_session_ids"]):
            errors.append(f"duplicate session in {key}")
        unknown = ids - set(sessions)
        if unknown:
            errors.append(f"unknown {key} sessions: {sorted(unknown)}")
    for a, ids_a in sets.items():
        for b, ids_b in sets.items():
            if a < b and ids_a & ids_b:
                errors.append(f"sessions appear in both {a} and {b}")
    if not sets["test"]:
        errors.append("test_session_ids is empty")
    for sid in sets["test"] & set(sessions):
        if sessions[sid]["robot_id"] not in held:
            errors.append(f"test session {sid} is not a held-out robot")
    for key in ("pretrain", "validation"):
        for sid in sets[key] & set(sessions):
            if sessions[sid]["robot_id"] in held:
                errors.append(f"held-out robot {sid} leaks into {key}")
    if fold["mode"] == "zero_shot" and sets["adaptation"]:
        errors.append("zero_shot fold cannot have adaptation sessions")
    for sid in sets["adaptation"] & set(sessions):
        if sessions[sid]["robot_id"] not in held:
            errors.append(f"adaptation session {sid} is not a held-out robot")
    if fold["mode"] == "few_shot" and not sets["adaptation"]:
        errors.append("few_shot fold needs predeclared adaptation sessions")
    # A repeated physical trajectory across train/test would leak temporal states.
    test_keys = {(sessions[sid]["robot_id"], sessions[sid]["trajectory_id"])
                 for sid in sets["test"] & set(sessions)}
    for key in ("pretrain", "adaptation", "validation"):
        for sid in sets[key] & set(sessions):
            trajectory_key = (sessions[sid]["robot_id"], sessions[sid]["trajectory_id"])
            if trajectory_key in test_keys:
                errors.append(f"trajectory {trajectory_key} appears in {key} and test")
    return {"fold_id": fid, "errors": errors}


def validate_manifest(path: Path, *, max_sync_residual_ms: float = 2.0,
                      max_label_gap_ms: float = 10.0,
                      strict_sync: bool = False) -> dict[str, Any]:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    base = path.parent
    errors: list[str] = []
    if manifest.get("protocol_version") != "1.0":
        errors.append("protocol_version must be '1.0'")
    if not math.isfinite(max_sync_residual_ms) or max_sync_residual_ms <= 0:
        errors.append("max_sync_residual_ms must be positive and finite")
    if not math.isfinite(max_label_gap_ms) or max_label_gap_ms <= 0:
        errors.append("max_label_gap_ms must be positive and finite")
    robots = {}
    for robot in manifest.get("robots", []):
        rid = robot.get("robot_id")
        names = robot.get("joint_names", [])
        kinds = robot.get("joint_types", [])
        if not rid or rid in robots:
            errors.append(f"missing or duplicate robot_id: {rid!r}")
        if not names or len(names) != len(set(names)) or len(kinds) != len(names):
            errors.append(f"robot {rid}: joint_names must be unique and match joint_types")
        if any(kind not in ("revolute", "continuous", "prismatic") for kind in kinds):
            errors.append(f"robot {rid}: unsupported joint type")
        robots[rid] = robot
    if not robots:
        errors.append("manifest must declare robots")
    sessions = {}
    for session in manifest.get("sessions", []):
        sid = session.get("session_id")
        if not sid or sid in sessions:
            errors.append(f"missing or duplicate session_id: {sid!r}")
        sessions[sid] = session
    if not sessions:
        errors.append("manifest must declare sessions")
    raw_files: dict[tuple[str, str], str] = {}
    raw_hashes: dict[tuple[str, str], str] = {}
    for sid, session in sessions.items():
        for field in ("video_path", "frame_timestamps_path", "encoder_path"):
            if field not in session:
                continue
            path_key = (field, str(_resolved(base, session[field]).resolve()))
            previous = raw_files.get(path_key)
            if previous and previous != sid:
                errors.append(f"{sid} reuses {field} from {previous}")
            raw_files[path_key] = sid
            source = _resolved(base, session[field])
            if source.is_file():
                hash_key = (field, _sha256(source))
                previous = raw_hashes.get(hash_key)
                if previous and previous != sid:
                    errors.append(f"{sid} duplicates {field} bytes from {previous} (SHA-256 leakage)")
                raw_hashes[hash_key] = sid
    session_reports = []
    for sid, session in sessions.items():
        rid = session.get("robot_id")
        if rid not in robots:
            session_reports.append({"session_id": sid, "errors": [f"unknown robot_id {rid!r}"], "warnings": [], "stats": {}})
        else:
            session_reports.append(_validate_session(session, robots[rid], base,
                                                     max_sync_residual_ms, max_label_gap_ms,
                                                     strict_sync))
    folds = manifest.get("evaluation_folds", [])
    if not folds:
        errors.append("manifest must predeclare evaluation_folds")
    fold_ids = [fold.get("fold_id") for fold in folds]
    if len(fold_ids) != len(set(fold_ids)):
        errors.append("duplicate fold_id")
    fold_reports = [_validate_fold(fold, sessions, set(robots)) for fold in folds]
    valid = not errors and all(not report["errors"] for report in session_reports + fold_reports)
    return {
        "valid": valid,
        "manifest": str(path),
        "protocol_version": manifest.get("protocol_version"),
        "max_sync_residual_ms": max_sync_residual_ms,
        "max_label_gap_ms": max_label_gap_ms,
        "strict_sync": strict_sync,
        "errors": errors,
        "sessions": session_reports,
        "folds": fold_reports,
        "limitation": "File consistency only; physical sync wiring and ground truth accuracy require independent verification.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--max-sync-residual-ms", type=float, default=2.0,
                        help="Study-defined p95 clock-fit threshold; not an IEEE requirement")
    parser.add_argument("--max-label-gap-ms", type=float, default=10.0,
                        help="Study-defined p95 nearest encoder-sample gap; not an IEEE requirement")
    parser.add_argument("--strict-sync", action="store_true",
                        help="Reject sync events that do not bracket every frame")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = validate_manifest(args.manifest, max_sync_residual_ms=args.max_sync_residual_ms,
                               max_label_gap_ms=args.max_label_gap_ms,
                               strict_sync=args.strict_sync)
    serialized = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(serialized, encoding="utf-8")
    print(serialized)
    raise SystemExit(0 if report["valid"] else 1)


if __name__ == "__main__":
    main()
