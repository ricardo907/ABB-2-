"""Exploratory lag-sensitivity evaluation; offsets are not verified truth."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from selection import ValidatedTrajectoryEstimator
from sync.time_sync import interpolate_frame_labels, read_encoder_log
from vision.frontend import CanonicalVideoFrontend, load_frame_directory


PROJECT = Path(__file__).resolve().parents[2]
CASES = {
    "Exp001": (PROJECT / "data/train/Exp001", "Train_Angle1_real.xlsx", 1.0),
    "Exp002": (PROJECT / "data2/test/Exp002", "Test_Angle2_real.xlsx", 1.333),
}
OUT = Path(__file__).resolve().parent


def metrics(actual: np.ndarray, prediction: np.ndarray) -> dict:
    error = np.abs(actual - prediction)
    return {"mae": float(error.mean()),
            "per_joint_mae": error.mean(axis=0).tolist(),
            "per_joint_p95": np.percentile(error, 95, axis=0).tolist()}


def main() -> None:
    names = {}
    frames = {}
    labels = {}
    selected_indices = {}
    joint_names = None
    for name, (folder, log_name, offset) in CASES.items():
        names[name], frames[name] = load_frame_directory(folder / "frames")
        log_times, angles, current_names = read_encoder_log(folder / log_name)
        if joint_names is None:
            joint_names = current_names
        if len(current_names) != len(joint_names):
            raise ValueError("The two recordings have different joint counts")
        table = interpolate_frame_labels(len(names[name]), 24.0, log_times, angles, offset)
        indices = np.asarray([int(image[6:10]) for image in table["image"]], dtype=int)
        selected_indices[name] = indices
        labels[name] = table[[f"joint_{i}" for i in range(1, len(joint_names) + 1)]].to_numpy()
    frontend = CanonicalVideoFrontend().fit_reference(frames["Exp001"])
    visual = {
        "Exp001": frontend.transform(frames["Exp001"], reference=True),
        "Exp002": frontend.transform(frames["Exp002"]),
    }
    if not all(result.usable for result in visual.values()):
        raise RuntimeError("Scene registration failed")
    results = []
    for source, target in (("Exp001", "Exp002"), ("Exp002", "Exp001")):
        source_index = selected_indices[source]
        target_index = selected_indices[target]
        model = ValidatedTrajectoryEstimator().fit(
            visual[source].appearance[source_index],
            visual[source].motion[source_index],
            labels[source], joint_names,
        )
        prediction = model.predict(
            visual[target].appearance[target_index],
            visual[target].motion[target_index],
        )
        actual = labels[target]
        results.append({
            "source": source,
            "target": target,
            "source_frames": len(source_index),
            "target_frames": len(target_index),
            "mean": metrics(actual, np.broadcast_to(labels[source].mean(axis=0), actual.shape)),
            "absolute": metrics(actual, prediction["absolute_observation"]),
            "selected": metrics(actual, prediction["angles"]),
            "selected_modes": list(model.selected_modes),
            "reliable_fraction": float(prediction["reliable"].mean()),
        })
    report = {"status": "exploratory: source and evaluation offsets from visual-motion evidence only",
              "offsets_s": {name: case[2] for name, case in CASES.items()},
              "results": results}
    (OUT / "shifted_evaluation_results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
