# Empirical risk gate for held-out trajectories

`empirical_gate.py` selects one quality threshold per joint using **independent,
held-out, hardware-synchronized validation trajectories**. It accepts the
largest observed set of high-quality frames whose *maximum measured joint
error* stays within a tolerance supplied for that joint. A joint with no
threshold supported by at least three trajectories abstains everywhere.

This is a descriptive validation rule. It does **not** establish a statistical
coverage bound, a future maximum error, or robot safety. The same trajectories
both select the threshold and report its measured error. Their correlated
frames cannot be counted as independent trials. Evaluate the frozen policy on
additional, untouched trajectories before making generalization claims.

## Input contract

For each validation trajectory, supply a prediction CSV and a synchronized
ground-truth CSV. Both need unique `image` values and exactly the same image
set. The prediction CSV uses `pred__<joint>`, `quality__<joint>`, and (by
default) `reliable__<joint>` columns. The truth CSV uses the joint name or the
explicit `JointSpec.truth_column`. Predicted values and quality may be blank on
unregistered frames; those frames never pass the gate and remain in the
coverage denominator. Truth values must be complete and finite. Quality must
lie in `[0, 1]`.

Declare each joint's `joint_type` (`revolute`, `continuous`, `prismatic`) and
`unit` (`rad`/`deg` for rotation; `m`/`mm` for translation). Continuous-joint
error uses the shortest difference modulo 2π radians or 360 degrees. Error
tolerances and reported errors retain each joint's declared unit. No mixed-unit
overall error is computed.

The caller must provide at least three distinct `trajectory_id` values and
three distinct `capture_sha256` values. Reused prediction or truth CSV content
is rejected. Each pair must explicitly say `label_status="verified_hardware_sync"`
and `held_out_from_training=True`. Known training capture hashes can be passed
to `training_capture_sha256` and are rejected if reused. These metadata fields
are declarations; this module cannot inspect physical wiring or certify that
a claimed encoder log was truly synchronized. The existing Exp001/Exp002
*provisional* labels do not meet this input contract and must not be relabeled
as verified for threshold fitting.

## Python interface

```python
import json
from pathlib import Path

from reliability.empirical_gate import (
    JointSpec, ValidationTrajectory, fit_policy, apply_policy,
)

trajectories = [
    ValidationTrajectory(
        trajectory_id="independent_run_001",
        prediction_csv="run_001_predictions.csv",
        truth_csv="run_001_synced_encoder.csv",
        capture_sha256="...64 hexadecimal characters...",
        label_status="verified_hardware_sync",
        held_out_from_training=True,
    ),
    # At least two more independent runs.
]
joint_specs = [
    JointSpec("shoulder", "continuous", "rad"),
    JointSpec("slide", "prismatic", "m", truth_column="encoder_slide"),
]
policy = fit_policy(
    trajectories,
    joint_specs,
    max_error_by_joint={"shoulder": 0.10, "slide": 0.005},
    training_capture_sha256=["...actual training capture hash..."],
)
Path("empirical_policy.json").write_text(json.dumps(policy, indent=2),
                                          encoding="utf-8")
gated = apply_policy(policy, "new_predictions.csv")
gated.to_csv("new_predictions_gated.csv", index=False)
```

The policy includes each joint's threshold (or `null` for abstention), pooled
validation coverage, macro-average trajectory coverage, maximum accepted
error, per-trajectory counts/errors, and SHA-256 hashes of every prediction
and truth CSV. `source_sha256` summarizes those source records, while
`policy_sha256` detects accidental policy edits. Hashes track content; they do
not authenticate the hardware or the person who supplied the metadata.

`apply_policy()` adds `empirical_reliable__<joint>` and
`empirical_safe__<joint>` columns. It respects the original `reliable__`
column by default. `empirical_safe__` is blank where the new gate abstains.
The function also accepts a policy JSON path and a pandas DataFrame.

Run `python selfcheck.py` from this directory for synthetic tests of radian and
degree periodic errors, mixed units, abstention, duplicate detection,
provisional-label rejection, and policy JSON round-trip.
