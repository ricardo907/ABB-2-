"""Descriptive, per-joint risk gates fitted on independent held-out trajectories.

The maximum errors in a fitted policy describe its supplied validation data.
They are not statistical bounds, coverage guarantees, or robot safety claims.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
import pandas as pd


SCHEMA = "robot-empirical-quality-gate-v1"
VERIFIED_LABEL_STATUS = "verified_hardware_sync"


@dataclass(frozen=True)
class JointSpec:
    name: str
    joint_type: str  # revolute, continuous, or prismatic
    unit: str  # rad/deg for rotation, m/mm for translation
    truth_column: str | None = None


@dataclass(frozen=True)
class ValidationTrajectory:
    trajectory_id: str
    prediction_csv: str | Path
    truth_csv: str | Path
    capture_sha256: str
    label_status: str
    held_out_from_training: bool


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_json(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _check_hash(value: str, name: str) -> str:
    if not isinstance(value, str) or len(value) != 64 or any(
        character not in "0123456789abcdef" for character in value.lower()
    ):
        raise ValueError(f"{name} must be a SHA-256 hex digest")
    return value.lower()


def _joint_specs(specs: Sequence[JointSpec]) -> list[JointSpec]:
    values = list(specs)
    if not values or not all(isinstance(item, JointSpec) for item in values):
        raise ValueError("joint_specs must contain JointSpec entries")
    names = [item.name for item in values]
    if any(not isinstance(name, str) or not name for name in names) or len(set(names)) != len(names):
        raise ValueError("Joint names must be nonempty and unique")
    for item in values:
        allowed = ({"rad", "deg"} if item.joint_type in {"revolute", "continuous"}
                   else {"m", "mm"} if item.joint_type == "prismatic" else set())
        if item.unit not in allowed:
            raise ValueError(f"Invalid joint type/unit for {item.name}: {item.joint_type}/{item.unit}")
        if item.truth_column is not None and (not isinstance(item.truth_column, str)
                                              or not item.truth_column):
            raise ValueError(f"Invalid truth column for {item.name}")
    truth_names = [item.truth_column or item.name for item in values]
    if len(set(truth_names)) != len(truth_names):
        raise ValueError("Truth columns must be unique")
    return values


def _bool_column(table: pd.DataFrame, name: str) -> np.ndarray:
    if name not in table:
        raise ValueError(f"Missing required column: {name}")
    values = table[name].map({True: True, False: False, 1: True, 0: False,
                              "True": True, "False": False,
                              "true": True, "false": False})
    if values.isna().any():
        raise ValueError(f"{name} must contain only true/false values")
    return values.to_numpy(dtype=bool)


def _numeric_column(table: pd.DataFrame, name: str, *,
                    allow_missing: bool = False) -> np.ndarray:
    if name not in table:
        raise ValueError(f"Missing required column: {name}")
    values = pd.to_numeric(table[name], errors="raise").to_numpy(dtype=np.float64)
    if np.isinf(values).any() or (not allow_missing and not np.isfinite(values).all()):
        raise ValueError(f"{name} contains non-finite values")
    return values


def _check_images(table: pd.DataFrame, path: Path) -> list[str]:
    if "image" not in table:
        raise ValueError(f"{path} needs an image column")
    names = table["image"].tolist()
    if (not names or any(not isinstance(name, str) or not name for name in names)
            or len(set(names)) != len(names)):
        raise ValueError(f"{path} has missing or duplicate image names")
    return names


def _read_pair(pair: ValidationTrajectory, specs: list[JointSpec],
               use_base_reliability: bool) -> tuple[dict, dict[str, dict]]:
    pred_path = Path(pair.prediction_csv).resolve()
    truth_path = Path(pair.truth_csv).resolve()
    if not pred_path.is_file() or not truth_path.is_file() or pred_path == truth_path:
        raise ValueError(f"Missing or identical prediction/truth CSV for {pair.trajectory_id}")
    pred = pd.read_csv(pred_path)
    truth = pd.read_csv(truth_path)
    pred_names = _check_images(pred, pred_path)
    truth_names = _check_images(truth, truth_path)
    if len(pred_names) != len(truth_names) or set(pred_names) != set(truth_names):
        raise ValueError(f"Prediction/truth frames differ for {pair.trajectory_id}")
    truth = truth.set_index("image").loc[pred_names].reset_index()
    data: dict[str, dict] = {}
    for spec in specs:
        name = spec.name
        prediction = _numeric_column(pred, f"pred__{name}", allow_missing=True)
        quality = _numeric_column(pred, f"quality__{name}", allow_missing=True)
        finite_quality = quality[np.isfinite(quality)]
        if ((finite_quality < 0).any() or (finite_quality > 1).any()):
            raise ValueError(f"quality__{name} must lie in [0, 1]")
        actual = _numeric_column(truth, spec.truth_column or name)
        base = (_bool_column(pred, f"reliable__{name}") if use_base_reliability
                else np.ones(len(pred), dtype=bool))
        eligible = base & np.isfinite(prediction) & np.isfinite(quality)
        delta = np.abs(prediction - actual)
        if spec.joint_type == "continuous":
            period = 2 * np.pi if spec.unit == "rad" else 360.0
            delta = np.abs((prediction - actual + period / 2) % period - period / 2)
        data[name] = {"quality": quality, "error": delta,
                      "eligible": eligible, "frames": len(pred)}
    source = {
        "trajectory_id": pair.trajectory_id,
        "capture_sha256": _check_hash(pair.capture_sha256, "capture_sha256"),
        "prediction_csv_sha256": _sha256_file(pred_path),
        "truth_csv_sha256": _sha256_file(truth_path),
        "prediction_csv_path": str(pred_path),
        "truth_csv_path": str(truth_path),
        "frame_count": len(pred),
        "label_status": pair.label_status,
        "held_out_from_training": pair.held_out_from_training,
    }
    return source, data


def fit_policy(
    validation_trajectories: Sequence[ValidationTrajectory],
    joint_specs: Sequence[JointSpec],
    max_error_by_joint: Mapping[str, float],
    *,
    min_accepted_trajectories: int = 3,
    use_base_reliability: bool = True,
    training_capture_sha256: Sequence[str] = (),
) -> dict:
    """Fit maximum-coverage quality cutoffs under observed error tolerances.

    A trajectory must have verified synchronized encoder labels and be declared
    held out from fitting. At least three unique trajectory and capture IDs are
    required. Higher quality is assumed preferable; if any high-quality
    accepted frame exceeds the tolerance, no lower threshold can include it.
    A joint with insufficient evidence gets ``quality_threshold=None`` and
    always abstains. The resulting maxima are descriptive validation results.
    """
    specs = _joint_specs(joint_specs)
    pairs = list(validation_trajectories)
    if len(pairs) < 3 or not all(isinstance(pair, ValidationTrajectory) for pair in pairs):
        raise ValueError("At least three ValidationTrajectory entries are required")
    if not isinstance(min_accepted_trajectories, int) or min_accepted_trajectories < 3:
        raise ValueError("min_accepted_trajectories must be at least 3")
    if min_accepted_trajectories > len(pairs):
        raise ValueError("min_accepted_trajectories exceeds the trajectory count")
    training_hashes = {_check_hash(value, "training_capture_sha256")
                       for value in training_capture_sha256}
    ids = [pair.trajectory_id for pair in pairs]
    if any(not isinstance(value, str) or not value.strip() for value in ids):
        raise ValueError("trajectory_id must be a nonempty string")
    if len(set(ids)) != len(ids):
        raise ValueError("The same trajectory_id was supplied more than once")
    for pair in pairs:
        if pair.label_status != VERIFIED_LABEL_STATUS:
            raise ValueError(f"{pair.trajectory_id}: provisional/unverified labels cannot fit a risk policy")
        if pair.held_out_from_training is not True:
            raise ValueError(f"{pair.trajectory_id}: trajectory must be held out from training")
    names = {spec.name for spec in specs}
    if set(max_error_by_joint) != names:
        raise ValueError("max_error_by_joint must specify exactly the listed joints")
    limits = {}
    for name in names:
        value = float(max_error_by_joint[name])
        if not np.isfinite(value) or value < 0:
            raise ValueError(f"Invalid maximum error tolerance for {name}")
        limits[name] = value

    sources = []
    records: dict[str, list[dict]] = {spec.name: [] for spec in specs}
    seen_captures: set[str] = set()
    seen_prediction_files: set[str] = set()
    seen_truth_files: set[str] = set()
    for pair in pairs:
        source, data = _read_pair(pair, specs, use_base_reliability)
        capture = source["capture_sha256"]
        if capture in seen_captures or capture in training_hashes:
            raise ValueError(f"Duplicate or training capture for {pair.trajectory_id}")
        if (source["prediction_csv_sha256"] in seen_prediction_files or
                source["truth_csv_sha256"] in seen_truth_files):
            raise ValueError(f"Repeated prediction/truth data for {pair.trajectory_id}")
        seen_captures.add(capture)
        seen_prediction_files.add(source["prediction_csv_sha256"])
        seen_truth_files.add(source["truth_csv_sha256"])
        sources.append(source)
        for spec in specs:
            records[spec.name].append({"trajectory_id": pair.trajectory_id,
                                       **data[spec.name]})

    joint_policy = {}
    for spec in specs:
        rows = records[spec.name]
        total_frames = sum(item["frames"] for item in rows)
        observations = []
        for item in rows:
            for quality, error in zip(item["quality"][item["eligible"]],
                                      item["error"][item["eligible"]]):
                observations.append((float(quality), float(error), item["trajectory_id"]))
        observations.sort(key=lambda row: row[0], reverse=True)
        accepted_count = 0
        accepted_ids: set[str] = set()
        observed_max = None
        threshold = None
        index = 0
        while index < len(observations):
            level = observations[index][0]
            end = index + 1
            while end < len(observations) and observations[end][0] == level:
                end += 1
            group = observations[index:end]
            group_max = max(row[1] for row in group)
            if group_max > limits[spec.name]:
                break
            accepted_count += len(group)
            accepted_ids.update(row[2] for row in group)
            observed_max = max(group_max, observed_max or 0.0)
            threshold = level
            index = end
        if len(accepted_ids) < min_accepted_trajectories:
            threshold = None
            accepted_count = 0
            accepted_ids = set()
            observed_max = None

        per_trajectory = {}
        for item in rows:
            accepted = (item["eligible"] & (item["quality"] >= threshold)
                        if threshold is not None else
                        np.zeros(item["frames"], dtype=bool))
            error = item["error"][accepted]
            per_trajectory[item["trajectory_id"]] = {
                "frames": item["frames"],
                "eligible_frames": int(item["eligible"].sum()),
                "accepted_frames": int(accepted.sum()),
                "coverage": float(accepted.mean()),
                "max_error": float(error.max()) if len(error) else None,
            }
        joint_policy[spec.name] = {
            "joint_type": spec.joint_type,
            "unit": spec.unit,
            "truth_column": spec.truth_column or spec.name,
            "max_error_tolerance": limits[spec.name],
            "quality_threshold": threshold,
            "status": "empirical_gate" if threshold is not None else "abstain_no_supported_threshold",
            "validation_frames": total_frames,
            "eligible_frames": len(observations),
            "accepted_frames": accepted_count,
            "accepted_trajectories": len(accepted_ids),
            "validation_coverage": accepted_count / total_frames,
            "trajectory_macro_coverage": float(np.mean([
                value["coverage"] for value in per_trajectory.values()])),
            "max_accepted_error": observed_max,
            "per_trajectory": per_trajectory,
        }

    sources.sort(key=lambda item: item["trajectory_id"])
    policy = {
        "schema": SCHEMA,
        "status": "descriptive_validation_only_no_statistical_guarantee",
        "method": "highest-coverage quality cutoff with observed max error within tolerance",
        "joint_order": [spec.name for spec in specs],
        "joints": joint_policy,
        "use_base_reliability": bool(use_base_reliability),
        "min_accepted_trajectories": min_accepted_trajectories,
        "validation_trajectory_count": len(pairs),
        "validation_sources": sources,
        "training_capture_sha256": sorted(training_hashes),
        "source_sha256": _sha256_json({
            "validation_sources": [{key: value for key, value in source.items()
                                    if not key.endswith("_path")}
                                   for source in sources],
            "training_capture_sha256": sorted(training_hashes),
        }),
        "warning": "Empirical maxima and coverage are descriptive; no future error or coverage guarantee.",
    }
    policy["policy_sha256"] = _sha256_json(policy)
    return policy


def apply_policy(policy: dict | str | Path,
                 predictions: pd.DataFrame | str | Path) -> pd.DataFrame:
    """Append per-joint empirical_reliable__/empirical_safe__ columns.

    This enforces the fitted quality threshold and, if configured, the model's
    base reliable__ gate. A policy with no supported threshold abstains for
    that joint. Input predictions are copied and never modified in place.
    """
    if isinstance(policy, (str, Path)):
        policy = json.loads(Path(policy).read_text(encoding="utf-8"))
    if not isinstance(policy, dict) or policy.get("schema") != SCHEMA:
        raise ValueError("Unsupported empirical gate policy")
    claimed_hash = policy.get("policy_sha256")
    content = {key: value for key, value in policy.items() if key != "policy_sha256"}
    if claimed_hash != _sha256_json(content):
        raise ValueError("Empirical gate policy hash mismatch")
    table = (predictions.copy() if isinstance(predictions, pd.DataFrame)
             else pd.read_csv(predictions))
    _check_images(table, Path("predictions"))
    for name in policy["joint_order"]:
        settings = policy["joints"][name]
        prediction = _numeric_column(table, f"pred__{name}", allow_missing=True)
        quality = _numeric_column(table, f"quality__{name}", allow_missing=True)
        finite_quality = quality[np.isfinite(quality)]
        if (finite_quality < 0).any() or (finite_quality > 1).any():
            raise ValueError(f"quality__{name} must lie in [0, 1]")
        base = (_bool_column(table, f"reliable__{name}")
                if policy["use_base_reliability"] else
                np.ones(len(table), dtype=bool))
        threshold = settings["quality_threshold"]
        accepted = (base & np.isfinite(prediction) & np.isfinite(quality) &
                    (quality >= threshold) if threshold is not None else
                    np.zeros(len(table), dtype=bool))
        table[f"empirical_reliable__{name}"] = accepted
        table[f"empirical_safe__{name}"] = np.where(accepted, prediction, np.nan)
    return table
