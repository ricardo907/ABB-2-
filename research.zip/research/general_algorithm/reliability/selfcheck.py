"""Deterministic checks for empirical risk gates; uses only synthetic data."""

from __future__ import annotations

from dataclasses import replace
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pandas as pd

from empirical_gate import (JointSpec, ValidationTrajectory, apply_policy,
                            fit_policy)


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _must_reject(callback, text: str) -> None:
    try:
        callback()
    except ValueError as exc:
        assert text in str(exc), str(exc)
    else:
        raise AssertionError(f"Expected rejection containing {text!r}")


def main() -> None:
    specs = [JointSpec("jrad", "continuous", "rad", "encoder_rad"),
             JointSpec("jlinear", "prismatic", "m"),
             JointSpec("jdeg", "revolute", "deg"),
             JointSpec("jwrapdeg", "continuous", "deg")]
    limits = {"jrad": 0.1, "jlinear": 0.005, "jdeg": 1.0,
              "jwrapdeg": 5.0}
    with TemporaryDirectory() as temporary:
        folder = Path(temporary)
        pairs = []
        for trajectory in range(3):
            names = [f"frame_{index:04d}.jpg" for index in range(4)]
            actual_rad = np.array([np.pi - 0.01, -np.pi + 0.03, 0.4, 1.0]) + 0.01 * trajectory
            predicted_rad = actual_rad + np.array([-2 * np.pi + 0.02,
                                                    2 * np.pi - 0.02, 0.04, 0.5])
            actual_linear = np.array([0.1, 0.2, 0.3, 0.4]) + 0.01 * trajectory
            actual_deg = np.array([0.0, 10.0, 20.0, 30.0]) + trajectory
            actual_wrapdeg = np.array([179.0, -179.0, 10.0, 20.0]) + trajectory
            truth = pd.DataFrame({"image": names, "encoder_rad": actual_rad,
                                  "jlinear": actual_linear, "jdeg": actual_deg,
                                  "jwrapdeg": actual_wrapdeg})
            prediction = pd.DataFrame({
                "image": names,
                "pred__jrad": predicted_rad,
                "quality__jrad": [0.9, 0.8, 0.7, 0.6],
                "reliable__jrad": [True] * 4,
                "pred__jlinear": actual_linear + [0.001, 0.002, 0.003, 0.1],
                "quality__jlinear": [0.9, 0.8, 0.7, 0.6],
                "reliable__jlinear": [True] * 4,
                "pred__jdeg": actual_deg + 2.0,
                "quality__jdeg": [0.9, 0.8, 0.7, 0.6],
                "reliable__jdeg": [True] * 4,
                "pred__jwrapdeg": actual_wrapdeg + [-358.0, 358.0, 4.0, 45.0],
                "quality__jwrapdeg": [0.9, 0.8, 0.7, 0.6],
                "reliable__jwrapdeg": [True] * 4,
            })
            pred_path = folder / f"prediction_{trajectory}.csv"
            truth_path = folder / f"truth_{trajectory}.csv"
            prediction.to_csv(pred_path, index=False)
            truth.to_csv(truth_path, index=False)
            pairs.append(ValidationTrajectory(
                trajectory_id=f"heldout_{trajectory}",
                prediction_csv=pred_path, truth_csv=truth_path,
                capture_sha256=_digest(f"independent_capture_{trajectory}"),
                label_status="verified_hardware_sync", held_out_from_training=True,
            ))
        training_hash = _digest("training_capture")
        kwargs = {"training_capture_sha256": [training_hash]}
        policy = fit_policy(pairs, specs, limits, **kwargs)
        assert policy["validation_trajectory_count"] == 3
        assert policy["joints"]["jrad"]["quality_threshold"] == 0.7
        assert policy["joints"]["jrad"]["accepted_frames"] == 9
        assert abs(policy["joints"]["jrad"]["max_accepted_error"] - 0.04) < 1e-10
        assert policy["joints"]["jlinear"]["quality_threshold"] == 0.7
        assert policy["joints"]["jlinear"]["max_accepted_error"] <= 0.005
        assert policy["joints"]["jdeg"]["quality_threshold"] is None
        assert policy["joints"]["jdeg"]["accepted_frames"] == 0
        assert policy["joints"]["jwrapdeg"]["quality_threshold"] == 0.7
        assert policy["joints"]["jwrapdeg"]["max_accepted_error"] <= 5.0
        assert "no_statistical_guarantee" in policy["status"]

        policy_path = folder / "policy.json"
        policy_path.write_text(json.dumps(policy, indent=2), encoding="utf-8")
        output = apply_policy(policy_path, pairs[0].prediction_csv)
        assert output["empirical_reliable__jrad"].tolist() == [True, True, True, False]
        assert output["empirical_safe__jrad"].isna().sum() == 1
        assert not output["empirical_reliable__jdeg"].any()
        output.loc[0, "reliable__jrad"] = False
        gated = apply_policy(policy, output)
        assert not gated.loc[0, "empirical_reliable__jrad"]

        _must_reject(lambda: fit_policy(pairs[:2], specs, limits, **kwargs),
                     "At least three")
        _must_reject(lambda: fit_policy([pairs[0], pairs[1], pairs[0]], specs,
                                        limits, **kwargs), "trajectory_id")
        same_capture = replace(pairs[2], capture_sha256=pairs[0].capture_sha256)
        _must_reject(lambda: fit_policy([pairs[0], pairs[1], same_capture], specs,
                                        limits, **kwargs), "Duplicate or training capture")
        provisional = replace(pairs[2], label_status="provisional")
        _must_reject(lambda: fit_policy([pairs[0], pairs[1], provisional], specs,
                                        limits, **kwargs), "provisional/unverified")
        training_overlap = replace(pairs[2], capture_sha256=training_hash)
        _must_reject(lambda: fit_policy([pairs[0], pairs[1], training_overlap],
                                        specs, limits, **kwargs), "Duplicate or training capture")
        altered = json.loads(policy_path.read_text(encoding="utf-8"))
        altered["joints"]["jrad"]["quality_threshold"] = 0.0
        _must_reject(lambda: apply_policy(altered, pairs[0].prediction_csv),
                     "policy hash mismatch")

        print(json.dumps({
            "status": "ok",
            "independent_trajectories": 3,
            "continuous_rad_threshold": policy["joints"]["jrad"]["quality_threshold"],
            "continuous_rad_max_error": policy["joints"]["jrad"]["max_accepted_error"],
            "linear_m_threshold": policy["joints"]["jlinear"]["quality_threshold"],
            "deg_joint_abstains": policy["joints"]["jdeg"]["quality_threshold"] is None,
        }, indent=2))


if __name__ == "__main__":
    main()
