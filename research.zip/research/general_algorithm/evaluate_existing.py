"""Exploratory two-video check of the generic trajectory estimator.

Both recordings and their provisional labels have already been inspected.
This is development feedback, not an independent performance estimate.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from trajectory import JointTrajectoryEstimator
from selection import ValidatedTrajectoryEstimator
from vision.frontend import CanonicalVideoFrontend, load_frame_directory


PROJECT = Path(__file__).resolve().parents[2]
CASES = {
    "Exp001": (PROJECT / "data/train/Exp001", "train_labels.csv"),
    "Exp002": (PROJECT / "data2/test/Exp002", "test_labels.csv"),
}
OUT = Path(__file__).resolve().parent


def measure(truth: np.ndarray, prediction: np.ndarray) -> dict:
    error = np.abs(truth - prediction)
    return {"mae": float(error.mean()),
            "per_joint_mae": error.mean(axis=0).tolist(),
            "per_joint_p95": np.percentile(error, 95, axis=0).tolist()}


def main() -> None:
    names = {}
    frames = {}
    labels = {}
    for name, (folder, label_name) in CASES.items():
        names[name], frames[name] = load_frame_directory(folder / "frames")
        table = pd.read_csv(folder / label_name)
        if list(table["image"]) != names[name]:
            raise ValueError(f"Frame/label mismatch: {name}")
        angle_names = [column for column in table if column.startswith("axis")]
        labels[name] = table[angle_names].to_numpy(dtype=np.float64)
    frontend = CanonicalVideoFrontend().fit_reference(frames["Exp001"])
    visual = {
        "Exp001": frontend.transform(frames["Exp001"], reference=True),
        "Exp002": frontend.transform(frames["Exp002"]),
    }
    if not all(result.usable for result in visual.values()):
        raise RuntimeError("Visual registration failed")
    results = []
    for source, target in (("Exp001", "Exp002"), ("Exp002", "Exp001")):
        x_source = visual[source]
        x_target = visual[target]
        target_y = labels[target]
        model = JointTrajectoryEstimator().fit(
            x_source.appearance, x_source.motion, labels[source],
            [f"joint_{j + 1}" for j in range(labels[source].shape[1])],
        )
        pred = model.predict(x_target.appearance, x_target.motion)
        selected_model = ValidatedTrajectoryEstimator().fit(
            x_source.appearance, x_source.motion, labels[source],
            [f"joint_{j + 1}" for j in range(labels[source].shape[1])],
        )
        selected_pred = selected_model.predict(x_target.appearance, x_target.motion)
        result = {
            "source": source,
            "target": target,
            "train_mean": measure(target_y, np.broadcast_to(labels[source].mean(axis=0), target_y.shape)),
            "absolute": measure(target_y, pred["absolute_observation"]),
            "fused": measure(target_y, pred["angles"]),
            "causal": measure(target_y, pred["causal_angles"]),
            "source_holdout_selected": measure(target_y, selected_pred["angles"]),
            "source_selected_modes": list(selected_model.selected_modes),
            "source_selection_split": selected_model.split,
            "reliable_fraction": float(pred["reliable"].mean()),
            "per_joint_reliable_fraction": pred["reliable"].mean(axis=0).tolist(),
            "quality_median": np.median(pred["quality"], axis=0).tolist(),
            "registration": x_target.registration,
        }
        results.append(result)
    report = {"status": "exploratory, provisional labels, both videos used in development",
              "joint_count": labels["Exp001"].shape[1], "results": results}
    (OUT / "evaluation_results.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
