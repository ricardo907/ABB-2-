"""Train, infer, probe, and evaluate the adaptable robot-arm estimator.

The method accepts any positive joint count with per-robot calibration data.
Its current visual frontend requires a matchable fixed scene; new scenes are
rejected. Video/log offset scans and uncertainty outputs are diagnostic, not
certified synchronization or statistical coverage guarantees.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from ensemble.offset_ensemble import OffsetHypothesis, OffsetHypothesisEnsemble, scenarios_from_scan
from protocol.provenance import build_provenance, hash_frames, provenance_path, sha256_file
from spec.urdf_chain import load_serial_chain
from sync.hardware_sync import aligned_frame_times, fit_clock_events, read_hardware_encoder
from sync.time_sync import extract_motion_trace, read_encoder_log, scan_offsets
from vlm.use_semantics import apply_visibility_gate, load_semantic_observations
from vision.frontend import (CanonicalVideoFrontend, iter_frame_directory,
                             list_frame_names, load_frame_directory, sample_video)


def _save_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _capture_session(manifest_path: Path | None, session_id: str | None) -> dict | None:
    if manifest_path is None:
        if session_id is not None:
            raise ValueError("--session-id needs --capture-manifest")
        return None
    if not session_id:
        raise ValueError("--capture-manifest needs --session-id")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    matches = [session for session in manifest.get("sessions", [])
               if session.get("session_id") == session_id]
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one manifest session_id={session_id!r}")
    return matches[0]


def _target_frame_times(path: Path, names: list[str]) -> tuple[np.ndarray, np.ndarray]:
    table = pd.read_csv(path)
    if "frame_index" not in table or "camera_time_ns" not in table:
        raise ValueError("Target timestamp CSV needs frame_index,camera_time_ns")
    indices = pd.to_numeric(table["frame_index"], errors="raise")
    camera = pd.to_numeric(table["camera_time_ns"], errors="raise")
    if (len(table) != len(names) or not np.issubdtype(indices.dtype, np.integer)
            or not np.issubdtype(camera.dtype, np.integer)
            or not np.array_equal(indices.to_numpy(), np.arange(len(names)))):
        raise ValueError("Target timestamps must contain one integer-indexed row per frame")
    if "image" in table and table["image"].tolist() != names:
        raise ValueError("Target timestamp image order differs from frame directory")
    camera_ns = camera.to_numpy(dtype=np.int64)
    if len(camera_ns) > 1 and np.any(np.diff(camera_ns) <= 0):
        raise ValueError("Target camera_time_ns must be strictly increasing")
    return (camera_ns - camera_ns[0]).astype(np.float64) / 1e9, camera_ns


def _attach_vlm_diagnostics(table: pd.DataFrame, report: dict, names: list[str],
                            joint_names: list[str], frames: Path,
                            camera_ns: np.ndarray | None) -> None:
    """Join diagnostic 2-D/numeric branches by frame identity, never by row count alone."""
    if report["joint_names"] != joint_names or report["frame_count"] != len(names):
        raise ValueError("VLM diagnostic joint order or frame count differs from main prediction")
    records = [json.loads(line) for line in Path(report["records_jsonl"]).read_text(
        encoding="utf-8").splitlines()]
    if len(records) != len(names):
        raise ValueError("VLM diagnostic JSONL frame count differs from input")
    for index, (record, name) in enumerate(zip(records, names)):
        if (record["frame_index"] != index or record["image"] != name or
                record["frame_sha256"] != sha256_file(frames / name)):
            raise ValueError(f"VLM diagnostic frame identity mismatch at {index}")
        if camera_ns is not None and record["timestamp_ns"] != int(camera_ns[index]):
            raise ValueError(f"VLM diagnostic camera timestamp mismatch at {index}")
    table["vlm_diagnostic_track_count"] = [record["tracked_joint_count"]
                                            for record in records]
    for joint_index, name in enumerate(joint_names):
        tracks = [record["tracks"][joint_index] for record in records]
        table[f"vlm_diagnostic_track_valid__{name}"] = [
            item["track_valid"] for item in tracks]
        table[f"vlm_diagnostic_u__{name}"] = [item["u_px"] for item in tracks]
        table[f"vlm_diagnostic_v__{name}"] = [item["v_px"] for item in tracks]
        table[f"vlm_diagnostic_track_quality__{name}"] = [
            item["quality"] for item in tracks]
        if report["regressor_predictions"] is not None:
            numeric = [record["regressor"]["joints"][joint_index]
                       for record in records]
            table[f"vlm_diagnostic_regressor_q__{name}"] = [
                item["diagnostic_q"] for item in numeric]
            table[f"vlm_diagnostic_regressor_supported_q__{name}"] = [
                item["source_supported_q"] for item in numeric]
        if report["urdf"] is not None:
            geometry = [record["geometry"] for record in records]
            table[f"vlm_diagnostic_geometry_q__{name}"] = [
                item["diagnostic_q"][joint_index] for item in geometry]
            table[f"vlm_diagnostic_geometry_observable__{name}"] = [
                item["observable_q"][joint_index] is not None for item in geometry]


def train(args) -> None:
    if args.frontend_mode == "causal":
        names = list_frame_names(args.frames)
        frames = None
        reference_frames = None
    else:
        names, frames = load_frame_directory(args.frames)
        if args.reference_frames is not None:
            _, reference_frames = load_frame_directory(args.reference_frames)
        else:
            reference_frames = frames
    hardware_pair = args.frame_timestamps is not None or args.sync_events is not None
    if hardware_pair:
        if args.frame_timestamps is None or args.sync_events is None:
            raise ValueError("Hardware sync needs both --frame-timestamps and --sync-events")
        if args.offsets is not None or args.sync_video is not None:
            raise ValueError("Hardware sync cannot be combined with provisional offsets or motion scan")
        if args.joint_columns is None:
            raise ValueError("Hardware encoder CSV needs ordered --joint-columns")
        times, log_angles, controller_origin_ns = read_hardware_encoder(
            args.encoder, args.joint_columns
        )
        log_names = list(args.joint_columns)
    else:
        times, log_angles, log_names = read_encoder_log(
            args.encoder, time_column=args.time_column, joint_columns=args.joint_columns
        )
    if args.urdf:
        spec = load_serial_chain(
            args.urdf, base_link=args.base_link, tip_link=args.tip_link,
            allow_branches=args.allow_branches,
        )
        if len(spec.joint_names) != len(log_names):
            raise ValueError("URDF active-joint count differs from encoder columns")
        if args.joint_columns is None and list(spec.joint_names) != log_names:
            raise ValueError(
                "Encoder names differ from URDF joints; pass --joint-columns in URDF chain order"
            )
        joint_names = list(spec.joint_names)
        joint_types = list(spec.joint_types)
        if args.joint_types is not None and args.joint_types != joint_types:
            raise ValueError("--joint-types conflicts with URDF joint types")
        limits = spec.joint_limits
        robot_spec = spec.to_dict()
    else:
        joint_names = list(log_names)
        joint_types = args.joint_types or ["revolute"] * len(joint_names)
        if len(joint_types) != len(joint_names):
            raise ValueError("--joint-types must match encoder joint count")
        limits = None
        robot_spec = None

    frame_times_s = None
    if hardware_pair:
        clock = fit_clock_events(args.sync_events)
        frame_times_s, sync_report = aligned_frame_times(
            args.frame_timestamps, names, times, controller_origin_ns, clock, args.fps,
            max_fit_residual_ms=args.max_sync_residual_ms,
            max_label_gap_ms=args.max_label_gap_ms,
        )
        hypotheses = [OffsetHypothesis(0.0)]
    elif args.offsets is not None:
        hypotheses = [OffsetHypothesis(float(offset)) for offset in args.offsets]
        sync_report = {"mode": "explicit unverified offsets",
                       "offsets_s": [item.offset_s for item in hypotheses]}
    else:
        if args.sync_video is None:
            raise ValueError("Pass --offsets or --sync-video for a provisional scan")
        trace = extract_motion_trace(args.sync_video)
        if trace["frame_count"] != len(names):
            raise ValueError("Sync video frame count differs from extracted frame directory")
        if abs(trace["fps"] - args.fps) > 0.01:
            raise ValueError("--fps differs from sync video FPS")
        scan = scan_offsets(
            trace, times, log_angles,
            lag_min_s=args.lag_min,
            lag_max_s=args.lag_max,
            window_s=(args.window_start, args.window_end)
            if args.window_start is not None else None,
            bootstrap_repeats=args.bootstrap,
        )
        hypotheses = scenarios_from_scan(scan)
        sync_report = {key: value for key, value in scan.items() if key != "candidates"}

    if args.frontend_mode == "causal":
        reference_dir = args.reference_frames or args.frames
        reference_names = list_frame_names(reference_dir)
        reference_content_hash = hash_frames(reference_dir, reference_names)
        frontend = CanonicalVideoFrontend().fit_reference_bounded(
            iter_frame_directory(reference_dir), max_frames=args.max_reference_frames
        )
        visual = frontend.transform_causal(
            iter_frame_directory(args.frames), reference=args.reference_frames is None
        )
    else:
        reference_names = None
        reference_content_hash = None
        frontend = CanonicalVideoFrontend().fit_reference(reference_frames)
        visual = frontend.transform(frames, reference=args.reference_frames is None)
    if not visual.usable:
        raise RuntimeError(f"Training video cannot register to reference: {visual.registration}")
    model = OffsetHypothesisEnsemble().fit(
        visual.appearance, visual.motion, args.fps, times, log_angles,
        joint_names, hypotheses, limits, joint_types, frame_times_s=frame_times_s,
    )
    bundle = {
        "frontend": frontend,
        "model": model,
        "joint_names": joint_names,
        "joint_types": joint_types,
        "joint_columns": log_names,
        "fps": args.fps,
        "frontend_mode": args.frontend_mode,
        "source_frames": str(args.frames),
        "reference_frames": str(args.reference_frames or args.frames),
        "reference_frames_resolved": str((args.reference_frames or args.frames).resolve()),
        "reference_frame_count": len(reference_names) if reference_names is not None else None,
        "reference_frames_sha256": reference_content_hash,
        "robot_spec": robot_spec,
        "sync_report": sync_report,
        "method_status": "research prototype; per-robot calibration; see sync_report for timestamp evidence",
    }
    args.model.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, args.model)
    report = {
        "model": str(args.model),
        "joint_count": len(joint_names),
        "joint_names": joint_names,
        "joint_types": joint_types,
        "joint_columns": log_names,
        "train_frames": len(names),
        "reference_frames": str(args.reference_frames or args.frames),
        "training_registration": visual.registration,
        "reference_frames_sha256": reference_content_hash,
        "fps": args.fps,
        "frontend_mode": args.frontend_mode,
        "hypotheses": model.hypotheses,
        "dropped_hypotheses": model.dropped_hypotheses,
        "sync_report": sync_report,
        "robot_spec": robot_spec,
        "limitation": "No cross-robot or cross-camera accuracy is established by this training run.",
    }
    _save_json(args.report or args.model.with_suffix(".report.json"), report)
    print(json.dumps({"model": str(args.model), "joint_count": len(joint_names),
                      "retained_hypotheses": len(model.hypotheses)}, ensure_ascii=False))


def infer(args) -> None:
    bundle = joblib.load(args.model)
    if not np.isfinite(args.fps) or args.fps <= 0:
        raise ValueError("--fps must be finite and positive")
    time_aware = all(hasattr(member, "reference_dt_s")
                     for member in bundle["model"].models)
    if not time_aware and abs(float(args.fps) - float(bundle["fps"])) > 0.01:
        raise ValueError("This older model needs the calibration FPS; retrain for time-aware inference")
    frontend_mode = bundle.get("frontend_mode", "offline")
    if (frontend_mode == "causal" and bundle.get("reference_frames_resolved") ==
            str(args.frames.resolve())):
        raise ValueError("Causal inference cannot use a reference fitted from the target recording")
    temporal_mode = ("causal" if frontend_mode == "causal" else "smoothed") if (
        args.temporal_mode == "auto") else args.temporal_mode
    if frontend_mode == "causal":
        names = list_frame_names(args.frames)
        frames = None
    else:
        names, frames = load_frame_directory(args.frames)
    if (frontend_mode == "causal" and bundle.get("reference_frame_count") == len(names)
            and bundle.get("reference_frames_sha256") == hash_frames(args.frames, names)):
        raise ValueError("Causal inference target frames duplicate the reference recording")
    session = _capture_session(args.capture_manifest, args.session_id)
    timestamp_path = args.frame_timestamps
    if session is not None:
        manifest_frames = Path(session["frames_path"])
        if not manifest_frames.is_absolute():
            manifest_frames = args.capture_manifest.parent / manifest_frames
        if manifest_frames.resolve() != args.frames.resolve():
            raise ValueError("--frames differs from capture manifest frames_path")
        manifest_timestamps = Path(session["frame_timestamps_path"])
        if not manifest_timestamps.is_absolute():
            manifest_timestamps = args.capture_manifest.parent / manifest_timestamps
        if timestamp_path is not None and timestamp_path.resolve() != manifest_timestamps.resolve():
            raise ValueError("--frame-timestamps differs from capture manifest")
        timestamp_path = manifest_timestamps
    frame_times_s, camera_ns = (None, None) if timestamp_path is None else _target_frame_times(
        timestamp_path, names
    )
    visual = (bundle["frontend"].transform_causal(iter_frame_directory(args.frames))
              if frontend_mode == "causal" else bundle["frontend"].transform(frames))
    status = {"model": str(args.model), "frames": str(args.frames),
              "frame_count": len(names), "registration": visual.registration,
              "usable": bool(visual.usable), "joint_names": bundle["joint_names"],
              "timestamp_source": str(timestamp_path) if timestamp_path is not None else "nominal_fps",
              "frontend_mode": frontend_mode,
              "temporal_mode": temporal_mode}
    if not visual.usable and visual.frame_usable is None:
        status["reason"] = "Scene could not be registered to calibrated source; angle prediction withheld"
    target_times = frame_times_s if frame_times_s is not None else np.arange(len(names)) / args.fps
    frame_usable = (visual.frame_usable if visual.frame_usable is not None else
                    np.full(len(names), bool(visual.usable), dtype=bool))
    status["registered_frame_count"] = int(frame_usable.sum())
    status["registered_fraction"] = float(frame_usable.mean())
    joints = len(bundle["joint_names"])
    result = {
        "angles": np.full((len(names), joints), np.nan),
        "safe_angles": np.full((len(names), joints), np.nan),
        "consensus_reliable": np.zeros((len(names), joints), dtype=bool),
        "weighted_quality": np.full((len(names), joints), np.nan),
        "timing_disagreement": np.full((len(names), joints), np.nan),
        "heuristic_sd": np.full((len(names), joints), np.nan),
        "frame_time_delta_s": np.r_[0.0, np.diff(target_times)],
    }
    valid_indices = np.flatnonzero(frame_usable)
    if len(valid_indices):
        breaks = np.flatnonzero(np.diff(valid_indices) > 1) + 1
        for block in np.split(valid_indices, breaks):
            first, last = int(block[0]), int(block[-1]) + 1
            prediction = bundle["model"].predict(
                visual.appearance[first:last], visual.motion[first:last],
                frame_times_s=target_times[first:last] if time_aware else None,
                temporal_mode=status["temporal_mode"],
            )
            for key in ("angles", "safe_angles", "consensus_reliable",
                        "weighted_quality", "timing_disagreement", "heuristic_sd"):
                result[key][first:last] = prediction[key]
    base_reliable = result["consensus_reliable"]
    reliable = base_reliable.copy()
    safe_angles = result["safe_angles"].copy()
    semantics = None
    if args.vlm_observations is not None:
        semantics = load_semantic_observations(
            args.vlm_observations, args.frames, names, bundle["joint_names"]
        )
        if args.vlm_mode == "gate":
            reliable = apply_visibility_gate(base_reliable, semantics)
            safe_angles[~reliable] = np.nan
        status["vlm"] = {
            "observations": str(args.vlm_observations),
            "mode": args.vlm_mode,
            "valid_keyframes": semantics["valid_keyframe_count"],
            "invalid_records": semantics["invalid_record_count"],
            "warning": "VLM visibility is an unvalidated semantic observation; gate only withholds values on annotated frames",
        }
    table = pd.DataFrame({"frame_index": np.arange(len(names)), "image": names})
    table["frame_time_delta_s"] = result["frame_time_delta_s"]
    if camera_ns is not None:
        table["camera_time_ns"] = camera_ns
    if semantics is not None:
        table["vlm_annotated_keyframe"] = semantics["annotated"]
    for index, name in enumerate(bundle["joint_names"]):
        table[f"pred__{name}"] = result["angles"][:, index]
        table[f"safe__{name}"] = safe_angles[:, index]
        table[f"reliable__{name}"] = reliable[:, index]
        if semantics is not None:
            table[f"base_reliable__{name}"] = base_reliable[:, index]
            table[f"vlm_visibility__{name}"] = semantics["visibility"][:, index]
            table[f"vlm_u__{name}"] = semantics["uv"][:, index, 0]
            table[f"vlm_v__{name}"] = semantics["uv"][:, index, 1]
        table[f"quality__{name}"] = result["weighted_quality"][:, index]
        table[f"timing_spread__{name}"] = result["timing_disagreement"][:, index]
        table[f"heuristic_sd__{name}"] = result["heuristic_sd"][:, index]
    if args.vlm_keyframes is not None:
        from vlm.diagnostic_pipeline import run_diagnostic_pipeline

        robot_id = args.vlm_robot_id or (session["robot_id"] if session else None)
        camera_id = args.vlm_camera_id or (session["camera_id"] if session else None)
        if not robot_id or not camera_id:
            raise ValueError("--vlm-keyframes needs robot and camera IDs or a capture manifest")
        diagnostic_dir = args.vlm_output_dir or args.output.parent / (
            args.output.stem + "_vlm_diagnostic")
        vlm_report = run_diagnostic_pipeline(
            args.frames, args.vlm_keyframes, diagnostic_dir,
            robot_id=robot_id, camera_id=camera_id, timestamp_file=timestamp_path,
            mask_dir=args.vlm_mask_dir, regressor_model=args.vlm_regressor_model,
            urdf=args.vlm_urdf, camera_json=args.vlm_camera_json,
            landmarks_json=args.vlm_landmarks_json,
            base_link=args.vlm_base_link, tip_link=args.vlm_tip_link,
        )
        _attach_vlm_diagnostics(table, vlm_report, names, bundle["joint_names"],
                                args.frames, camera_ns)
        status["vlm_diagnostic"] = {
            "report": str(diagnostic_dir / "diagnostic_report.json"),
            "records": vlm_report["records_jsonl"],
            "keyframes_sha256": vlm_report["keyframes_sha256"],
            "full_2d_frames": vlm_report["full_2d_frames"],
            "partial_2d_frames": vlm_report["partial_2d_frames"],
            "warning": "VLM tracks and numeric values are diagnostics; they do not upgrade safe or reliable outputs",
        }
    if args.reliability_policy is not None:
        from reliability.empirical_gate import apply_policy

        policy = json.loads(args.reliability_policy.read_text(encoding="utf-8"))
        if policy.get("joint_order") != bundle["joint_names"]:
            raise ValueError("Reliability policy joint order differs from the model")
        gated = apply_policy(args.reliability_policy, table)
        for name in bundle["joint_names"]:
            original = table[f"reliable__{name}"].to_numpy(dtype=bool)
            accepted = original & gated[f"empirical_reliable__{name}"].to_numpy(dtype=bool)
            table[f"base_reliable__{name}"] = original
            table[f"reliable__{name}"] = accepted
            table[f"safe__{name}"] = np.where(accepted, table[f"pred__{name}"], np.nan)
            table[f"empirical_reliable__{name}"] = accepted
            table[f"empirical_safe__{name}"] = table[f"safe__{name}"]
        status["reliability_policy"] = {
            "path": str(args.reliability_policy),
            "sha256": sha256_file(args.reliability_policy),
            "warning": "Validation-set empirical gate only; no future coverage or error guarantee",
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.output, index=False)
    if session is not None:
        provenance = build_provenance(session, args.capture_manifest.parent, args.frames,
                                      args.model, args.output, names)
        _save_json(provenance_path(args.output), provenance)
        status["provenance_sidecar"] = str(provenance_path(args.output))
    status["prediction_csv"] = str(args.output)
    status["reliable_fraction_by_joint"] = [
        float(table[f"reliable__{name}"].mean()) for name in bundle["joint_names"]
    ]
    status["warning"] = "Unreliable cells are blank in safe__ columns; pred__ values are diagnostics only"
    _save_json(args.output.with_suffix(".status.json"), status)
    print(json.dumps(status, ensure_ascii=False))


def probe(args) -> None:
    bundle = joblib.load(args.model)
    frames = sample_video(args.video, samples=args.samples)
    visual = (bundle["frontend"].transform_causal(frames)
              if bundle.get("frontend_mode", "offline") == "causal" else
              bundle["frontend"].transform(frames))
    report = {"video": str(args.video), "samples": len(frames),
              "registration": visual.registration, "usable": bool(visual.usable),
              "warning": "Appearance probe only; no joint-angle accuracy can be measured without labels"}
    _save_json(args.output, report)
    print(json.dumps(report, ensure_ascii=False))


def evaluate(args) -> None:
    pred = pd.read_csv(args.predictions)
    labels = pd.read_csv(args.labels)
    if "image" not in pred or "image" not in labels:
        raise ValueError("Both files need an image column")
    pred_cols = [column for column in pred if column.startswith("pred__")]
    joint_names = [column.removeprefix("pred__") for column in pred_cols]
    if not joint_names:
        raise ValueError("Prediction CSV has no pred__ joint columns")
    if args.label_columns:
        label_cols = args.label_columns
    elif all(name in labels for name in joint_names):
        label_cols = joint_names
    elif all(f"joint_{i}" in labels for i in range(1, len(joint_names) + 1)):
        label_cols = [f"joint_{i}" for i in range(1, len(joint_names) + 1)]
    elif all(f"axis{i}" in labels for i in range(1, len(joint_names) + 1)):
        label_cols = [f"axis{i}" for i in range(1, len(joint_names) + 1)]
    else:
        raise ValueError("Pass --label-columns in the same order as the model joints")
    if len(label_cols) != len(joint_names):
        raise ValueError("Label column count differs from prediction joint count")
    spec = None
    if args.urdf is not None:
        spec = load_serial_chain(args.urdf, base_link=args.base_link, tip_link=args.tip_link,
                                 allow_branches=args.allow_branches)
        if list(spec.joint_names) != joint_names:
            raise ValueError("URDF joint order must equal prediction joint names for FK evaluation")
    joint_types = list(spec.joint_types) if spec is not None else (
        args.joint_types or ["revolute"] * len(joint_names)
    )
    if len(joint_types) != len(joint_names):
        raise ValueError("Joint type count differs from prediction joint count")
    if spec is not None and args.joint_types is not None and args.joint_types != joint_types:
        raise ValueError("--joint-types conflicts with URDF joint types")
    merged = pred.merge(labels[["image", *label_cols]], on="image", how="inner", validate="one_to_one")
    if merged.empty:
        raise ValueError("No image names shared by predictions and labels")
    actual = merged[label_cols].to_numpy(dtype=np.float64)
    output = merged[pred_cols].to_numpy(dtype=np.float64)
    if not np.isfinite(actual).all() or np.isinf(output).any():
        raise ValueError("Matched labels must be finite; raw predictions cannot be infinite")
    raw_available = np.isfinite(output)
    error = np.abs(actual - output)
    for index, kind in enumerate(joint_types):
        if kind == "continuous":
            delta = actual[:, index] - output[:, index]
            error[:, index] = np.abs(np.arctan2(np.sin(delta), np.cos(delta)))
    reliable = merged[[f"reliable__{name}" for name in joint_names]].to_numpy(dtype=bool)
    if np.any(reliable & ~raw_available):
        raise ValueError("A missing raw prediction cannot be marked reliable")
    raw_mae = [float(error[raw_available[:, j], j].mean())
               if raw_available[:, j].any() else None for j in range(len(joint_names))]
    raw_p95 = [float(np.percentile(error[raw_available[:, j], j], 95))
               if raw_available[:, j].any() else None for j in range(len(joint_names))]
    conditional_mae = [float(error[reliable[:, j], j].mean()) if reliable[:, j].any() else None
                       for j in range(len(joint_names))]
    conditional_p95 = [float(np.percentile(error[reliable[:, j], j], 95))
                       if reliable[:, j].any() else None for j in range(len(joint_names))]
    units = ["m" if kind == "prismatic" else "rad" for kind in joint_types]
    report = {
        "label_status": args.label_status,
        "warning": "Provisional labels are development diagnostics, not verified accuracy"
        if args.label_status == "provisional" else
        "Verified is a user declaration; this evaluator cannot check physical trigger wiring or label provenance",
        "matched_frames": len(merged),
        "raw_coverage_by_joint": raw_available.mean(axis=0).tolist(),
        "raw_complete_frame_fraction": float(np.all(raw_available, axis=1).mean()),
        "joint_names": joint_names,
        "joint_types": joint_types,
        "joint_units": units,
        "raw_mae_overall": (float(np.nanmean(error)) if raw_available.any() else None)
        if len(set(units)) == 1 else None,
        "raw_mae_by_joint": raw_mae,
        "raw_p95_by_joint": raw_p95,
        "reliable_fraction_by_joint": reliable.mean(axis=0).tolist(),
        "reliable_joint_frame_count_by_joint": reliable.sum(axis=0).tolist(),
        "reliable_only_mae_by_joint": conditional_mae,
        "reliable_only_p95_by_joint": conditional_p95,
    }
    if len(set(units)) > 1:
        report["overall_mae_note"] = "Mixed radian/metre joints: report per-joint errors only"
    if spec is not None:
        position_error = []
        orientation_error = []
        for true_row, predicted_row in zip(actual[np.all(raw_available, axis=1)],
                                           output[np.all(raw_available, axis=1)]):
            true_pose = spec.forward_kinematics(true_row)
            predicted_pose = spec.forward_kinematics(predicted_row)
            position_error.append(float(np.linalg.norm(true_pose[:3, 3] - predicted_pose[:3, 3])))
            relative_rotation = true_pose[:3, :3].T @ predicted_pose[:3, :3]
            cosine = float(np.clip((np.trace(relative_rotation) - 1.0) / 2.0, -1.0, 1.0))
            orientation_error.append(float(np.arccos(cosine)))
        report["end_effector_fk"] = {
            "complete_frame_count": len(position_error),
            "position_mae_m": float(np.mean(position_error)) if position_error else None,
            "position_p95_m": float(np.percentile(position_error, 95)) if position_error else None,
            "orientation_mae_rad": float(np.mean(orientation_error)) if orientation_error else None,
            "orientation_p95_rad": float(np.percentile(orientation_error, 95)) if orientation_error else None,
            "limitation": "FK discrepancy is measured against the supplied labels, which may be provisional",
        }
    _save_json(args.output, report)
    print(json.dumps(report, ensure_ascii=False))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    p = actions.add_parser("train", help="Fit one robot from ordered frames and encoder log")
    p.add_argument("--frames", type=Path, required=True)
    p.add_argument("--reference-frames", type=Path,
                   help="Optional unlabeled canonical scene frames; must register with training video")
    p.add_argument("--encoder", type=Path, required=True)
    p.add_argument("--fps", type=float, required=True)
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--report", type=Path)
    p.add_argument("--time-column", default="Time(s)")
    p.add_argument("--joint-columns", nargs="+")
    p.add_argument("--joint-types", nargs="+",
                   choices=("revolute", "continuous", "prismatic"),
                   help="Required for non-revolute joints when no URDF is provided")
    p.add_argument("--urdf", type=Path)
    p.add_argument("--base-link")
    p.add_argument("--tip-link")
    p.add_argument("--allow-branches", action="store_true")
    p.add_argument("--offsets", nargs="+", type=float)
    p.add_argument("--sync-video", type=Path)
    p.add_argument("--frame-timestamps", type=Path,
                   help="CSV: frame_index,camera_time_ns,trigger_id for paired hardware timestamps")
    p.add_argument("--sync-events", type=Path,
                   help="CSV: event_id,camera_time_ns,controller_time_ns; needs 3+ pulses")
    p.add_argument("--max-sync-residual-ms", type=float, default=2.0,
                   help="Project-defined clock-fit p95 limit, not a T-RO rule")
    p.add_argument("--max-label-gap-ms", type=float, default=10.0,
                   help="Project-defined nearest encoder-sample p95 limit")
    p.add_argument("--lag-min", type=float, default=-1.5)
    p.add_argument("--lag-max", type=float, default=1.5)
    p.add_argument("--window-start", type=float)
    p.add_argument("--window-end", type=float)
    p.add_argument("--bootstrap", type=int, default=200)
    p.add_argument("--frontend-mode", choices=("offline", "causal"), default="offline",
                   help="Causal mode streams frames and uses no future target frames")
    p.add_argument("--max-reference-frames", type=int, default=64,
                   help="Maximum calibration frames retained for causal reference median")
    p.set_defaults(function=train)
    p = actions.add_parser("infer", help="Infer another frame directory or abstain")
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--frames", type=Path, required=True)
    p.add_argument("--fps", type=float, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--temporal-mode", choices=("auto", "causal", "smoothed"),
                   default="auto", help="Auto selects causal for causal features, otherwise smoothed")
    p.add_argument("--frame-timestamps", type=Path,
                   help="Optional target CSV: frame_index,camera_time_ns[,image]")
    p.add_argument("--capture-manifest", type=Path,
                   help="Capture manifest for strict prediction provenance; requires --session-id")
    p.add_argument("--session-id", help="Manifest session to bind the prediction to")
    p.add_argument("--vlm-observations", type=Path,
                   help="Optional semantic keyframe JSON with matching image hashes and joint order")
    p.add_argument("--vlm-mode", choices=("diagnostic", "gate"), default="diagnostic",
                   help="Gate can only withhold safe values on annotated keyframes")
    p.add_argument("--vlm-keyframes", type=Path,
                   help="Run provenance-checked semantic tracking and numeric diagnostic branches")
    p.add_argument("--vlm-output-dir", type=Path)
    p.add_argument("--vlm-robot-id")
    p.add_argument("--vlm-camera-id")
    p.add_argument("--vlm-mask-dir", type=Path)
    p.add_argument("--vlm-regressor-model", type=Path)
    p.add_argument("--vlm-urdf", type=Path)
    p.add_argument("--vlm-camera-json", type=Path)
    p.add_argument("--vlm-landmarks-json", type=Path)
    p.add_argument("--vlm-base-link")
    p.add_argument("--vlm-tip-link")
    p.add_argument("--reliability-policy", type=Path,
                   help="Optional empirical gate fitted on independent verified validation trajectories")
    p.set_defaults(function=infer)
    p = actions.add_parser("probe", help="Check an unlabeled video for scene support")
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--video", type=Path, required=True)
    p.add_argument("--samples", type=int, default=30)
    p.add_argument("--output", type=Path, required=True)
    p.set_defaults(function=probe)
    p = actions.add_parser("evaluate", help="Evaluate a prediction CSV against matched labels")
    p.add_argument("--predictions", type=Path, required=True)
    p.add_argument("--labels", type=Path, required=True)
    p.add_argument("--label-columns", nargs="+")
    p.add_argument("--label-status", choices=("provisional", "verified"), required=True)
    p.add_argument("--joint-types", nargs="+",
                   choices=("revolute", "continuous", "prismatic"),
                   help="Needed without URDF to score continuous/prismatic joints correctly")
    p.add_argument("--urdf", type=Path)
    p.add_argument("--base-link")
    p.add_argument("--tip-link")
    p.add_argument("--allow-branches", action="store_true")
    p.add_argument("--output", type=Path, required=True)
    p.set_defaults(function=evaluate)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.action == "train" and (args.window_start is None) != (args.window_end is None):
        parser.error("Pass both --window-start and --window-end")
    if args.action == "train" and args.offsets is not None and args.sync_video is not None:
        parser.error("Choose explicit --offsets or --sync-video, not both")
    if args.action == "infer" and args.vlm_mode == "gate" and args.vlm_observations is None:
        parser.error("--vlm-mode gate needs --vlm-observations")
    if args.action == "infer" and args.vlm_keyframes is None and any(
        getattr(args, name) is not None for name in (
            "vlm_output_dir", "vlm_robot_id", "vlm_camera_id", "vlm_mask_dir",
            "vlm_regressor_model", "vlm_urdf", "vlm_camera_json",
            "vlm_landmarks_json", "vlm_base_link", "vlm_tip_link"
        )
    ):
        parser.error("VLM diagnostic options need --vlm-keyframes")
    args.function(args)


if __name__ == "__main__":
    main()
