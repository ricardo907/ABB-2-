# 可变关节数机械臂视频估角算法原型

这是一次**完整的软件算法原型**：训练、视频/编码器时间偏移诊断、硬件脉冲时间映射、视频配准、逐关节角度估计、时序融合、拒答、URDF 串联关节适配、多标定视频专家库和评估入口均可运行。代码不写死 ABB 型号或六轴数量。它需要**每台机械臂自己的同步标定视频与关节日志**；当前素材不能证明一个模型对所有未见机械臂零样本有效，也不能证明这是文献中的首创方法。[T-RO 投稿准备状态](../TRO_readiness.md)列出尚缺的研究证据。

## 输入与输出

- 每台机械臂：按时间排序的视频帧、实际帧率、带时间列的编码器日志；建议提供 URDF、串联链的 base/tip、相机/编码器共同触发标记。
- 训练时日志关节列的顺序必须与 URDF 选中链的关节顺序一致；名称不一致时必须用 `--joint-columns` 按 URDF 顺序显式指定。关节数可以变化，支持转动、连续转动和直线关节；没有 URDF 时非转动关节需显式传 `--joint-types`。URDF 模块对并联机构、模仿关节和未指定的分支明确拒绝。
- 推理输出每关节的原始诊断角度、保守角度、可观测/可靠标记、时间假设分歧。证据不足时 `safe__...` 为空；原始数值不可用于机器人控制。

```mermaid
flowchart LR
    A[视频与编码器日志] --> B[时间偏移候选]
    A --> C[视频背景配准与运动特征]
    B --> D[各偏移的角度模型]
    C --> D
    D --> E[逐关节时序估计]
    E --> F[视觉可观测度与偏移分歧]
    F --> G[可靠角度或拒答]
```

## 算法步骤

1. **弱时间对齐。** 在固定公共时间窗口比较视频运动量与任意数量关节的编码器速度，保留相关峰、分块稳定性和原始零偏移作为敏感性情景。仅在日志时间覆盖的帧训练。相关峰**不是**经硬件确认的同步时刻，情景权重也不是后验概率。
2. **无标签视觉前端。** 默认离线模式用完整视频中值背景做 ORB/RANSAC 注册；新增 `--frontend-mode causal` 用标定视频拟合固定参考并逐帧配准，只保留有限张参考帧，不读取未来目标画面。每帧配准失败时该帧拒答，成功的连续片段独立预测。可选机械臂掩码描述子是独立特征接口，尚未接入主模型；两种已接入模式都仍依赖可配准的场景。
3. **双观测轨迹模型。** 对每个时间偏移情景，分别回归绝对关节位置和按实际帧间隔归一的关节增量；预测时按真实 `Δt` 积分，并对过长帧间隔拒答。因果模式只用前向滤波，离线模式可用后向平滑。局部视觉近邻的同像异角离散程度仍只是启发式可观测性指标。
4. **偏移分歧与拒答。** 汇总多个偏移情景的角度及分歧；仅当视觉邻域和情景一致性均达到规则阈值时给出 `safe__` 值。输出的标准差是启发式量，**没有统计覆盖率保证**。
5. **机器人适配。** 可选 URDF 提供可变关节顺序、类型、限位和正运动学；同一实体机械臂可为不同已标定机位添加专家，逐关节融合。没有 URDF 时合并专家必须显式确认属于同一台机器人。

各模块：`pipeline.py`（端到端入口）、`trajectory.py`（双观测时序模型）、`ensemble/offset_ensemble.py`（偏移情景）、`vision/frontend.py`（视觉前端）、`sync/time_sync.py`（弱时间诊断）、`sync/hardware_sync.py`（硬件脉冲映射）、`spec/urdf_chain.py`（URDF/FK）、`bank/expert_bank.py`（多视频专家库）、`adaptation/`（同一机器人目标机位短标定）、`protocol/`（采集、来源校验和留出测试）、`reliability/`（独立验证轨迹经验门控）、`vlm/`（关键帧语义、二维跟踪与数值诊断）。

## 用现有视频检验的结果

| 检查 | 结果 | 含义 |
| --- | --- | --- |
| 24/30 fps、4 关节合成时间信号 | 隐藏偏移恢复到一帧内 | 只验证对齐代码的计算行为 |
| 3/7 关节、连续关节、URDF 正运动学 | 合成自检通过 | 验证接口可变维数和几何计算 |
| 一个可见关节、一个视觉中不可见关节的合成样本 | 可靠输出比例 1.00 / 0.14 | 验证逐关节拒答机制；不是现实覆盖率 |
| 原离线 Exp001 → Exp002 / 反向 | 暂定原始诊断 MAE 0.453 / 0.372 rad；可靠输出均 0% | 两段视频已用于开发，且未硬件同步 |
| 新因果 Exp001 → Exp002 / 反向 | 暂定原始诊断 MAE 0.405 / 0.553 rad；可靠输出均 0% | 一个方向变好、一个变差；反向固定参考只用训练视频，避免目标参考泄漏 |
| 另外 9 段无标签视频 | 新因果前端抽样 270 帧，配准成功 0 帧 | 场景迁移仍是主要失败点；不能计算角度误差 |
| 目标机位前 25% 帧短标定 | 两折尾段暂定 MAE 从 0.550/0.516 降到 0.465/0.247 rad | 同一机器人身份与同步未确认；只是开发诊断 |
| 名义 90% 残差区间 | 两折尾段经验覆盖率仅 19.0%/48.4% | 当前不确定度不能声称已校准 |

**当前算法没有在真实视频上稳定优于前一版受约束回归基线。** 新因果路径解决了未来目标帧参与背景计算的代码问题，但没有解决跨场景数值精度。现有 Exp001/Exp002 首帧对应日志 0 秒的假设未被验证；Exp002 末段的画面/角度矛盾见上层 `research/README.md`。因此表中的 MAE 不是可信的真实估角精度，`safe__` 也不是已验证的控制安全保证。`examples/` 中的权重、预测与评估文件均标为 `provisional` 或 `diagnostic`。

## 运行

在 `ABB_Cup_2` 目录执行：

```powershell
python -m pip install -r research/general_algorithm/requirements.txt
python research/general_algorithm/check_tracker_synthetic.py
python research/general_algorithm/sync/selfcheck.py
python research/general_algorithm/spec/selfcheck.py
python research/general_algorithm/ensemble/selfcheck.py
python research/general_algorithm/bank/selfcheck_bank.py

python research/general_algorithm/pipeline.py train `
  --frames data/train/Exp001/frames `
  --encoder data/train/Exp001/Train_Angle1_real.xlsx `
  --fps 24 --sync-video data/train/Exp001/Train_Angle1_real.mp4 `
  --window-start 1.6 --window-end 7.5 `
  --model research/general_algorithm/examples/exp001_model_provisional.joblib

python research/general_algorithm/pipeline.py infer `
  --model research/general_algorithm/examples/exp001_model_provisional.joblib `
  --frames data2/test/Exp002/frames --fps 24 `
  --output research/general_algorithm/examples/exp001_to_exp002_diagnostic.csv

python research/general_algorithm/pipeline.py evaluate `
  --predictions research/general_algorithm/examples/exp001_to_exp002_diagnostic.csv `
  --labels data2/test/Exp002/test_labels.csv --label-status provisional `
  --output research/general_algorithm/examples/exp001_to_exp002_evaluation.json
```

对新机械臂，先用其真实编码器日志和标定视频重新执行 `train`，可加 `--urdf robot.urdf --base-link ... --tip-link ... --joint-columns ...`。多机位可在**确认同一机器人**后用 `bank/expert_bank.py create` 合并各机位模型。`pipeline.py probe` 和 `bank/expert_bank.py probe-video` 可先检查无标签视频的场景匹配；不能把抽帧检查当成估角精度。

长视频或需要因果计算的目标场景，可在训练命令加 `--frontend-mode causal --max-reference-frames 64`。模型会记录视觉模式，推理自动使用相同模式与因果滤波；程序逐帧解码但仍在整段特征算完后一次写出 CSV，尚未实现实时逐帧输出或测量端到端延迟。也可显式用 `--temporal-mode smoothed` 做离线诊断，此时使用未来帧。因果模型推理时禁止把**同一目标视频**拿来拟合参考背景。目标视频若有真实曝光时间戳，传 `--frame-timestamps frames.csv`（`frame_index,camera_time_ns[,image]`），模型按每段实际时差传播；无时间戳时才按 `--fps` 推算。旧版权重仍可读，但须保持原帧率，若要利用实际时差则需重新训练。

严格测试时，`infer` 加 `--capture-manifest manifest.json --session-id test_01`：它自动读取该 session 的帧时间戳，在预测 CSV 旁生成 `.provenance.json`，绑定模型、预测、原始视频、帧文件内容及顺序、编码器和同步事件。`protocol/evaluate_fold.py` 会重算这些哈希并拒绝来源不符、时间缺口过大或评估泄漏；没有硬件同步的现有视频不能通过严格准确率协议。

新采集数据可采用 `protocol/README.md` 的纳秒时间戳格式。先运行 `protocol/validate_dataset.py`，再使用 `pipeline.py train --frame-timestamps ... --sync-events ... --encoder ... --joint-columns ...`；训练会拟合相机/控制器时钟并拒绝明显丢触发、采样间隙和视频帧率不符。拟合残差不能代替对物理接线的独立检查。`pipeline.py evaluate` 对连续关节使用周期误差，混合转动/直线关节只给逐关节误差。

VLM 的稀疏关键帧模块见 `vlm/README.md`。`pipeline.py infer --vlm-observations ... --vlm-mode diagnostic` 只记录语义；`--vlm-mode gate` 可在已标注关键帧撤回被判断为遮挡/未知的关节输出。新接口 `--vlm-keyframes keyframes.json --vlm-robot-id ... --vlm-camera-id ...` 会运行语义关键帧→二维跟踪→可选数值回归/几何求解，并将 `vlm_diagnostic_*` 列加入同一预测 CSV；可选 `--vlm-mask-dir`、`--vlm-regressor-model`、`--vlm-urdf --vlm-camera-json`。所有加入的数值只供诊断，**不会提高 `safe__` 或 `reliable__`**。目前只有模拟语义记录的端到端自检，尚无真实 Qwen 权重推理或本数据集上的 VLM 数值收益证据。

`reliability/` 提供独立验证轨迹的逐关节经验质量门控。至少需要三条独立、硬件同步且未参与训练的轨迹；当前 Exp001/Exp002 暂定标签被接口拒绝。保存门控策略 JSON 后可在推理时加 `--reliability-policy policy.json`，进一步撤回不被验证集经验阈值支持的输出。验证集上的最大误差与覆盖率是描述统计，不是未来的置信保证。

## 研究边界

这套程序支持不同关节数和串联 URDF 的**接口适配**，当前视觉特征仍需要每台机器人、每个场景的带真值标定。单目画面对遮挡、轴对称或完全不可见的关节可能有多个合法角度，因而“所有机械臂、所有帧都能唯一准确估角”无法成立；系统通过逐关节拒答表达这一点。已有 [RoboPose](https://openaccess.thecvf.com/content/CVPR2021/papers/Labbe_Single-View_Robot_Pose_and_Joint_Angle_Estimation_via_Render__CVPR_2021_paper.pdf)、[RoboTAG](https://openaccess.thecvf.com/content/CVPR2026/papers/Liu_RoboTAG_End-to-end_Robot_Pose_Estimation_via_Topological_Alignment_Graph_CVPR_2026_paper.pdf) 和 [SyncHeC](https://arxiv.org/abs/2611.02999) 涉及多机器人视觉估角、无标签适配或时间标定；当前组合的新颖性与优越性尚未证明。

要验证跨机械臂能力，必须用不同品牌、关节数、结构和相机视角的**独立机器人留出测试**，并先确保编码器/相机硬件同步。应报告每关节误差、末端 FK 误差、拒答覆盖率与覆盖后的误差，而不是仅报告平均 MAE。当前原型不能作为达到 Transactions 投稿标准的结论。
