"""Check variable joint counts and the two-observation filter on known signals."""

import numpy as np

from trajectory import JointTrajectoryEstimator


def one_case(joints: int) -> dict:
    rng = np.random.default_rng(17 + joints)
    count = 320
    time = np.arange(count) / 24.0
    truth = np.stack([
        0.4 * np.sin((1.2 + index * 0.08) * time + index * 0.3)
        + 0.1 * np.cos((2.1 + index * 0.04) * time)
        for index in range(joints)
    ], axis=1)
    appearance = np.c_[truth + rng.normal(0, 0.09, truth.shape),
                       np.sin(truth) + rng.normal(0, 0.09, truth.shape)]
    increments = np.diff(truth, axis=0, prepend=truth[[0]])
    motion = np.c_[increments + rng.normal(0, 0.015, truth.shape),
                   increments * 0.5 + rng.normal(0, 0.015, truth.shape)]
    train = slice(0, 180)
    test = slice(180, None)
    model = JointTrajectoryEstimator().fit(
        appearance[train], motion[train], truth[train],
        [f"joint_{index + 1}" for index in range(joints)],
    )
    result = model.predict(appearance[test], motion[test])
    assert result["angles"].shape == (count - 180, joints)
    assert result["quality"].shape == (count - 180, joints)
    assert np.isfinite(result["angles"]).all()
    absolute_mae = float(np.abs(result["absolute_observation"] - truth[test]).mean())
    fused_mae = float(np.abs(result["angles"] - truth[test]).mean())
    return {"joints": joints, "absolute_mae": absolute_mae,
            "fused_mae": fused_mae,
            "reliable_fraction": float(result["reliable"].mean())}


def hidden_joint_case() -> dict:
    rng = np.random.default_rng(123)
    train_count = 400
    test_count = 80
    visible_train = rng.uniform(-1, 1, train_count)
    visible_test = rng.uniform(-1, 1, test_count)
    hidden_train = rng.uniform(-1, 1, train_count)
    hidden_test = rng.uniform(-1, 1, test_count)
    train_angles = np.c_[visible_train, hidden_train]
    train_appearance = np.c_[visible_train, visible_train ** 2] + rng.normal(0, 0.02, (train_count, 2))
    test_appearance = np.c_[visible_test, visible_test ** 2] + rng.normal(0, 0.02, (test_count, 2))
    train_motion = np.c_[np.diff(visible_train, prepend=visible_train[0]), np.zeros(train_count)]
    test_motion = np.c_[np.diff(visible_test, prepend=visible_test[0]), np.zeros(test_count)]
    model = JointTrajectoryEstimator().fit(train_appearance, train_motion, train_angles,
                                           ["visible", "hidden"])
    output = model.predict(test_appearance, test_motion)
    reliable = output["reliable"].mean(axis=0)
    assert reliable[0] > reliable[1] + 0.25, reliable
    return {"observable_joint_reliable_fraction": float(reliable[0]),
            "hidden_joint_reliable_fraction": float(reliable[1]),
            "hidden_joint_target_count": len(hidden_test)}


def continuous_joint_case() -> dict:
    unwrapped = np.linspace(2.5, 4.5, 100)
    wrapped = (unwrapped + np.pi) % (2 * np.pi) - np.pi
    appearance = np.c_[np.sin(unwrapped), np.cos(unwrapped)]
    motion = np.diff(unwrapped, prepend=unwrapped[0])[:, None]
    model = JointTrajectoryEstimator().fit(
        appearance, motion, wrapped[:, None], ["wrist"], joint_types=["continuous"]
    )
    maximum_step = float(np.abs(np.diff(model.training_angles[:, 0])).max())
    assert maximum_step < 0.03, maximum_step
    return {"continuous_joint_max_training_step_rad": maximum_step}


if __name__ == "__main__":
    for count in (3, 7):
        print(one_case(count))
    print(hidden_joint_case())
    print(continuous_joint_case())
