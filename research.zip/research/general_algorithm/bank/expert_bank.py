"""Combine calibrated video experts for one identified robot.

This bank is adaptable to any positive joint count. It does not transfer a
trained expert to a robot with different kinematics, and scene registration
failure or low per-joint evidence causes abstention. The raw diagnostic output
is never a substitute for the blank-safe output.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Iterable

import joblib
import numpy as np
import pandas as pd


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from vision.frontend import gray_frames, load_frame_directory, sample_video  # noqa: E402


def _json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _spec_signature(spec: dict | None) -> str | None:
    if spec is None:
        return None
    # The geometry and chain order, rather than just a display name, identify
    # the calibrated serial robot. Drop a possible FK pose/result field.
    relevant = {key: spec.get(key) for key in (
        "robot_name", "base_link", "tip_link", "joint_names", "joint_types",
        "joint_limits", "chain",
    )}
    encoded = json.dumps(relevant, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def validate_experts(bundles: Iterable[dict], *, same_robot_confirmed: bool) -> dict:
    bundles = list(bundles)
    if not bundles:
        raise ValueError("At least one calibrated expert is required")
    first = bundles[0]
    names = tuple(first.get("joint_names", []))
    if not names or len(set(names)) != len(names):
        raise ValueError("Expert joint_names must be nonempty and unique")
    signatures = []
    for index, bundle in enumerate(bundles):
        current = tuple(bundle.get("joint_names", []))
        if current != names:
            raise ValueError(
                f"Expert {index} has different joint count, names or order; do not mix robots"
            )
        if "frontend" not in bundle or "model" not in bundle:
            raise ValueError(f"Expert {index} lacks a fitted frontend or model")
        if tuple(bundle["model"].joint_names) != names:
            raise ValueError(f"Expert {index} model joint order differs from bundle metadata")
        fps = float(bundle.get("fps", math.nan))
        if not math.isfinite(fps) or fps <= 0:
            raise ValueError(f"Expert {index} has no valid FPS")
        signatures.append(_spec_signature(bundle.get("robot_spec")))
    has_urdf = [signature is not None for signature in signatures]
    if any(has_urdf) and not all(has_urdf):
        raise ValueError("Do not mix URDF-identified experts with unidentified experts")
    if all(has_urdf):
        if len(set(signatures)) != 1:
            raise ValueError("URDF identities differ; experts belong to different robots")
        identity_mode = "matching URDF geometry"
    else:
        if not same_robot_confirmed:
            raise ValueError(
                "No URDF identity is available; pass --same-robot-confirmed only "
                "after verifying that the experts were calibrated on the same robot"
            )
        identity_mode = "same robot asserted by caller; software cannot verify identity without URDF"
    return {"joint_names": list(names), "joint_count": len(names),
            "identity_mode": identity_mode, "urdf_signature": signatures[0]}


def create_bank(expert_paths: list[Path], bank_path: Path, robot_id: str,
                *, same_robot_confirmed: bool) -> dict:
    if not robot_id.strip():
        raise ValueError("A nonempty robot_id is required")
    paths = [Path(path).resolve() for path in expert_paths]
    if len(set(paths)) != len(paths):
        raise ValueError("Duplicate expert paths are not useful")
    bundles = [joblib.load(path) for path in paths]
    identity = validate_experts(bundles, same_robot_confirmed=same_robot_confirmed)
    record = {"robot_id": robot_id, "expert_paths": [str(path) for path in paths],
              "bundles": bundles, "identity": identity,
              "scope": "multiple calibrated recordings of the same robot; no unseen-robot guarantee"}
    bank_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(record, bank_path)
    summary = {key: value for key, value in record.items() if key != "bundles"}
    summary["bank_path"] = str(bank_path.resolve())
    _json(bank_path.with_suffix(".metadata.json"), summary)
    return summary


def _registration_weight(details: dict) -> float:
    if details.get("status") != "ok":
        return 0.0
    if details.get("method") == "identity reference":
        return 1.0
    fraction = float(details.get("inlier_fraction", 0.0))
    inliers = float(details.get("ransac_inliers", 0.0))
    error = float(details.get("median_inlier_reprojection_px", math.inf))
    if not all(math.isfinite(value) for value in (fraction, inliers, error)):
        return 0.0
    return max(0.0, fraction) * min(1.0, inliers / 100.0) / (1.0 + max(0.0, error) / 3.0)


def infer_frames(bank: dict, frames: np.ndarray, fps: float) -> tuple[dict, dict]:
    """Return safe joint-wise fusion and diagnostic metadata for ordered frames."""
    if not math.isfinite(fps) or fps <= 0:
        raise ValueError("Target FPS must be positive")
    images = gray_frames(frames)
    names = tuple(bank["identity"]["joint_names"])
    count, joints = len(images), len(names)
    expert_reports = []
    registered_predictions = []
    for index, bundle in enumerate(bank["bundles"]):
        base = {"expert_index": index, "source_frames": bundle.get("source_frames"),
                "calibration_fps": float(bundle["fps"])}
        if abs(float(bundle["fps"]) - fps) > 0.01:
            expert_reports.append({**base, "status": "rejected",
                                   "reason": "target FPS differs from expert calibration FPS"})
            continue
        visual = bundle["frontend"].transform(images)
        if not visual.usable:
            expert_reports.append({**base, "status": "rejected",
                                   "reason": "scene registration failed",
                                   "registration": visual.registration})
            continue
        predictions = bundle["model"].predict(visual.appearance, visual.motion)
        registration_weight = _registration_weight(visual.registration)
        if registration_weight <= 0:
            expert_reports.append({**base, "status": "rejected",
                                   "reason": "invalid registration weight",
                                   "registration": visual.registration})
            continue
        if predictions["angles"].shape != (count, joints):
            raise ValueError(f"Expert {index} output has wrong joint count")
        registered_predictions.append((index, registration_weight, predictions))
        expert_reports.append({**base, "status": "registered",
                               "registration": visual.registration,
                               "registration_weight": registration_weight,
                               "reliable_fraction_by_joint":
                                   predictions["consensus_reliable"].mean(axis=0).tolist()})

    raw = np.full((count, joints), np.nan)
    safe = np.full((count, joints), np.nan)
    reliable = np.zeros((count, joints), dtype=bool)
    quality = np.zeros((count, joints), dtype=np.float64)
    selected_index = np.full((count, joints), -1, dtype=int)
    reliable_expert_count = np.zeros((count, joints), dtype=int)
    disagreement = np.full((count, joints), np.nan)
    if registered_predictions:
        values = np.stack([result["angles"] for _, _, result in registered_predictions])
        registration_weights = np.asarray([weight for _, weight, _ in registered_predictions])
        raw = np.average(values, axis=0, weights=registration_weights)
        evidence = np.stack([
            result["consensus_reliable"] for _, _, result in registered_predictions
        ])
        qualities = np.stack([
            result["weighted_quality"] for _, _, result in registered_predictions
        ])
        # Only experts that pass their own per-joint gate can contribute.
        weights = evidence * qualities * registration_weights[:, None, None]
        denominator = weights.sum(axis=0)
        reliable = denominator > 0
        reliable_expert_count = evidence.sum(axis=0)
        safe[reliable] = (weights * values).sum(axis=0)[reliable] / denominator[reliable]
        quality[reliable] = denominator[reliable] / registration_weights.sum()
        winner = np.argmax(weights, axis=0)
        indices = np.asarray([index for index, _, _ in registered_predictions])
        selected_index[reliable] = indices[winner[reliable]]
        disagreement[reliable] = np.sqrt((weights * (values - np.nan_to_num(safe)[None]) ** 2).sum(axis=0)[reliable]
                                         / denominator[reliable])
    result = {"raw_angles": raw, "safe_angles": safe,
              "reliable": reliable, "quality": quality,
              "selected_expert_index": selected_index,
              "reliable_expert_count": reliable_expert_count,
              "expert_disagreement": disagreement}
    status = {"robot_id": bank["robot_id"], "joint_names": list(names),
              "target_frames": count, "target_fps": fps,
              "registered_experts": len(registered_predictions),
              "reliable_fraction_by_joint": reliable.mean(axis=0).tolist(),
              "all_abstained": not bool(reliable.any()),
              "experts": expert_reports,
              "warning": "raw angles are diagnostics; safe angles are blank where evidence is insufficient"}
    return result, status


def _write_prediction_csv(path: Path, frame_names: list[str], result: dict,
                          joint_names: list[str]) -> None:
    table = pd.DataFrame({"image": frame_names})
    for axis, name in enumerate(joint_names):
        table[f"raw__{name}"] = result["raw_angles"][:, axis]
        table[f"safe__{name}"] = result["safe_angles"][:, axis]
        table[f"reliable__{name}"] = result["reliable"][:, axis]
        table[f"quality__{name}"] = result["quality"][:, axis]
        table[f"expert__{name}"] = result["selected_expert_index"][:, axis]
        table[f"expert_count__{name}"] = result["reliable_expert_count"][:, axis]
        table[f"expert_disagreement__{name}"] = result["expert_disagreement"][:, axis]
    path.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(path, index=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    make = actions.add_parser("create", help="Validate and combine same-robot calibrated experts")
    make.add_argument("--experts", type=Path, nargs="+", required=True)
    make.add_argument("--bank", type=Path, required=True)
    make.add_argument("--robot-id", required=True)
    make.add_argument("--same-robot-confirmed", action="store_true",
                      help="Required when experts have no URDF identity")
    predict = actions.add_parser("infer", help="Run all experts on an extracted frame directory")
    predict.add_argument("--bank", type=Path, required=True)
    predict.add_argument("--frames", type=Path, required=True)
    predict.add_argument("--fps", type=float, required=True)
    predict.add_argument("--output", type=Path, required=True)
    probe = actions.add_parser("probe-video", help="Check an unlabeled MP4 and abstain when unsupported")
    probe.add_argument("--bank", type=Path, required=True)
    probe.add_argument("--video", type=Path, required=True)
    probe.add_argument("--samples", type=int, default=30)
    probe.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.action == "create":
        report = create_bank(args.experts, args.bank, args.robot_id,
                             same_robot_confirmed=args.same_robot_confirmed)
    elif args.action == "infer":
        bank = joblib.load(args.bank)
        names, frames = load_frame_directory(args.frames)
        result, report = infer_frames(bank, frames, args.fps)
        _write_prediction_csv(args.output, names, result, bank["identity"]["joint_names"])
        report["prediction_csv"] = str(args.output)
        _json(args.output.with_suffix(".status.json"), report)
    else:
        bank = joblib.load(args.bank)
        frames = sample_video(args.video, samples=args.samples)
        # The sample spacing is not equivalent to the original video FPS.
        # Probe registration only: do not produce or evaluate angle predictions.
        registration = []
        for index, bundle in enumerate(bank["bundles"]):
            features = bundle["frontend"].transform(frames)
            registration.append({"expert_index": index,
                                 "registration": features.registration,
                                 "usable_scene": bool(features.usable)})
        report = {"video": str(args.video), "sampled_frames": len(frames),
                  "robot_id": bank["robot_id"], "registered_experts":
                      sum(item["usable_scene"] for item in registration),
                  "angle_output": "abstain; sparse probe has no valid motion FPS",
                  "experts": registration}
        _json(args.output, report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
