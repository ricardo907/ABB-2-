"""Check variable joint count and strict per-joint abstention without real labels."""

from dataclasses import dataclass

import numpy as np

from expert_bank import infer_frames


@dataclass
class MockVisual:
    appearance: np.ndarray
    motion: np.ndarray
    registration: dict
    usable: bool = True


class MockFrontend:
    def transform(self, frames):
        count = len(frames)
        return MockVisual(np.zeros((count, 2)), np.zeros((count, 2)),
                          {"status": "ok", "method": "identity reference"})


class MockModel:
    def __init__(self, joint_count, expert_index, reliable):
        self.joint_count = joint_count
        self.expert_index = expert_index
        self.reliable = reliable

    def predict(self, appearance, motion):
        count = len(appearance)
        return {
            "angles": np.full((count, self.joint_count), float(self.expert_index + 1)),
            "consensus_reliable": np.broadcast_to(self.reliable, (count, self.joint_count)),
            "weighted_quality": np.ones((count, self.joint_count)),
        }


def run_case(joints):
    names = [f"joint_{index}" for index in range(joints)]
    experts = []
    for index in (0, 1):
        reliable = np.asarray([(axis % 2) == index for axis in range(joints)])
        experts.append({"frontend": MockFrontend(),
                        "model": MockModel(joints, index, reliable),
                        "joint_names": names, "fps": 24.0})
    bank = {"robot_id": f"synthetic_{joints}", "identity": {"joint_names": names},
            "bundles": experts}
    result, status = infer_frames(bank, np.zeros((5, 40, 40), dtype=np.uint8), 24.0)
    assert result["safe_angles"].shape == (5, joints)
    assert result["reliable"].all()
    for axis in range(joints):
        assert np.allclose(result["safe_angles"][:, axis], 1.0 if axis % 2 == 0 else 2.0)
    assert not status["all_abstained"]
    # A timing/visual gate that rejects all experts must blank every safe angle.
    for bundle in experts:
        bundle["model"].reliable = np.zeros(joints, dtype=bool)
    result, status = infer_frames(bank, np.zeros((5, 40, 40), dtype=np.uint8), 24.0)
    assert np.isnan(result["safe_angles"]).all()
    assert status["all_abstained"]
    return {"joints": joints, "fusion_passed": True, "abstention_passed": True}


if __name__ == "__main__":
    print(run_case(3))
    print(run_case(7))
