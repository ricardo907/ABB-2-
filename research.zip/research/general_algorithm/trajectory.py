"""Robot-independent visual joint trajectory estimator.

This is a research prototype. The observation and transition regressors are
combined by a per-joint temporal filter whose observation weight depends on
local ambiguity in the visual training set. The uncertainty is heuristic,
not a calibrated coverage statement.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler


@dataclass(frozen=True)
class EstimatorConfig:
    absolute_alpha: float = 100.0
    transition_alpha: float = 100.0
    feature_z_limit: float = 5.0
    neighbor_count: int = 8
    pca_components: int = 12
    min_observation_sd: float = 0.10
    min_transition_sd: float = 0.02
    quality_threshold: float = 0.30
    distance_reject_factor: float = 3.0
    max_prediction_gap_factor: float = 3.0


def _check_features(name: str, values: np.ndarray, expected_rows: int | None = None) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] < 1:
        raise ValueError(f"{name} must be a nonempty 2D array")
    if expected_rows is not None and len(array) != expected_rows:
        raise ValueError(f"{name} has {len(array)} rows; expected {expected_rows}")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} has nonfinite values")
    return array


def _time_steps(frame_times_s: np.ndarray | None, count: int,
                default_step: float) -> tuple[np.ndarray, float]:
    """Return per-row elapsed time and a robust reference interval."""
    if frame_times_s is None:
        steps = np.full(count, default_step, dtype=np.float64)
        steps[0] = 0.0
        return steps, default_step
    times = np.asarray(frame_times_s, dtype=np.float64)
    if times.shape != (count,) or not np.isfinite(times).all():
        raise ValueError("frame_times_s must contain one finite timestamp per frame")
    if count > 1 and np.any(np.diff(times) <= 0):
        raise ValueError("frame_times_s must be strictly increasing")
    steps = np.r_[0.0, np.diff(times)]
    return steps, float(np.median(steps[1:])) if count > 1 else default_step


class JointTrajectoryEstimator:
    """Fit one calibrated arm; output length follows its joint names."""

    def __init__(self, config: EstimatorConfig = EstimatorConfig()):
        self.config = config
        self.fitted = False

    def fit(
        self,
        appearance: np.ndarray,
        motion: np.ndarray,
        angles: np.ndarray,
        joint_names: list[str],
        joint_limits: np.ndarray | None = None,
        joint_types: list[str] | tuple[str, ...] | None = None,
        *,
        frame_times_s: np.ndarray | None = None,
    ) -> "JointTrajectoryEstimator":
        y = _check_features("angles", angles)
        if len(y) < max(12, self.config.neighbor_count + 2):
            raise ValueError("At least 12 aligned training frames are required")
        if len(joint_names) != y.shape[1] or len(set(joint_names)) != len(joint_names):
            raise ValueError("joint_names must be unique and match the angle columns")
        if joint_types is None:
            joint_types = ["revolute"] * y.shape[1]
        if len(joint_types) != y.shape[1] or any(
            kind not in {"revolute", "continuous", "prismatic"} for kind in joint_types
        ):
            raise ValueError("joint_types must match the angles and use revolute/continuous/prismatic")
        y = y.copy()
        for index, kind in enumerate(joint_types):
            if kind == "continuous":
                y[:, index] = np.unwrap(y[:, index])
        x_abs = _check_features("appearance", appearance, len(y))
        x_motion = _check_features("motion", motion, len(y))
        steps, self.reference_dt_s = _time_steps(frame_times_s, len(y), 1.0)
        if self.reference_dt_s <= 0 or not np.isfinite(self.reference_dt_s):
            raise ValueError("The reference frame interval must be positive")
        valid_transition = steps[1:] <= self.config.max_prediction_gap_factor * self.reference_dt_s
        if np.count_nonzero(valid_transition) < 2:
            raise ValueError("Too few transitions remain after rejecting large timestamp gaps")
        normalized_motion = x_motion.copy()
        normalized_motion[1:] *= (self.reference_dt_s / steps[1:])[:, None]
        normalized_motion[0] = 0.0
        self.joint_names = tuple(joint_names)
        self.joint_types = tuple(joint_types)
        self.training_angles = y.copy()
        self.train_mean = y.mean(axis=0)
        self.train_min = y.min(axis=0)
        self.train_max = y.max(axis=0)
        self.global_joint_spread = np.maximum(np.std(y, axis=0), 0.05)
        self.absolute_scaler = StandardScaler().fit(x_abs)
        self.motion_scaler = StandardScaler().fit(normalized_motion[1:][valid_transition])
        z_abs = self._scale(self.absolute_scaler, x_abs)
        z_motion = self._scale(self.motion_scaler, normalized_motion)
        self.absolute_model = Ridge(alpha=self.config.absolute_alpha).fit(z_abs, y)
        increments = np.diff(y, axis=0) * (self.reference_dt_s / steps[1:])[:, None]
        self.transition_model = Ridge(alpha=self.config.transition_alpha).fit(
            z_motion[1:][valid_transition], increments[valid_transition]
        )
        absolute_residual = y - self.absolute_model.predict(z_abs)
        transition_residual = increments[valid_transition] - self.transition_model.predict(
            z_motion[1:][valid_transition]
        )
        self.observation_sd = np.maximum(
            np.sqrt(np.mean(absolute_residual ** 2, axis=0)),
            self.config.min_observation_sd,
        )
        self.transition_sd = np.maximum(
            np.sqrt(np.mean(transition_residual ** 2, axis=0)),
            self.config.min_transition_sd,
        )

        components = min(self.config.pca_components, len(y) - 1, z_abs.shape[1])
        self.pca = PCA(n_components=components, svd_solver="randomized", random_state=42)
        compact = self.pca.fit_transform(z_abs)
        k = min(self.config.neighbor_count, len(y) - 2)
        self.neighbors = NearestNeighbors(n_neighbors=k + 1).fit(compact)
        distances, indices = self.neighbors.kneighbors(compact)
        self.reference_distance = max(float(np.percentile(distances[:, 1], 90)), 1e-6)
        local_spread = np.std(y[indices[:, 1:]], axis=1)
        self.reference_spread = np.maximum(self.global_joint_spread, 1e-6)
        if joint_limits is not None:
            limits = np.asarray(joint_limits, dtype=np.float64)
            if limits.shape != (y.shape[1], 2) or np.any(limits[:, 0] >= limits[:, 1]):
                raise ValueError("joint_limits must have shape (joint_count, 2) with lower < upper")
            self.joint_limits = limits
        else:
            self.joint_limits = None
        self.fitted = True
        return self

    def _scale(self, scaler: StandardScaler, values: np.ndarray) -> np.ndarray:
        return np.clip(scaler.transform(values), -self.config.feature_z_limit,
                       self.config.feature_z_limit)

    def predict(self, appearance: np.ndarray, motion: np.ndarray, *,
                frame_times_s: np.ndarray | None = None) -> dict[str, np.ndarray]:
        if not self.fitted:
            raise RuntimeError("Fit the estimator before prediction")
        x_abs = _check_features("appearance", appearance)
        x_motion = _check_features("motion", motion, len(x_abs))
        reference_dt = getattr(self, "reference_dt_s", 1.0)
        steps, _ = _time_steps(frame_times_s, len(x_abs), reference_dt)
        normalized_motion = x_motion.copy()
        normalized_motion[1:] *= (reference_dt / steps[1:])[:, None]
        normalized_motion[0] = 0.0
        z_abs = self._scale(self.absolute_scaler, x_abs)
        z_motion = self._scale(self.motion_scaler, normalized_motion)
        observation = self.absolute_model.predict(z_abs)
        transition = self.transition_model.predict(z_motion)
        transition[1:] *= (steps[1:] / reference_dt)[:, None]
        transition[0] = 0.0

        compact = self.pca.transform(z_abs)
        distances, indices = self.neighbors.kneighbors(compact)
        nearest_distance = distances[:, 0]
        local_spread = np.std(self.training_angles[indices[:, :self.config.neighbor_count]], axis=1)
        quality = 1.0 / (
            1.0
            + (nearest_distance[:, None] / self.reference_distance) ** 2
            + 4.0 * (local_spread / self.reference_spread) ** 2
        )
        reliable = (
            (quality >= self.config.quality_threshold)
            & (nearest_distance[:, None] <=
               self.config.distance_reject_factor * self.reference_distance)
        )
        gap_factor = getattr(self.config, "max_prediction_gap_factor", 3.0)
        reliable[steps > gap_factor * reference_dt] = False

        count, joints = observation.shape
        filtered = np.empty_like(observation)
        variance = np.empty_like(observation)
        predicted = np.empty_like(observation)
        predicted_variance = np.empty_like(observation)
        observation_var = self.observation_sd[None, :] ** 2 / np.maximum(quality, 0.01)
        filtered[0] = observation[0]
        variance[0] = observation_var[0]
        predicted[0] = observation[0]
        predicted_variance[0] = observation_var[0]
        for index in range(1, count):
            prior = filtered[index - 1] + transition[index]
            process_var = self.transition_sd ** 2 * (steps[index] / reference_dt) ** 2
            prior_var = variance[index - 1] + process_var
            predicted[index] = prior
            predicted_variance[index] = prior_var
            gain = prior_var / (prior_var + observation_var[index])
            filtered[index] = prior + gain * (observation[index] - prior)
            variance[index] = (1.0 - gain) * prior_var
        smoothed = filtered.copy()
        smoothed_variance = variance.copy()
        for index in range(count - 2, -1, -1):
            smoothing_gain = variance[index] / predicted_variance[index + 1]
            smoothed[index] = filtered[index] + smoothing_gain * (
                smoothed[index + 1] - predicted[index + 1]
            )
            smoothed_variance[index] = variance[index] + smoothing_gain ** 2 * (
                smoothed_variance[index + 1] - predicted_variance[index + 1]
            )
        if self.joint_limits is not None:
            smoothed = np.clip(smoothed, self.joint_limits[:, 0], self.joint_limits[:, 1])
            filtered = np.clip(filtered, self.joint_limits[:, 0], self.joint_limits[:, 1])
        safe = smoothed.copy()
        safe[~reliable] = np.nan
        return {
            "angles": smoothed,
            "safe_angles": safe,
            "causal_angles": filtered,
            "causal_sd": np.sqrt(np.maximum(variance, 0.0)),
            "absolute_observation": observation,
            "predicted_increment": transition,
            "quality": quality,
            "reliable": reliable,
            "heuristic_sd": np.sqrt(np.maximum(smoothed_variance, 0.0)),
            "nearest_visual_distance": nearest_distance,
            "local_label_spread": local_spread,
            "frame_time_delta_s": steps,
        }

