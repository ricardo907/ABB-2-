"""Select absolute, causal, or offline estimates per joint on a time holdout."""

from __future__ import annotations

import math

import numpy as np

from trajectory import EstimatorConfig, JointTrajectoryEstimator


MODES = ("absolute_observation", "causal_angles", "angles")


class ValidatedTrajectoryEstimator:
    def __init__(self, config: EstimatorConfig = EstimatorConfig()):
        self.config = config
        self.fitted = False

    def fit(self, appearance: np.ndarray, motion: np.ndarray, angles: np.ndarray,
            joint_names: list[str], joint_limits: np.ndarray | None = None,
            joint_types: list[str] | tuple[str, ...] | None = None):
        count = len(angles)
        if count < 60:
            raise ValueError("At least 60 ordered labelled frames are needed for temporal selection")
        validation_count = math.ceil(count * 0.20)
        gap_count = math.ceil(count * 0.05)
        train_end = count - validation_count - gap_count
        if train_end < 12:
            raise ValueError("Too few training frames after holdout")
        provisional = JointTrajectoryEstimator(self.config).fit(
            appearance[:train_end], motion[:train_end], angles[:train_end],
            joint_names, joint_limits, joint_types,
        )
        validation = provisional.predict(appearance[-validation_count:], motion[-validation_count:])
        aligned_truth = np.asarray(angles, dtype=np.float64).copy()
        if joint_types is not None:
            for index, kind in enumerate(joint_types):
                if kind == "continuous":
                    aligned_truth[:, index] = np.unwrap(aligned_truth[:, index])
        true = aligned_truth[-validation_count:]
        losses = np.stack([
            np.abs(validation[mode] - true).mean(axis=0) for mode in MODES
        ])
        # Exact ties favor the simpler absolute observation.
        selected = np.argmin(losses, axis=0)
        self.selected_modes = tuple(MODES[index] for index in selected)
        self.validation_mae = {mode: losses[i].tolist() for i, mode in enumerate(MODES)}
        self.split = {"train": train_end, "gap": gap_count,
                      "validation": validation_count}
        self.model = JointTrajectoryEstimator(self.config).fit(
            appearance, motion, angles, joint_names, joint_limits, joint_types
        )
        self.joint_names = tuple(joint_names)
        self.fitted = True
        return self

    def predict(self, appearance: np.ndarray, motion: np.ndarray) -> dict[str, np.ndarray]:
        if not self.fitted:
            raise RuntimeError("Fit before prediction")
        result = self.model.predict(appearance, motion)
        selected = np.column_stack([
            result[mode][:, axis] for axis, mode in enumerate(self.selected_modes)
        ])
        safe = selected.copy()
        safe[~result["reliable"]] = np.nan
        result["angles"] = selected
        result["safe_angles"] = safe
        result["selected_modes"] = self.selected_modes
        return result
