"""Chronological residual-interval diagnostic for the target-view adapter.

The finite-sample split-conformal quantile is calculated correctly, but the
time-correlated frames and provisional labels violate the usual exchangeable
sample conditions. Reported coverage is empirical only and has no guarantee.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from target_calibration_adapter import (  # noqa: E402
    ALGORITHM, TargetCalibrationAdapter, _read_labels,
)

import sys

sys.path.insert(0, str(ALGORITHM))
from vision.frontend import CanonicalVideoFrontend, load_frame_directory  # noqa: E402


ROOT = Path(__file__).resolve().parents[3]
CASES = {
    "Exp001": (ROOT / "data/train/Exp001/frames", ROOT / "data/train/Exp001/train_labels.csv"),
    "Exp002": (ROOT / "data2/test/Exp002/frames", ROOT / "data2/test/Exp002/test_labels.csv"),
}
JOINTS = [f"axis{i}" for i in range(1, 7)]
FIT_FRACTION = 0.15
CALIBRATION_FRACTION = 0.10
GAP_FRACTION = 0.10
ALPHA = 0.10


def finite_sample_radius(residuals: np.ndarray, alpha: float) -> np.ndarray:
    errors = np.asarray(residuals, dtype=float)
    if errors.ndim != 2 or len(errors) < 1 or not np.isfinite(errors).all():
        raise ValueError("Expected finite nonempty calibration residuals")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    n = len(errors)
    rank = int(np.ceil((n + 1) * (1 - alpha)))
    # If rank > n, finite-sample conformal would use infinity. This diagnostic
    # deliberately refuses to report a misleading finite radius.
    if rank > n:
        return np.full(errors.shape[1], np.inf)
    return np.sort(errors, axis=0)[rank - 1]


def main() -> None:
    frames, labels = {}, {}
    for key, (folder, csv_path) in CASES.items():
        names, frames[key] = load_frame_directory(folder)
        labels[key] = _read_labels(csv_path, names, JOINTS)
    folds = []
    for source, target in (("Exp001", "Exp002"), ("Exp002", "Exp001")):
        frontend = CanonicalVideoFrontend().fit_reference(frames[source])
        xs = frontend.transform(frames[source], reference=True).appearance
        target_visual = frontend.transform(frames[target])
        if not target_visual.usable:
            raise RuntimeError(f"Registration failed: {target_visual.registration}")
        xt, yt = target_visual.appearance, labels[target]
        n = len(yt)
        fit_end = int(FIT_FRACTION * n)
        calibration_end = fit_end + int(CALIBRATION_FRACTION * n)
        test_start = calibration_end + int(GAP_FRACTION * n)
        if min(fit_end, calibration_end - fit_end, n - test_start) < 12:
            raise ValueError("Insufficient frames in one split")
        model = TargetCalibrationAdapter().fit(
            xs, labels[source], xt[:fit_end], yt[:fit_end], JOINTS,
        )
        calibration_prediction = model.predict(xt[fit_end:calibration_end])
        test_prediction = model.predict(xt[test_start:])
        radius = finite_sample_radius(
            np.abs(calibration_prediction - yt[fit_end:calibration_end]), ALPHA,
        )
        test_error = np.abs(test_prediction - yt[test_start:])
        folds.append({
            "source": source, "target": target,
            "fit_target_frames": fit_end,
            "calibration_frames": calibration_end - fit_end,
            "gap_frames": test_start - calibration_end,
            "test_frames": n - test_start,
            "nominal_coverage": 1 - ALPHA,
            "radius_rad_by_joint": radius.tolist(),
            "empirical_test_coverage_by_joint": np.mean(test_error <= radius, axis=0).tolist(),
            "empirical_test_mae_by_joint": test_error.mean(axis=0).tolist(),
            "median_radius_rad": float(np.median(radius)),
            "mean_empirical_coverage": float(np.mean(test_error <= radius)),
        })
    result = {
        "status": "exploratory chronological intervals; NOT calibrated coverage",
        "warning": "Frames are time-correlated; labels are provisional and synchronization unverified",
        "same_robot_status": "assumed for diagnostic; not user-confirmed",
        "target_fit_fraction": FIT_FRACTION,
        "target_calibration_fraction": CALIBRATION_FRACTION,
        "gap_fraction": GAP_FRACTION,
        "alpha": ALPHA,
        "method": "per-joint split residual quantile with ceil((n+1)*(1-alpha)) rank",
        "folds": folds,
    }
    path = Path(__file__).with_name("interval_diagnostic.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"path": str(path), "folds": [
        {"source": x["source"], "target": x["target"],
         "median_radius_rad": x["median_radius_rad"],
         "mean_empirical_coverage": x["mean_empirical_coverage"]}
        for x in folds]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
