"""Supervised target-view calibration adapter for one identified robot.

This research prototype combines one source-view recording with a short,
encoder-labeled prefix from a new camera view. Source and target must depict
the same physical robot and the same ordered joints. It is not cross-robot
zero-shot transfer. Predictions are diagnostic and have no reliability or
coverage guarantee. A future benchmark must use hardware-synchronized labels.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler


HERE = Path(__file__).resolve().parent
ALGORITHM_CANDIDATES = (HERE.parent, HERE.parent / "new_robot_algorithm")
ALGORITHM = next(
    (candidate for candidate in ALGORITHM_CANDIDATES
     if (candidate / "vision" / "frontend.py").is_file()),
    None,
)
if ALGORITHM is None:
    raise ImportError("Place adaptation/ beside vision/ in general_algorithm")
sys.path.insert(0, str(ALGORITHM))
from vision.frontend import CanonicalVideoFrontend, load_frame_directory  # noqa: E402


@dataclass(frozen=True)
class Split:
    calibration_count: int
    gap_count: int
    test_start: int
    test_count: int


def chronological_split(count: int, calibration_fraction: float, gap_fraction: float) -> Split:
    if count < 40:
        raise ValueError("At least 40 target frames are required")
    if not 0 < calibration_fraction < 0.8 or not 0 < gap_fraction < 0.5:
        raise ValueError("Use 0 < calibration_fraction < 0.8 and 0 < gap_fraction < 0.5")
    calibration = int(count * calibration_fraction)
    gap = max(1, int(count * gap_fraction))
    test_start = calibration + gap
    if calibration < 12 or count - test_start < 12:
        raise ValueError("Calibration and test segments must each contain at least 12 frames")
    return Split(calibration, gap, test_start, count - test_start)


def matrix(name: str, value: np.ndarray, rows: int | None = None) -> np.ndarray:
    array = np.asarray(value, dtype=float)
    if array.ndim != 2 or min(array.shape) == 0 or not np.isfinite(array).all():
        raise ValueError(f"{name} must be a nonempty finite 2D array")
    if rows is not None and len(array) != rows:
        raise ValueError(f"{name} has {len(array)} rows; expected {rows}")
    return array


def joint_types_or_default(joint_types: list[str] | None, count: int) -> tuple[str, ...]:
    kinds = tuple(joint_types or ["revolute"] * count)
    if len(kinds) != count or any(
        kind not in {"revolute", "continuous", "prismatic"} for kind in kinds
    ):
        raise ValueError("joint_types must match joints and use revolute/continuous/prismatic")
    return kinds


def encode_angles(values: np.ndarray, joint_types: tuple[str, ...]) -> np.ndarray:
    columns = []
    for index, kind in enumerate(joint_types):
        angle = values[:, index]
        if kind == "continuous":
            columns.extend((np.cos(angle), np.sin(angle)))
        else:
            columns.append(angle)
    return np.column_stack(columns)


def decode_angles(values: np.ndarray, joint_types: tuple[str, ...]) -> np.ndarray:
    columns, cursor = [], 0
    for kind in joint_types:
        if kind == "continuous":
            columns.append(np.arctan2(values[:, cursor + 1], values[:, cursor]))
            cursor += 2
        else:
            columns.append(values[:, cursor])
            cursor += 1
    return np.column_stack(columns)


def joint_error(actual: np.ndarray, prediction: np.ndarray,
                joint_types: tuple[str, ...]) -> np.ndarray:
    error = actual - prediction
    for index, kind in enumerate(joint_types):
        if kind == "continuous":
            error[:, index] = (error[:, index] + np.pi) % (2 * np.pi) - np.pi
    return np.abs(error)


def joint_center(values: np.ndarray, joint_types: tuple[str, ...]) -> np.ndarray:
    centers = []
    for index, kind in enumerate(joint_types):
        angle = values[:, index]
        if kind == "continuous":
            centers.append(float(np.arctan2(np.sin(angle).mean(), np.cos(angle).mean())))
        else:
            centers.append(float(angle.mean()))
    return np.asarray(centers)


class TargetCalibrationAdapter:
    """Balanced supervised adaptation with an ordered joint interface."""

    def __init__(self, *, alpha: float = 100.0, source_mass: float = 0.5):
        if alpha <= 0 or not 0 < source_mass < 1:
            raise ValueError("alpha must be positive and source_mass in (0, 1)")
        self.alpha = float(alpha)
        self.source_mass = float(source_mass)
        self.fitted = False

    def fit(self, source_features: np.ndarray, source_angles: np.ndarray,
            calibration_features: np.ndarray, calibration_angles: np.ndarray,
            joint_names: list[str],
            joint_types: list[str] | None = None) -> "TargetCalibrationAdapter":
        xs = matrix("source_features", source_features)
        ys = matrix("source_angles", source_angles, len(xs))
        xc = matrix("calibration_features", calibration_features)
        yc = matrix("calibration_angles", calibration_angles, len(xc))
        if xs.shape[1] != xc.shape[1] or ys.shape[1] != yc.shape[1]:
            raise ValueError("Source and target feature/joint dimensions must match")
        if len(joint_names) != ys.shape[1] or len(set(joint_names)) != len(joint_names):
            raise ValueError("Unique joint_names must match ordered labels")
        kinds = joint_types_or_default(joint_types, ys.shape[1])
        if len(xs) < 12 or len(xc) < 12:
            raise ValueError("At least 12 source and calibration rows are required")
        x = np.vstack((xs, xc))
        y = encode_angles(np.vstack((ys, yc)), kinds)
        # Equal aggregate mass per view by default; this is a design choice,
        # not a model-selection result or a probabilistic weight.
        weights = np.r_[np.full(len(xs), self.source_mass / len(xs)),
                        np.full(len(xc), (1 - self.source_mass) / len(xc))]
        weights *= len(x)
        self.scaler = StandardScaler().fit(x)
        self.regressor = Ridge(alpha=self.alpha).fit(
            np.clip(self.scaler.transform(x), -5.0, 5.0), y,
            sample_weight=weights,
        )
        self.joint_names = tuple(joint_names)
        self.joint_types = kinds
        self.source_count = len(xs)
        self.calibration_count = len(xc)
        self.fitted = True
        return self

    def predict(self, features: np.ndarray) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("Fit before prediction")
        x = matrix("features", features)
        if x.shape[1] != self.scaler.n_features_in_:
            raise ValueError("Feature dimension differs from calibration")
        encoded = self.regressor.predict(np.clip(self.scaler.transform(x), -5.0, 5.0))
        return decode_angles(encoded, self.joint_types)


def _read_labels(path: Path, names: list[str], columns: list[str]) -> np.ndarray:
    table = pd.read_csv(path)
    if "image" not in table or table["image"].tolist() != names:
        raise ValueError(f"Image names in {path} must exactly match the ordered frame directory")
    if len(set(columns)) != len(columns) or not all(col in table for col in columns):
        raise ValueError("Pass unique --joint-columns present in both label CSVs")
    return matrix(str(path), table[columns].to_numpy(dtype=float), len(names))


def _metrics(actual: np.ndarray, prediction: np.ndarray,
             joint_types: tuple[str, ...]) -> dict:
    error = joint_error(actual, prediction, joint_types)
    units = ["m" if kind == "prismatic" else "rad" for kind in joint_types]
    return {"mae": float(error.mean()) if len(set(units)) == 1 else None,
            "mae_unit": units[0] if len(set(units)) == 1 else None,
            "joint_units": units,
            "overall_note": (None if len(set(units)) == 1
                             else "Angular radians and prismatic metres must not be averaged"),
            "mae_by_joint": error.mean(axis=0).tolist(),
            "p95_by_joint": np.percentile(error, 95, axis=0).tolist()}


def _single_view_predict(x_train: np.ndarray, y_train: np.ndarray,
                         x_test: np.ndarray, alpha: float,
                         joint_types: tuple[str, ...]) -> np.ndarray:
    scaler = StandardScaler().fit(x_train)
    model = Ridge(alpha=alpha).fit(
        np.clip(scaler.transform(x_train), -5.0, 5.0), encode_angles(y_train, joint_types),
    )
    encoded = model.predict(np.clip(scaler.transform(x_test), -5.0, 5.0))
    return decode_angles(encoded, joint_types)


def split_evaluate(args: argparse.Namespace) -> None:
    source_names, source_frames = load_frame_directory(args.source_frames)
    target_names, target_frames = load_frame_directory(args.target_frames)
    source_y = _read_labels(args.source_labels, source_names, args.joint_columns)
    target_y = _read_labels(args.target_labels, target_names, args.joint_columns)
    kinds = joint_types_or_default(args.joint_types, len(args.joint_columns))
    split = chronological_split(len(target_names), args.calibration_fraction, args.gap_fraction)
    frontend = CanonicalVideoFrontend().fit_reference(source_frames)
    source_visual = frontend.transform(source_frames, reference=True)
    target_visual = frontend.transform(target_frames)
    if not target_visual.usable:
        raise RuntimeError(f"Target camera view cannot register: {target_visual.registration}")
    xs = source_visual.appearance
    xt = target_visual.appearance
    adapter = TargetCalibrationAdapter(alpha=args.alpha, source_mass=args.source_mass)
    adapter.fit(xs, source_y, xt[:split.calibration_count],
                target_y[:split.calibration_count], args.joint_columns, list(kinds))
    test_x = xt[split.test_start:]
    test_y = target_y[split.test_start:]
    pred = adapter.predict(test_x)
    source_pred = _single_view_predict(xs, source_y, test_x, args.alpha, kinds)
    target_prefix_pred = _single_view_predict(
        xt[:split.calibration_count], target_y[:split.calibration_count], test_x, args.alpha, kinds
    )
    report = {
        "status": "exploratory diagnostic; no publication-level validation",
        "label_status": args.label_status,
        "same_robot_status": ("user_confirmed" if args.same_robot_confirmed
                              else "assumed_for_diagnostic_only"),
        "warning": "Supplied provisional labels may be time-misaligned; no coverage guarantee",
        "split_fixed_before_model_fit": True,
        "source_frames": str(args.source_frames),
        "source_labels": str(args.source_labels),
        "target_frames": str(args.target_frames),
        "target_labels": str(args.target_labels),
        "joint_columns_in_order": args.joint_columns,
        "joint_types_in_order": list(kinds),
        "joint_units_in_order": ["m" if kind == "prismatic" else "rad" for kind in kinds],
        "source_count": len(xs),
        "calibration_count": split.calibration_count,
        "gap_count": split.gap_count,
        "test_start_frame": split.test_start,
        "test_count": split.test_count,
        "calibration_fraction": args.calibration_fraction,
        "gap_fraction": args.gap_fraction,
        "ridge_alpha": args.alpha,
        "source_mass": args.source_mass,
        "registration": target_visual.registration,
        "metrics": _metrics(test_y, pred, kinds),
        "source_only_metrics": _metrics(test_y, source_pred, kinds),
        "target_prefix_only_metrics": _metrics(test_y, target_prefix_pred, kinds),
        "target_prefix_mean_metrics": _metrics(
            test_y, np.broadcast_to(joint_center(target_y[:split.calibration_count], kinds),
                                    test_y.shape), kinds),
        "limitations": [
            "Target test frames enter the unlabeled full-video median used for offline registration.",
            "Target test labels are used for scoring only, never fitting or model selection.",
            "Only one apparent robot and two development videos are available.",
        ],
    }
    args.output.mkdir(parents=True, exist_ok=True)
    joblib.dump({"adapter": adapter, "frontend": frontend, "metadata": report},
                args.output / "model.joblib")
    pd.DataFrame({"image": target_names[split.test_start:], **{
        f"pred__{name}": pred[:, j] for j, name in enumerate(args.joint_columns)
    }}).to_csv(args.output / "predictions.csv", index=False)
    (args.output / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), "test_mae": report["metrics"]["mae"],
                      "test_count": split.test_count}, ensure_ascii=False))


def predict(args: argparse.Namespace) -> None:
    bundle = joblib.load(args.model)
    names, frames = load_frame_directory(args.frames)
    visual = bundle["frontend"].transform(frames)
    if not visual.usable:
        raise RuntimeError(f"Video cannot register: {visual.registration}")
    pred = bundle["adapter"].predict(visual.appearance)
    columns = bundle["adapter"].joint_names
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"image": names, **{
        f"pred__{name}": pred[:, j] for j, name in enumerate(columns)
    }}).to_csv(args.output, index=False)
    print(json.dumps({"output": str(args.output), "frame_count": len(names),
                      "warning": "Diagnostic values only; no calibrated reliability"},
                     ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    p = actions.add_parser("split-evaluate")
    p.add_argument("--source-frames", required=True, type=Path)
    p.add_argument("--source-labels", required=True, type=Path)
    p.add_argument("--target-frames", required=True, type=Path)
    p.add_argument("--target-labels", required=True, type=Path)
    p.add_argument("--joint-columns", nargs="+", required=True)
    p.add_argument("--joint-types", nargs="+",
                   choices=("revolute", "continuous", "prismatic"),
                   help="Ordered types; defaults to all revolute when URDF is unavailable")
    p.add_argument("--calibration-fraction", type=float, default=0.25)
    p.add_argument("--gap-fraction", type=float, default=0.10)
    p.add_argument("--alpha", type=float, default=100.0)
    p.add_argument("--source-mass", type=float, default=0.5)
    p.add_argument("--label-status", choices=("provisional", "verified"), required=True)
    identity = p.add_mutually_exclusive_group(required=True)
    identity.add_argument("--same-robot-confirmed", action="store_true")
    identity.add_argument("--same-robot-assumed-for-diagnostic", action="store_true")
    p.add_argument("--output", type=Path, required=True)
    p.set_defaults(function=split_evaluate)
    p = actions.add_parser("predict")
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--frames", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.set_defaults(function=predict)
    args = parser.parse_args()
    args.function(args)


if __name__ == "__main__":
    main()
