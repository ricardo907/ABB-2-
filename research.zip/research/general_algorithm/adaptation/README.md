# T-RO 准备阶段：目标机位短标定诊断

`target_calibration_adapter.py` 是**同一台机械臂**换机位后的监督适配原型，输入源机位图像/关节标签和目标机位最前面一段图像/标签；目标后段只用于评估。它接受任意正整数个按顺序对应的关节列，采用 ORB 背景注册、灰度 32×32 特征、两个机位各占总样本权重一半的 Ridge 回归。`--joint-types` 可显式标注转动、连续转动和直线关节；连续关节使用周期输出及 wrapped 误差，直线关节单位为 m，混合 rad/m 时不汇总总体 MAE。没有跨机器人共享模型或置信区间保证。

```powershell
python research/general_algorithm/adaptation/target_calibration_adapter.py split-evaluate `
  --source-frames data/train/Exp001/frames `
  --source-labels data/train/Exp001/train_labels.csv `
  --target-frames data2/test/Exp002/frames `
  --target-labels data2/test/Exp002/test_labels.csv `
  --joint-columns axis1 axis2 axis3 axis4 axis5 axis6 `
  --label-status provisional --same-robot-assumed-for-diagnostic `
  --output research/general_algorithm/adaptation/examples/exp001_to_exp002
```

默认先固定目标视频的前 25% 帧作标定，跳过 10% 帧作为时间间隔，在后段评估。输出 `model.joblib`、`predictions.csv` 和包含原始路径、标定/间隔/测试帧数、同机器人状态及各基线误差的 `report.json`。`predict` 命令可在新目录生成诊断值；配准失败会拒绝推理。模型不提供安全控制输出。

现有两段视频均已参与算法开发，标签与视频的硬件同步未确认，两个视频是否同一实体机械臂也未由用户确认。两折暂定标签诊断（单位 rad）：

| 源→目标 | 后段帧数 | 源模型 | 目标前缀单独 | 源+目标前缀 |
| --- | ---: | ---: | ---: | ---: |
| Exp001→Exp002 | 143 | 0.550 | 0.520 | 0.465 |
| Exp002→Exp001 | 132 | 0.516 | 0.222 | 0.247 |

`interval_diagnostic.py` 使用前 15% 目标帧拟合、随后 10% 残差校准、隔 10% 后测试。名义 90% 的逐关节区间在两折的平均实测覆盖率仅 19.0% 和 48.4%。时间相关、姿态分布变化和标签偏移破坏常规 split conformal 前提，因此不能说这些区间有 90% 真实覆盖率。区间结果是 T-RO 研究设计中的失败诊断，提示需要独立同步标定、跨姿态/机位数据和更可靠的不确定度模型。
