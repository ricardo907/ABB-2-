"""Validate sparse VLM annotations before optional per-joint inference gating.

The VLM cannot turn an unreliable estimate into a reliable one. Gating can
only withhold values on annotated keyframes; other frames retain the base
estimator's decision. This is an experimental ablation, not a safety claim.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

from vlm.semantic_keyframes import ResponseValidationError, parse_response, sha256_bytes


SCHEMA = "robot-joint-semantic-keyframe-v1"
VISIBILITY = {"visible", "occluded", "unknown"}


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_semantic_observations(
    path: str | Path,
    frame_directory: str | Path,
    frame_names: list[str],
    joint_names: list[str],
) -> dict[str, np.ndarray | int]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("schema_version") != SCHEMA:
        raise ValueError("Unsupported VLM semantic observation schema")
    if data.get("joint_names") != list(joint_names):
        raise ValueError("VLM joint order differs from the trained model")
    joint_to_link = data.get("joint_to_link")
    records = data.get("records")
    if not isinstance(records, list):
        raise ValueError("VLM observations need a records list")
    frame_lookup = {name: index for index, name in enumerate(frame_names)}
    if len(frame_lookup) != len(frame_names):
        raise ValueError("Frame directory has duplicate image names")
    count = len(frame_names)
    joints = len(joint_names)
    annotated = np.zeros(count, dtype=bool)
    visibility = np.full((count, joints), "unannotated", dtype=object)
    uv = np.full((count, joints, 2), np.nan, dtype=np.float64)
    seen = set()
    invalid_count = 0
    for record in records:
        if not isinstance(record, dict) or "frame" not in record:
            raise ValueError("VLM record is malformed")
        name = Path(record["frame"]).name
        if name not in frame_lookup or name in seen:
            raise ValueError(f"VLM frame is absent or repeated: {name}")
        seen.add(name)
        actual_path = Path(frame_directory) / name
        if record.get("frame_sha256") != _hash(actual_path):
            raise ValueError(f"VLM frame hash does not match inference input: {name}")
        if record.get("status") != "parsed_diagnostic_only":
            invalid_count += 1
            continue
        annotation = record.get("annotation")
        items = annotation.get("joints") if isinstance(annotation, dict) else None
        if not isinstance(items, list) or len(items) != joints:
            raise ValueError(f"VLM parsed annotation has wrong joint count: {name}")
        size = record.get("inference_size")
        if not isinstance(size, list) or len(size) != 2 or any(
            not isinstance(value, int) or value <= 0 for value in size
        ):
            raise ValueError(f"VLM inference_size is invalid: {name}")
        with Image.open(actual_path) as source:
            original_size = list(source.size)
        if record.get("original_size") != original_size:
            raise ValueError(f"VLM original_size does not match inference input: {name}")
        prompt = record.get("prompt")
        response = record.get("raw_response")
        if not isinstance(prompt, str) or not isinstance(response, str):
            raise ValueError(f"VLM prompt or raw response is missing: {name}")
        if record.get("prompt_sha256") != sha256_bytes(prompt.encode("utf-8")):
            raise ValueError(f"VLM prompt hash mismatch: {name}")
        try:
            parsed_again = parse_response(response, joint_names, *size, joint_to_link)
        except ResponseValidationError as error:
            raise ValueError(f"VLM raw response no longer parses: {name}: {error}") from error
        if parsed_again != annotation:
            raise ValueError(f"VLM parsed annotation differs from raw response: {name}")
        index = frame_lookup[name]
        for joint, (item, expected_name) in enumerate(zip(items, joint_names)):
            if not isinstance(item, dict) or item.get("joint_name") != expected_name:
                raise ValueError(f"VLM annotation joint order mismatch: {name}")
            state = item.get("visibility")
            if state not in VISIBILITY:
                raise ValueError(f"VLM visibility is invalid: {name} {expected_name}")
            point = item.get("uv")
            if state == "visible":
                if not isinstance(point, list) or len(point) != 2 or any(
                    not isinstance(value, int) for value in point
                ) or not (0 <= point[0] < size[0] and 0 <= point[1] < size[1]):
                    raise ValueError(f"VLM visible joint needs in-bounds uv: {name} {expected_name}")
                uv[index, joint] = [
                    (point[axis] + 0.5) * original_size[axis] / size[axis] - 0.5
                    for axis in (0, 1)
                ]
            elif point is not None:
                raise ValueError(f"VLM hidden joint must have null uv: {name} {expected_name}")
            visibility[index, joint] = state
        annotated[index] = True
    return {"annotated": annotated, "visibility": visibility, "uv": uv,
            "invalid_record_count": invalid_count, "valid_keyframe_count": int(annotated.sum())}


def apply_visibility_gate(base_reliable: np.ndarray, semantics: dict) -> np.ndarray:
    reliable = np.asarray(base_reliable, dtype=bool)
    annotated = np.asarray(semantics["annotated"], dtype=bool)
    visibility = np.asarray(semantics["visibility"], dtype=object)
    if reliable.ndim != 2 or annotated.shape != (len(reliable),) or visibility.shape != reliable.shape:
        raise ValueError("VLM semantics and base reliability have different dimensions")
    gated = reliable.copy()
    gated[annotated] &= visibility[annotated] == "visible"
    return gated
