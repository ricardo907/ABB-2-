# 机械臂关键帧 VLM 语义标注原型

`semantic_keyframes.py` 只输出关节的 `visible / occluded / unknown`、可见关节的二维像素位置、以及经输入规范验证的连杆名称。图像里看不出具体关节时应输出 `unknown`。后续数值模块会产生**诊断性**角度候选，但不能充当真值、标定结果或控制系统的安全依据。

## 输入

`joint_spec_example.json` 的 `joint_names` 必须按机械臂基座到末端排列，名字唯一。可选 `joint_to_link` 为每个关节提供一个经人工/URDF 验证的连杆名；不提供时输出中的 `link_name` 只能为 `null`。关键帧用重复的 `--frame` 传入。`semantic_keyframes.py` 本身不自动抽帧、估角或传播二维点；下文独立模块处理后两项。

## 不安装模型的结构测试

```powershell
python research/general_algorithm/vlm/selfcheck.py
python research/general_algorithm/vlm/tracker_selfcheck.py
python research/general_algorithm/vlm/selfcheck_regressor.py
python research/general_algorithm/vlm/selfcheck_diagnostic_pipeline.py
```

## 本地 Qwen3-VL

建议在独立虚拟环境安装 `requirements-vlm.txt`。PyTorch 应选择与本机 CUDA 驱动兼容的官方发行版。模型默认 `Qwen/Qwen3-VL-2B-Instruct`；用 `--cache-dir` 指定权重缓存位置。首次联网下载后用 `--offline` 强制只读缓存。当前系统自带的 PyTorch 2.0.1 / Transformers 4.24.0 不满足 Qwen3-VL 运行要求；**截至本版本，真实权重尚未在本机完成推理验证**。

实际尝试和下载阻碍见 `TRIAL_STATUS.md`。`clip_fallback.py` 只检查图文推理是否能运行，不能定位关节；此次其权重下载也未完成。

```powershell
python research/general_algorithm/vlm/semantic_keyframes.py `
  --backend qwen3-vl `
  --joint-spec research/general_algorithm/vlm/joint_spec_example.json `
  --frame data/train/Exp001/frames/frame_0000.jpg `
  --cache-dir research/general_algorithm/vlm_cache `
  --output research/general_algorithm/vlm/qwen_trial.json
```

结果记录原始帧 SHA-256、完整提示词及其 SHA-256、请求的模型 revision、缓存中解析的精确 revision、模型原文及严格校验后的结构。输出坐标属于 `inference_size` 表示的缩放图像，不能直接当原图坐标。严格 JSON 校验拒绝 markdown 围栏、重复键、额外键、漏掉/重复关节、越界像素和无效连杆名。格式正确不等于语义正确；需要独立人工标注测试后才能把它并入估角模型。

`direct_angle_baseline.py` 是隔离的直接报角度对照实验，沿用同一模型与关键帧，但输出字段名明确是 `angles_diagnostic_only`。它不参与语义关键帧模块或任何安全输出；没有经核验真值时只记录预测，不报告误差。

`track_joint_points.py` 可读取上述语义 JSON，在原始视频帧上用双向光流传播各关节的 2D 候选。运行例子：

```powershell
python research/general_algorithm/vlm/track_joint_points.py `
  --frames data/train/Exp001/frames `
  --keyframes research/general_algorithm/vlm/qwen_trial.json `
  --mask-dir data/train/Exp001/robot_masks `
  --timestamps data/train/Exp001/timestamps.csv `
  --output research/general_algorithm/vlm/joint_tracks.csv
```

`--mask-dir` 和 `--timestamps` 均可省略。掩码目录若提供，必须包含与每个视频帧对应的 `frame_XXXX.png` 二值机械臂掩码；掩码应由独立分割或标定获得，不能从待评估角度标签反推。跟踪器只在前后两帧掩码内挑选和保留光流角点，关键帧候选若落在掩码外则拒绝作为跟踪起点。时间戳 CSV 接受采集协议的 `frame_index,camera_time_ns[,image]`，也接受 `timestamp_ns` 作为时间列别名；逐帧对应且严格递增，若有 `image` 列则须与所选帧名相同。输出统一记为 `timestamp_ns`。输出每帧每关节的位置、质量、失效原因、原帧 SHA-256 和相机时间戳。掩码降低背景锁定风险，但没有真实二维真值时不能断言减少了真实误差。

`pipeline.py infer --vlm-observations ... --vlm-mode diagnostic|gate` 是原有关键帧门控接口；光流轨迹与数值分支单独保留诊断属性。

`joint_track_regressor.py` 是**独立数值实验分支**：在某一机器人/相机上，用上述轨迹 CSV 和该机器人的同步编码器标签训练逐关节模型；推理要求机器人与相机 ID、图像尺寸一致。训练标签若同时包含与轨迹相同的 `timestamp_ns` 和 `frame_sha256`，程序会核对；缺少时间戳时报告 `label_timing_verified=false`，不能把仅按文件名对齐当成已验证同步。默认每个关节使用相邻两个跟踪点，也可在训练时用 `--support-map` 传入 `{关节名: [所需跟踪点名, ...]}` JSON。某一点缺失时仅其相关关节拒答，其他关节仍可输出候选。每关节的 `status__...` 和 `nearest_source_distance__...` 说明是否在训练源邻域；兼容字段 `safe__...` **不是安全保证或已校准的不确定度**。默认相邻点选择只是建模假设，尤其不能解决仅看关节中心时末轴角度不可观测的问题。新模型格式为 `vlm-track-local-ridge-v2`，旧版模型需重新训练。命令可通过 `python research/general_algorithm/vlm/joint_track_regressor.py --help` 查看。3/7 关节合成自检只证明接口、部分可见性和拒答行为，现有真实视频缺乏已验证的 VLM 点和同步标签，尚不能报告真实角度精度。

`geometry/geometry_solver.py` 是另一条物理几何分支：在已知串联 URDF、相机内外参和关节/工具二维点时，以重投影残差估计关节坐标，并用**不含时间先验**的图像雅可比检查局部可观测性。仅有关节中心通常看不到末轴转角，需要偏离末轴的工具或连杆标记。当前 VLM/光流二维点均未人工核实，所以真实输入只会得到诊断值；`geometry/README.md` 说明接口与 3/7 自由度合成自检。

## 统一诊断流程

先用 `semantic_keyframes.py` 生成与原帧 SHA-256 匹配的关键帧 JSON，再调用：

```powershell
python research/general_algorithm/vlm/diagnostic_pipeline.py `
  --frames data/train/Exp001/frames `
  --keyframes research/general_algorithm/vlm/qwen_trial.json `
  --output-dir research/general_algorithm/vlm/exp001_diagnostic `
  --robot-id ABB_具体型号 `
  --camera-id camera_1 `
  --timestamps data/train/Exp001/timestamps.csv `
  --mask-dir data/train/Exp001/robot_masks
```

已有**独立训练**的同机器人/相机回归模型时加 `--regressor-model model.joblib`；有串联 URDF 与相机内外参时加 `--urdf arm.urdf --camera-json camera.json`。两支可以同时运行，不要求每个关节在每帧都可见。`--landmarks-json` 可提供刚性标记的几何定义，但当前关键帧/跟踪 JSON 仅提供关节点，**不会自动产生标记的二维观测**；因此它本身不能补足末轴可观测性。`diagnostic_frames.jsonl` 每帧一条，按 `joint_names` 顺序提供 `tracks`，可选 `regressor` 和 `geometry`。`diagnostic_report.json` 记录输入输出哈希、帧数和失败数量；`joint_tracks.csv` 与可选 `joint_regressor_predictions.csv` 便于主流程按 `frame_index`、`frame_sha256` 和 `timestamp_ns` 对齐。任何结果都只作为研究诊断，不能提升主流程的安全或可靠性标记。

当前没有下载并验证真实 Qwen 权重，也没有在现有机械臂视频上形成独立二维与同步编码器评测。因此合成测试通过不构成真实性能提升，更不能作为 TRO 投稿精度证据。论文实验还需真实角度测试、独立二维标注、跨轨迹/视角/光照/机械臂拆分，以及无 VLM、无掩码和纯几何等消融。

## 来源与边界

[Qwen3-VL-2B-Instruct 官方模型卡](https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct)标记为 Apache-2.0，提供本地 Transformers 运行方式。[直接用 VLM 报关节角的研究](https://arxiv.org/abs/2512.06017)发现误差与自报不确定性均较大。
