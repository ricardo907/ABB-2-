"""No-weight checks for the semantic keyframe response contract."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image

from direct_angle_baseline import parse_angle_response
from semantic_keyframes import ResponseValidationError, annotate, parse_response, sha256_file


ROOT = Path(__file__).resolve().parent
SCRATCH = ROOT / "selfcheck_tmp"


def _expect_rejected(raw: str, names: list[str]) -> None:
    try:
        parse_response(raw, names, 100, 60, {"j1": "link1", "j2": "link2"})
    except ResponseValidationError:
        return
    raise AssertionError(f"parser accepted invalid response: {raw}")


def main() -> None:
    names = ["j1", "j2"]
    links = {"j1": "link1", "j2": "link2"}
    valid = {
        "joints": [
            {"joint_name": "j2", "visibility": "occluded", "uv": None, "link_name": "link2"},
            {"joint_name": "j1", "visibility": "visible", "uv": [30, 20], "link_name": "link1"},
        ]
    }
    raw = json.dumps(valid)
    parsed = parse_response(raw, names, 100, 60, links)
    assert [item["joint_name"] for item in parsed["joints"]] == names
    for invalid in [
        "```json\n" + raw + "\n```",
        '{"joints":[],"joints":[]}',
        json.dumps({"joints": [valid["joints"][1], valid["joints"][1]]}),
        json.dumps({"joints": [dict(valid["joints"][0], uv=[20, 20]), valid["joints"][1]]}),
        json.dumps({"joints": [dict(valid["joints"][0], link_name="wrong"), valid["joints"][1]]}),
        json.dumps({"joints": [dict(valid["joints"][0], visibility="visible", uv=[100, 0]), valid["joints"][1]]}),
    ]:
        _expect_rejected(invalid, names)

    SCRATCH.mkdir(exist_ok=True)
    frame = SCRATCH / "tiny.png"
    Image.new("RGB", (100, 60), color=(220, 230, 240)).save(frame)
    result = annotate(
        [frame], names, links, "mock", "unused", "unused", ROOT / "cache", True,
        1024, 512, [raw],
    )
    record = result["records"][0]
    assert record["status"] == "parsed_diagnostic_only"
    assert record["frame_sha256"] == sha256_file(frame)
    assert len(record["prompt_sha256"]) == 64
    assert record["resolved_revision"] == "mock-no-weights"
    assert result["purpose"].startswith("diagnostic")
    invalid_result = annotate(
        [frame], names, links, "mock", "unused", "unused", ROOT / "cache", True,
        1024, 512, ["not JSON"],
    )
    assert invalid_result["records"][0]["status"] == "invalid_response"
    assert invalid_result["records"][0]["annotation"] is None
    angle_raw = '{"joints":[{"joint_name":"j2","angle_rad":-0.25},{"joint_name":"j1","angle_rad":0.5}]}'
    angle_parsed = parse_angle_response(angle_raw, names)
    assert [x["angle_rad"] for x in angle_parsed["joints"]] == [0.5, -0.25]
    for invalid_angle in [
        '{"joints":[{"joint_name":"j1","angle_rad":NaN},{"joint_name":"j2","angle_rad":0}]}',
        '{"joints":[{"joint_name":"j1","angle_rad":true},{"joint_name":"j2","angle_rad":0}]}',
        '{"joints":[]}',
    ]:
        try:
            parse_angle_response(invalid_angle, names)
        except ResponseValidationError:
            pass
        else:
            raise AssertionError(f"direct-angle parser accepted {invalid_angle}")
    print("semantic keyframe mock/parser selfcheck passed")


if __name__ == "__main__":
    main()
