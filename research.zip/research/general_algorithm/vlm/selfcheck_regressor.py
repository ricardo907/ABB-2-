"""Variable-joint synthetic fit, missing-point abstention, ID and metric checks."""

from __future__ import annotations

import csv
import hashlib
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from joint_track_regressor import evaluate, infer, train


def synth(base: Path, joint_count: int) -> None:
    rng = np.random.default_rng(20 + joint_count)
    names = [f"joint_{index + 1}" for index in range(joint_count)]
    label_columns = [f"encoder_{index + 1}" for index in range(joint_count)]
    joint_types = ["revolute"] * joint_count
    if joint_count == 7:
        joint_types[-1] = "prismatic"
    width, height = 200, 160

    def write_part(name: str, count: int, missing: bool) -> tuple[Path, Path]:
        uv = rng.uniform(0.1, 0.9, size=(count, joint_count, 2))
        quality = rng.uniform(0.75, 0.98, size=(count, joint_count))
        # Each synthetic target uses only its configured adjacent landmarks.
        y = np.empty((count, joint_count))
        for joint in range(joint_count):
            neighbor = joint + 1 if joint + 1 < joint_count else joint - 1
            y[:, joint] = (1.2 * uv[:, joint, 0]
                           - 0.8 * uv[:, neighbor, 1]
                           + 0.05 * joint)
        track_rows = []
        label_rows = []
        for frame in range(count):
            image = f"frame_{frame:04d}.png"
            frame_hash = hashlib.sha256(image.encode("utf-8")).hexdigest()
            timestamp_ns = 1_000_000_000 + 33_333_333 * frame
            label_rows.append({"image": image, "frame_sha256": frame_hash,
                               "camera_time_ns": timestamp_ns, **{
                column: y[frame, joint] for joint, column in enumerate(label_columns)
            }})
            for joint, joint_name in enumerate(names):
                visible = not (missing and frame == 5 and joint == 2)
                q = quality[frame, joint]
                if missing and frame == 6 and joint == 2:
                    q = 0.01
                track_rows.append({
                    "frame_index": frame, "image": image, "joint_name": joint_name,
                    "frame_sha256": frame_hash, "timestamp_ns": timestamp_ns,
                    "u_px": uv[frame, joint, 0] * width if visible else "",
                    "v_px": uv[frame, joint, 1] * height if visible else "",
                    "track_valid": visible, "quality": q if visible else 0,
                })
        tracks = base / f"{name}_tracks.csv"
        labels = base / f"{name}_labels.csv"
        with tracks.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(track_rows[0]))
            writer.writeheader()
            writer.writerows(track_rows)
        pd.DataFrame(label_rows).to_csv(labels, index=False)
        return tracks, labels

    train_tracks, train_labels = write_part("train", 240, False)
    test_tracks, test_labels = write_part("test", 40, True)
    model = base / "model.joblib"
    report = train(train_tracks, train_labels, model, robot_id=f"robot_{joint_count}",
                   camera_id="cam_1", joint_names=names, label_columns=label_columns,
                   joint_types=joint_types, width=width, height=height,
                   ridge_alpha=0.01)
    assert report["fully_tracked_labeled_frames"] == 240
    assert report["label_timing_verified"] is True
    output = base / "predictions.csv"
    infer_report = infer(test_tracks, model, output, robot_id=f"robot_{joint_count}",
                         camera_id="cam_1", width=width, height=height)
    pred = pd.read_csv(output)
    assert pred.loc[5, "status"] == "partial_or_out_of_source_support"
    assert pred.loc[6, "status"] == "partial_or_out_of_source_support"
    assert pred.loc[5, "status__joint_3"] == "missing_2d_observation"
    assert np.isnan(pred.loc[5, "safe__joint_3"])
    assert pd.notna(pred.loc[5, "safe__joint_1"])
    assert 0 < infer_report["safe_fraction"] < 1
    scores = evaluate(output, test_labels, base / "evaluation.json",
                      model_path=model, label_status="verified")
    errors = [entry["diagnostic_mae"] for entry in scores["per_joint"]]
    assert all(error is not None and error < 0.02 for error in errors), errors
    try:
        infer(test_tracks, model, output, robot_id="different_robot",
              camera_id="cam_1", width=width, height=height)
    except ValueError as exc:
        assert "Robot/camera ID differs" in str(exc)
    else:
        raise AssertionError("Cross-robot model reuse was accepted")
    stale_labels = pd.read_csv(train_labels)
    stale_labels.loc[0, "camera_time_ns"] += 1
    stale_path = base / "stale_labels.csv"
    stale_labels.to_csv(stale_path, index=False)
    try:
        train(train_tracks, stale_path, base / "bad_model.joblib",
              robot_id=f"robot_{joint_count}", camera_id="cam_1",
              joint_names=names, label_columns=label_columns,
              joint_types=joint_types, width=width, height=height)
    except ValueError as exc:
        assert "timestamp_ns differs" in str(exc)
    else:
        raise AssertionError("Mismatched encoder timestamp was accepted")


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        base = Path(temporary)
        for count in (3, 7):
            folder = base / f"joints_{count}"
            folder.mkdir()
            synth(folder, count)
    print("VLM track regressor selfcheck passed: 3/7 joints, missing points, ID guard, errors")


if __name__ == "__main__":
    main()
