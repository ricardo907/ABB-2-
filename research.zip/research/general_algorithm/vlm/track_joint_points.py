"""Offline 2-D tracking from sparse VLM joint-location proposals.

The VLM supplies only keyframe pixels. Lucas–Kanade flow propagates those
pixels, with forward/backward and local-motion checks. No angle output or
ground-truth interpretation is made here.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np


SCHEMA_VERSION = "robot-joint-semantic-keyframe-v1"
FRAME_NAME = re.compile(r"frame_(\d+)\.(?:jpg|jpeg|png)$", re.IGNORECASE)


@dataclass(frozen=True)
class TrackerConfig:
    patch_radius_px: int = 22
    max_gap_frames: int = 60
    min_features: int = 3
    max_features: int = 60
    max_fb_error_px: float = 1.5
    max_lk_residual: float = 30.0
    max_flow_spread_px: float = 3.0
    max_step_px: float = 40.0
    max_anchor_disagreement_px: float = 5.0
    min_track_quality: float = 0.12


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_timestamps(path: Path | None, frame_indices: list[int],
                    frame_names: list[str] | None = None) -> dict[int, int | None]:
    """Read exact camera timestamps; absent timestamps remain explicit nulls."""
    if path is None:
        return {index: None for index in frame_indices}
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or ())
        if "frame_index" not in fields or not ({"timestamp_ns", "camera_time_ns"} & fields):
            raise ValueError("Timestamp CSV needs frame_index and timestamp_ns or camera_time_ns")
        rows = list(reader)
    if len(rows) != len(frame_indices):
        raise ValueError("Timestamp CSV must contain exactly one row per frame")
    try:
        time_column = "camera_time_ns" if "camera_time_ns" in fields else "timestamp_ns"
        stamps = {int(row["frame_index"]): int(row[time_column]) for row in rows}
    except (TypeError, ValueError) as exc:
        raise ValueError("frame_index and timestamp_ns must be integers") from exc
    if len(stamps) != len(rows) or set(stamps) != set(frame_indices):
        raise ValueError("Timestamp CSV frame indices differ or repeat")
    if "timestamp_ns" in fields and "camera_time_ns" in fields:
        if any(int(row["timestamp_ns"]) != int(row["camera_time_ns"]) for row in rows):
            raise ValueError("timestamp_ns and camera_time_ns disagree")
    if "image" in fields and frame_names is not None:
        expected = dict(zip(frame_indices, frame_names))
        if any(row["image"] != expected[int(row["frame_index"])] for row in rows):
            raise ValueError("Timestamp CSV image differs from selected video frame")
    ordered = [stamps[index] for index in frame_indices]
    if any(stamp < 0 for stamp in ordered) or any(
        following <= previous for previous, following in zip(ordered, ordered[1:])
    ):
        raise ValueError("Camera timestamps must be nonnegative and strictly increasing")
    return stamps


def load_frames(folder: Path) -> tuple[list[int], list[Path], list[np.ndarray]]:
    indexed = []
    for path in folder.iterdir():
        match = FRAME_NAME.fullmatch(path.name)
        if match and path.is_file():
            indexed.append((int(match.group(1)), path.resolve()))
    indexed.sort()
    if not indexed:
        raise ValueError(f"No frame_NNNN images in {folder}")
    indices = [index for index, _ in indexed]
    if indices != list(range(indices[0], indices[0] + len(indices))):
        raise ValueError("Frame numbers must be consecutive")
    paths = [path for _, path in indexed]
    grays = []
    for path in paths:
        frame = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise OSError(f"Cannot decode frame: {path}")
        grays.append(frame)
    if len({frame.shape for frame in grays}) != 1:
        raise ValueError("Frame dimensions must remain constant")
    return indices, paths, grays


def load_keyframes(path: Path, frame_paths: list[Path],
                   frame_size: tuple[int, int]) -> tuple[list[str], dict[str, dict[int, Any]], dict[str, Any]]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"Expected {SCHEMA_VERSION} annotations")
    names = value.get("joint_names")
    if (type(names) is not list or not names or
            any(type(name) is not str or not name for name in names) or
            len(names) != len(set(names))):
        raise ValueError("joint_names must be unique nonempty strings")
    records = value.get("records")
    if type(records) is not list:
        raise ValueError("records must be a list")
    path_to_index = {path: index for index, path in enumerate(frame_paths)}
    annotations: dict[str, dict[int, Any]] = {name: {} for name in names}
    counts = {"records": len(records), "parsed_records": 0, "invalid_records": 0}
    width, height = frame_size
    seen_frames: set[int] = set()
    for record in records:
        if type(record) is not dict:
            raise ValueError("Each keyframe record must be an object")
        status = record.get("status")
        if status == "invalid_response":
            counts["invalid_records"] += 1
            continue
        if status != "parsed_diagnostic_only":
            raise ValueError(f"Unknown keyframe status: {status!r}")
        record_path = Path(record["frame"]).resolve()
        if record_path not in path_to_index:
            raise ValueError(f"Keyframe is outside the selected frame directory: {record_path}")
        index = path_to_index[record_path]
        if index in seen_frames:
            raise ValueError(f"Duplicate parsed keyframe: {record_path}")
        seen_frames.add(index)
        if record.get("frame_sha256") != _hash_file(record_path):
            raise ValueError(f"Keyframe SHA-256 mismatch: {record_path}")
        if record.get("original_size") != [width, height]:
            raise ValueError(f"Keyframe original_size mismatch: {record_path}")
        infer_size = record.get("inference_size")
        if (type(infer_size) is not list or len(infer_size) != 2 or
                any(type(size) is not int or size < 1 for size in infer_size)):
            raise ValueError("inference_size must be [positive width,height]")
        annotation = record.get("annotation")
        if type(annotation) is not dict or set(annotation) != {"joints"}:
            raise ValueError("Parsed record needs only annotation.joints")
        joints = annotation["joints"]
        if type(joints) is not list or len(joints) != len(names):
            raise ValueError("Parsed record must list each joint once")
        joint_map = {}
        for joint in joints:
            if type(joint) is not dict or set(joint) != {"joint_name", "visibility", "uv", "link_name"}:
                raise ValueError("Joint annotation has unexpected fields")
            name = joint["joint_name"]
            visibility = joint["visibility"]
            uv = joint["uv"]
            if name not in names or name in joint_map:
                raise ValueError("Unknown or duplicate joint in keyframe")
            if visibility not in ("visible", "occluded", "unknown"):
                raise ValueError("Invalid joint visibility")
            if visibility == "visible":
                if (type(uv) is not list or len(uv) != 2 or
                        any(type(coord) is not int for coord in uv) or
                        not (0 <= uv[0] < infer_size[0] and 0 <= uv[1] < infer_size[1])):
                    raise ValueError("Visible joint needs in-bounds integer uv")
                # Map pixel centres, accounting for VLM downsampling.
                x = (uv[0] + 0.5) * width / infer_size[0] - 0.5
                y = (uv[1] + 0.5) * height / infer_size[1] - 0.5
                joint_map[name] = ("visible", np.array([x, y], dtype=np.float32))
            else:
                if uv is not None:
                    raise ValueError("Nonvisible joint must have null uv")
                joint_map[name] = (visibility, None)
        if set(joint_map) != set(names):
            raise ValueError("Keyframe joint list differs from joint_names")
        for name in names:
            annotations[name][index] = joint_map[name]
        counts["parsed_records"] += 1
    if counts["parsed_records"] == 0:
        raise ValueError("No valid parsed keyframe records")
    return names, annotations, counts


def _weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    order = np.argsort(values)
    cumulative = np.cumsum(weights[order])
    return float(values[order[np.searchsorted(cumulative, cumulative[-1] / 2)]])


def _track_step(previous: np.ndarray, following: np.ndarray, point: np.ndarray,
                config: TrackerConfig, previous_robot_mask: np.ndarray | None = None,
                following_robot_mask: np.ndarray | None = None) -> tuple[np.ndarray | None, float, float]:
    height, width = previous.shape
    if not (0 <= point[0] < width and 0 <= point[1] < height):
        return None, 0.0, float("inf")
    mask = np.zeros_like(previous, dtype=np.uint8)
    cv2.circle(mask, (int(round(point[0])), int(round(point[1]))),
               config.patch_radius_px, 255, -1)
    if previous_robot_mask is not None:
        mask = cv2.bitwise_and(mask, previous_robot_mask)
    features = cv2.goodFeaturesToTrack(
        previous, maxCorners=config.max_features, qualityLevel=0.01,
        minDistance=3, mask=mask, blockSize=5,
    )
    if features is None or len(features) < config.min_features:
        return None, 0.0, float("inf")
    next_points, forward_status, forward_error = cv2.calcOpticalFlowPyrLK(
        previous, following, features, None, winSize=(21, 21), maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01),
    )
    if next_points is None or forward_status is None or forward_error is None:
        return None, 0.0, float("inf")
    back_points, back_status, _ = cv2.calcOpticalFlowPyrLK(
        following, previous, next_points, None, winSize=(21, 21), maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01),
    )
    if back_points is None or back_status is None:
        return None, 0.0, float("inf")
    starts = features.reshape(-1, 2)
    ends = next_points.reshape(-1, 2)
    fb = np.linalg.norm(back_points.reshape(-1, 2) - starts, axis=1)
    valid = (
        (forward_status.ravel() != 0) & (back_status.ravel() != 0)
        & np.isfinite(ends).all(axis=1) & np.isfinite(fb)
        & (fb <= config.max_fb_error_px)
        & (forward_error.ravel() <= config.max_lk_residual)
        & (ends[:, 0] >= 0) & (ends[:, 0] < width)
        & (ends[:, 1] >= 0) & (ends[:, 1] < height)
    )
    if following_robot_mask is not None:
        rounded = np.rint(ends).astype(np.int64)
        in_bounds = ((rounded[:, 0] >= 0) & (rounded[:, 0] < width)
                     & (rounded[:, 1] >= 0) & (rounded[:, 1] < height))
        on_robot = np.zeros(len(ends), dtype=bool)
        on_robot[in_bounds] = (following_robot_mask[
            rounded[in_bounds, 1], rounded[in_bounds, 0]] != 0)
        valid &= on_robot
    if int(valid.sum()) < config.min_features:
        return None, 0.0, float("inf")
    starts, ends, fb = starts[valid], ends[valid], fb[valid]
    flows = ends - starts
    distance = np.linalg.norm(starts - point, axis=1)
    weights = np.exp(-0.5 * (distance / max(config.patch_radius_px / 2, 1)) ** 2)
    weights /= np.maximum(1 + fb, 1e-6)
    translation = np.array([_weighted_median(flows[:, axis], weights) for axis in (0, 1)])
    deviations = np.linalg.norm(flows - translation, axis=1)
    consensus = deviations <= config.max_flow_spread_px
    if (int(consensus.sum()) < config.min_features or
            weights[consensus].sum() / weights.sum() < 0.60):
        return None, 0.0, float("inf")
    translation = np.average(flows[consensus], axis=0, weights=weights[consensus])
    spread = float(np.median(np.linalg.norm(flows[consensus] - translation, axis=1)))
    next_point = point + translation
    if np.linalg.norm(translation) > config.max_step_px or not (
        0 <= next_point[0] < width and 0 <= next_point[1] < height
    ):
        return None, 0.0, float("inf")
    if following_robot_mask is not None:
        x, y = np.rint(next_point).astype(int)
        x, y = min(x, width - 1), min(y, height - 1)
        if following_robot_mask[y, x] == 0:
            return None, 0.0, float("inf")
    fb_med = float(np.median(fb[consensus]))
    quality = (
        min(1.0, len(flows[consensus]) / 12.0)
        * math.exp(-fb_med / max(config.max_fb_error_px, 1e-6))
        * math.exp(-spread / max(config.max_flow_spread_px, 1e-6))
    )
    return next_point.astype(np.float32), float(quality), fb_med


def _candidate_track(frames: list[np.ndarray], anchor: int, point: np.ndarray,
                     barriers: set[int], config: TrackerConfig,
                     robot_masks: list[np.ndarray] | None = None) -> dict[int, dict[str, Any]]:
    result = {anchor: {"point": point.copy(), "quality": 1.0,
                       "fb_error_px": 0.0, "distance": 0, "anchor": anchor}}
    for direction in (-1, 1):
        current = anchor
        current_point = point.copy()
        min_quality = 1.0
        max_fb = 0.0
        for distance in range(1, config.max_gap_frames + 1):
            next_index = current + direction
            if next_index < 0 or next_index >= len(frames) or next_index in barriers:
                break
            next_point, step_quality, fb_error = _track_step(
                frames[current], frames[next_index], current_point, config,
                None if robot_masks is None else robot_masks[current],
                None if robot_masks is None else robot_masks[next_index],
            )
            if next_point is None:
                break
            min_quality = min(min_quality, step_quality)
            max_fb = max(max_fb, fb_error)
            quality = min_quality * math.exp(-distance / max(config.max_gap_frames, 1))
            result[next_index] = {"point": next_point, "quality": quality,
                                  "fb_error_px": max_fb, "distance": distance,
                                  "anchor": anchor}
            current = next_index
            current_point = next_point
    return result


def track_joint_points(frames: list[np.ndarray], names: list[str],
                       annotations: dict[str, dict[int, Any]],
                       config: TrackerConfig = TrackerConfig(),
                       robot_masks: list[np.ndarray] | None = None) -> list[dict[str, Any]]:
    if not frames or not names:
        raise ValueError("Need frames and joint names")
    if config.max_gap_frames < 1 or config.patch_radius_px < 3:
        raise ValueError("Invalid tracker radius or gap")
    if robot_masks is not None and (len(robot_masks) != len(frames) or any(
        mask.shape != frames[index].shape for index, mask in enumerate(robot_masks)
    )):
        raise ValueError("Robot masks must match every frame's dimensions")
    rows = []
    for name in names:
        keyframes = annotations[name]
        barriers = {index for index, (visibility, _) in keyframes.items()
                    if visibility != "visible"}
        invalid_anchors = set()
        if robot_masks is not None:
            for index, (visibility, point) in keyframes.items():
                if visibility != "visible":
                    continue
                x, y = np.rint(point).astype(int)
                x, y = min(x, frames[index].shape[1] - 1), min(y, frames[index].shape[0] - 1)
                if robot_masks[index][y, x] == 0:
                    invalid_anchors.add(index)
        barriers.update(invalid_anchors)
        candidates: dict[int, list[dict[str, Any]]] = {i: [] for i in range(len(frames))}
        for anchor, (visibility, point) in keyframes.items():
            if visibility != "visible" or anchor in invalid_anchors:
                continue
            for index, candidate in _candidate_track(
                frames, anchor, point, barriers, config, robot_masks
            ).items():
                if index not in barriers:
                    candidates[index].append(candidate)
        for index in range(len(frames)):
            row = {"frame_index": index, "joint_name": name, "u_px": "", "v_px": "",
                   "track_valid": False, "status": "untracked", "quality": 0.0,
                   "fb_error_px": "", "anchor_distance_frames": "",
                   "semantic_verified": False}
            if index in invalid_anchors:
                row["status"] = "anchor_outside_robot_mask"
            elif index in barriers:
                row["status"] = f"{keyframes[index][0]}_keyframe"
            elif robot_masks is not None and not np.any(robot_masks[index]):
                row["status"] = "robot_mask_empty"
            elif candidates[index]:
                selected = sorted(candidates[index], key=lambda item: item["distance"])[:2]
                disagreement = 0.0
                if len(selected) == 2:
                    disagreement = float(np.linalg.norm(selected[0]["point"] - selected[1]["point"]))
                if disagreement > config.max_anchor_disagreement_px:
                    row["status"] = "anchor_disagreement"
                else:
                    weights = np.array([max(item["quality"], 1e-6) for item in selected])
                    point = np.average([item["point"] for item in selected], axis=0, weights=weights)
                    quality = min(item["quality"] for item in selected)
                    quality *= math.exp(-disagreement / max(config.max_anchor_disagreement_px, 1e-6))
                    if quality >= config.min_track_quality:
                        row.update({"u_px": round(float(point[0]), 3),
                                    "v_px": round(float(point[1]), 3),
                                    "track_valid": True,
                                    "status": "vlm_anchor" if selected[0]["distance"] == 0
                                    else ("bidirectional" if len(selected) == 2 else "flow"),
                                    "quality": round(quality, 4),
                                    "fb_error_px": round(max(item["fb_error_px"] for item in selected), 3),
                                    "anchor_distance_frames": min(item["distance"] for item in selected)})
                    else:
                        row["status"] = "low_flow_quality"
            rows.append(row)
    rows.sort(key=lambda row: (row["frame_index"], names.index(row["joint_name"])))
    return rows


def run(frame_folder: Path, keyframes_file: Path, output_csv: Path,
        report_json: Path, config: TrackerConfig = TrackerConfig(),
        mask_folder: Path | None = None,
        timestamp_file: Path | None = None) -> dict[str, Any]:
    frame_indices, paths, frames = load_frames(frame_folder)
    height, width = frames[0].shape
    timestamps = load_timestamps(timestamp_file, frame_indices,
                                 [path.name for path in paths])
    frame_hashes = {path.name: _hash_file(path) for path in paths}
    names, annotations, counts = load_keyframes(keyframes_file, paths, (width, height))
    robot_masks = None
    mask_hashes = None
    if mask_folder is not None:
        mask_paths = [mask_folder / f"{path.stem}.png" for path in paths]
        if any(not mask_path.is_file() for mask_path in mask_paths):
            raise ValueError("Mask folder needs a frame_XXXX.png mask for every image")
        robot_masks = []
        for mask_path in mask_paths:
            mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
            if mask is None or mask.shape != frames[0].shape:
                raise ValueError(f"Cannot decode matching robot mask: {mask_path}")
            robot_masks.append(np.where(mask > 0, 255, 0).astype(np.uint8))
        mask_hashes = {path.name: _hash_file(path) for path in mask_paths}
    rows = track_joint_points(frames, names, annotations, config, robot_masks)
    for row in rows:
        position = row["frame_index"]
        row["frame_index"] = frame_indices[position]
        row["image"] = paths[position].name
        row["frame_sha256"] = frame_hashes[paths[position].name]
        row["timestamp_ns"] = timestamps[frame_indices[position]]
    fieldnames = ["frame_index", "image", "joint_name", "u_px", "v_px", "track_valid",
                  "status", "quality", "fb_error_px", "anchor_distance_frames",
                  "semantic_verified", "frame_sha256", "timestamp_ns"]
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    rates = {name: sum(row["track_valid"] for row in rows if row["joint_name"] == name) / len(frames)
             for name in names}
    report = {
        "status": "diagnostic_2d_tracks_only",
        "frame_folder": str(frame_folder.resolve()),
        "keyframes_file": str(keyframes_file.resolve()),
        "frame_count": len(frames),
        "image_size": [width, height],
        "joint_names": names,
        "frame_sha256_by_image": frame_hashes,
        "timestamp_file": str(timestamp_file.resolve()) if timestamp_file else None,
        "parsed_keyframes": counts["parsed_records"],
        "invalid_keyframes": counts["invalid_records"],
        "tracking_coverage_by_joint": rates,
        "tracker_config": vars(config),
        "robot_mask_folder": str(mask_folder.resolve()) if mask_folder else None,
        "robot_mask_sha256_by_frame": mask_hashes,
        "robot_mask_used": mask_folder is not None,
        "output_csv": str(output_csv.resolve()),
        "limitation": "VLM pixels and optical-flow tracks are unverified 2-D proposals, never angle ground truth or safe robot control outputs.",
    }
    report_json.parent.mkdir(parents=True, exist_ok=True)
    report_json.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frames", type=Path, required=True)
    parser.add_argument("--keyframes", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--max-gap-frames", type=int, default=60)
    parser.add_argument("--patch-radius-px", type=int, default=22)
    parser.add_argument("--mask-dir", type=Path,
                        help="Optional independent binary robot masks, frame_XXXX.png")
    parser.add_argument("--timestamps", type=Path,
                        help="Optional CSV with frame_index,camera_time_ns[,image] (timestamp_ns alias accepted)")
    args = parser.parse_args()
    config = TrackerConfig(max_gap_frames=args.max_gap_frames,
                           patch_radius_px=args.patch_radius_px)
    report = run(args.frames, args.keyframes, args.output,
                 args.report or args.output.with_suffix(".report.json"), config,
                 args.mask_dir, args.timestamps)
    print(json.dumps({"output_csv": report["output_csv"],
                      "tracking_coverage_by_joint": report["tracking_coverage_by_joint"]},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
