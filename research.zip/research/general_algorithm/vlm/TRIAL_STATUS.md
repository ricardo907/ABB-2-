# 本次运行记录（2026-11-11）

- `python work/tro_vlm/selfcheck.py`：通过。覆盖正确/错误 JSON、重复键、关节名称、可见性、像素界、连杆名以及直接角度字段的严格验证。
- `semantic_keyframes.py --backend mock`：对现有 Exp001 `frame_0000.jpg` 成功生成结构化记录，包含真实帧 SHA-256；此记录中的全部语义值是人工 mock，不是 VLM 实测。
- `direct_angle_baseline.py --backend mock`：CLI 完成；显式 prismatic 类型按预期拒绝。mock 角度不是实际估计或真值。
- 本机显卡：NVIDIA GeForce RTX 4090，约 24 GB 显存。系统 Python 3.10.9、PyTorch 2.0.1、Transformers 4.24.0。隔离 `work/tro_vlm/.venv` 安装了 Transformers 4.57.6 等；新版 Transformers 不支持当前 PyTorch 2.0.1。
- 为独立环境安装官方 PyTorch 2.8.0+cu128 时，3.46 GB wheel 下载数分钟未完成，已中止。Qwen3-VL 权重因此尚未下载，真实 Qwen 推理、加载时间、生成时间、峰值显存均**没有测得**。
- 用系统环境尝试 `openai/clip-vit-base-patch32` 对 Exp001 一帧做图文匹配：只下载了小配置文件，后续权重请求长时间无字节进展，已中止。因此 CLIP 也**没有真实推理结果**。
- 清理中断下载留下的约 353 MB 临时 wheel 时，自动审核拒绝删除命令，理由仅为 `blocked by policy`；残留在 `work/tro_vlm/temp`。

不应把 mock 解析成功写为 VLM 视觉定位成功，亦不应报告未测得的准确率、延迟或显存。
