"""Synthetic translation, occlusion, scaling, and hash checks."""

from __future__ import annotations

import json
import csv
import tempfile
from pathlib import Path

import cv2
import numpy as np

from track_joint_points import _hash_file, run


def _background_mask_selfcheck(base: Path) -> None:
    """Keep a moving textured link when static background has nearby corners."""
    frames_dir = base / "background_frames"
    masks_dir = base / "robot_masks"
    frames_dir.mkdir()
    masks_dir.mkdir()
    rng = np.random.default_rng(23)
    moving = rng.integers(45, 230, size=(23, 23), dtype=np.uint8)
    stationary = rng.integers(20, 245, size=(31, 31), dtype=np.uint8)
    paths = []
    for index in range(10):
        image = np.full((100, 170), 12, dtype=np.uint8)
        image[35:66, 22:53] = stationary
        left = 58 + 2 * index
        image[39:62, left:left + 23] = moving
        mask = np.zeros_like(image)
        mask[39:62, left:left + 23] = 255
        frame_path = frames_dir / f"frame_{index:04d}.png"
        assert cv2.imwrite(str(frame_path), image)
        assert cv2.imwrite(str(masks_dir / frame_path.name), mask)
        paths.append(frame_path)
    annotation = {
        "schema_version": "robot-joint-semantic-keyframe-v1",
        "joint_names": ["joint_1"],
        "records": [{
            "frame": str(paths[0].resolve()),
            "frame_sha256": _hash_file(paths[0]),
            "original_size": [170, 100], "inference_size": [170, 100],
            "status": "parsed_diagnostic_only",
            "annotation": {"joints": [{
                "joint_name": "joint_1", "visibility": "visible",
                "uv": [69, 50], "link_name": None,
            }]},
        }],
    }
    keyframes = base / "background_keyframes.json"
    keyframes.write_text(json.dumps(annotation), encoding="utf-8")
    output = base / "masked_tracks.csv"
    report = run(frames_dir, keyframes, output, base / "masked_report.json",
                 mask_folder=masks_dir)
    with output.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for index, row in enumerate(rows):
        assert row["track_valid"] == "True", (index, row)
        assert abs(float(row["u_px"]) - (69.5 + 2 * index)) < 2.5, (index, row)
    assert report["robot_mask_used"] is True
    assert len(report["robot_mask_sha256_by_frame"]) == 10

    # An anchor on the background must fail independently of optical-flow quality.
    first_mask = np.zeros((100, 170), dtype=np.uint8)
    assert cv2.imwrite(str(masks_dir / paths[0].name), first_mask)
    run(frames_dir, keyframes, output, base / "masked_report.json",
        mask_folder=masks_dir)
    with output.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["status"] == "anchor_outside_robot_mask"
    assert all(row["track_valid"] == "False" for row in rows)


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        base = Path(temporary)
        frames_dir = base / "frames"
        frames_dir.mkdir()
        rng = np.random.default_rng(7)
        texture = rng.integers(40, 240, size=(25, 25), dtype=np.uint8)
        paths = []
        for index in range(13):
            image = np.full((120, 160), 10, dtype=np.uint8)
            if index not in (5, 6, 7):
                left, top = 28 + 2 * index, 38
                image[top:top + 25, left:left + 25] = texture
            path = frames_dir / f"frame_{index:04d}.png"
            assert cv2.imwrite(str(path), image)
            paths.append(path)

        records = []
        for index, visibility, uv in (
            (0, "visible", [20, 25]),
            (6, "occluded", None),
            (12, "visible", [32, 25]),
        ):
            records.append({
                "frame": str(paths[index].resolve()),
                "frame_sha256": _hash_file(paths[index]),
                "original_size": [160, 120],
                "inference_size": [80, 60],
                "status": "parsed_diagnostic_only",
                "annotation": {"joints": [
                    {"joint_name": "joint_1", "visibility": visibility,
                     "uv": uv, "link_name": None},
                    {"joint_name": "joint_2", "visibility": "unknown",
                     "uv": None, "link_name": None},
                ]},
            })
        annotation = {
            "schema_version": "robot-joint-semantic-keyframe-v1",
            "joint_names": ["joint_1", "joint_2"],
            "records": records,
        }
        keyframes = base / "semantic_keyframes.json"
        keyframes.write_text(json.dumps(annotation), encoding="utf-8")
        output_csv = base / "tracks.csv"
        timestamps = base / "timestamps.csv"
        with timestamps.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(("frame_index", "camera_time_ns", "image"))
            writer.writerows((index, 1_000_000 + 100_000 * index,
                              paths[index].name)
                             for index in range(13))
        report = run(frames_dir, keyframes, output_csv, base / "report.json",
                     timestamp_file=timestamps)
        with output_csv.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        by_joint = {name: [row for row in rows if row["joint_name"] == name]
                    for name in ("joint_1", "joint_2")}
        first = by_joint["joint_1"]
        assert first[0]["track_valid"] == "True"
        assert abs(float(first[0]["u_px"]) - 40.5) < 1.0  # scaled VLM pixel centre
        for index in (1, 2, 3, 4, 8, 9, 10, 11, 12):
            assert first[index]["track_valid"] == "True", (index, first[index])
            assert abs(float(first[index]["u_px"]) - (40.5 + 2 * index)) < 2.5
        assert all(first[index]["track_valid"] == "False" for index in (5, 6, 7))
        assert first[6]["status"] == "occluded_keyframe"
        assert all(row["track_valid"] == "False" for row in by_joint["joint_2"])
        assert all(row["semantic_verified"] == "False" for row in rows)
        assert rows[0]["timestamp_ns"] == "1000000"
        assert rows[0]["frame_sha256"] == _hash_file(paths[0])
        assert report["tracking_coverage_by_joint"]["joint_1"] > 0.6

        with timestamps.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(("frame_index", "timestamp_ns"))
            writer.writerows((index, 1_000_000 - 100_000 * index)
                             for index in range(13))
        try:
            run(frames_dir, keyframes, output_csv, base / "report.json",
                timestamp_file=timestamps)
        except ValueError as exc:
            assert "timestamps" in str(exc)
        else:
            raise AssertionError("Nonmonotonic camera timestamps were accepted")

        annotation["records"][0]["frame_sha256"] = "0" * 64
        keyframes.write_text(json.dumps(annotation), encoding="utf-8")
        try:
            run(frames_dir, keyframes, output_csv, base / "report.json")
        except ValueError as exc:
            assert "SHA-256 mismatch" in str(exc)
        else:
            raise AssertionError("Stale keyframe hash was accepted")
        _background_mask_selfcheck(base)
        print("VLM point tracker selfcheck passed: translation, occlusion, mask, timestamps, hash")


if __name__ == "__main__":
    main()
