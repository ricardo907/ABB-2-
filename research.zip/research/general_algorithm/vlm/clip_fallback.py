"""One-frame CLIP smoke test: coarse image/text similarity only.

CLIP is not a joint detector, angle estimator, or safety signal. This script
only checks that local image-model inference can run on the supplied frame.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import torch
from PIL import Image
from transformers import CLIPModel, CLIPProcessor

from semantic_keyframes import sha256_file


MODEL_ID = "openai/clip-vit-base-patch32"
TEXTS = [
    "A white industrial robot arm is visible on a table.",
    "A table with no robot arm visible.",
    "A robot arm is fully hidden behind another object.",
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frame", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, default=Path(__file__).resolve().parent / "cache")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    started = perf_counter()
    processor = CLIPProcessor.from_pretrained(
        MODEL_ID, cache_dir=str(args.cache_dir), local_files_only=args.offline
    )
    model = CLIPModel.from_pretrained(
        MODEL_ID, cache_dir=str(args.cache_dir), local_files_only=args.offline
    ).to(device).eval()
    load_seconds = perf_counter() - started
    with Image.open(args.frame) as source:
        image = source.convert("RGB")
    inputs = processor(text=TEXTS, images=image, return_tensors="pt", padding=True)
    inputs = {key: value.to(device) for key, value in inputs.items()}
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    started = perf_counter()
    with torch.inference_mode():
        logits = model(**inputs).logits_per_image[0]
    generation_seconds = perf_counter() - started
    result = {
        "schema_version": "clip-image-text-smoke-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "model-inference smoke test only; not joint localization, angle truth or safety output",
        "model_id": MODEL_ID,
        "model_revision_resolved": getattr(model.config, "_commit_hash", None),
        "frame": str(args.frame.resolve()),
        "frame_sha256": sha256_file(args.frame),
        "device": device,
        "torch_version": torch.__version__,
        "transformers_version": __import__("transformers").__version__,
        "load_seconds": round(load_seconds, 3),
        "generation_seconds": round(generation_seconds, 3),
        "cuda_peak_memory_mb": round(torch.cuda.max_memory_allocated() / 2**20, 1) if device == "cuda" else None,
        "texts": TEXTS,
        "similarity_logits": [round(float(item), 5) for item in logits.cpu()],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"CLIP smoke inference completed on {device}; output={args.output}")


if __name__ == "__main__":
    main()
