"""Per-robot diagnostic angle regressor from tracked 2-D VLM joint pixels.

The regressor is an experimental branch, independent of the main estimator.
It uses encoder labels for fitting; VLM pixels are unverified observations,
never angle ground truth. Missing or out-of-support visual observations abstain.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler


TRACK_COLUMNS = {"frame_index", "image", "joint_name", "u_px", "v_px",
                 "track_valid", "quality"}
MODEL_VERSION = "vlm-track-local-ridge-v2"
SHA256 = re.compile(r"[0-9a-f]{64}")


def _save_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _booleans(values: pd.Series) -> np.ndarray:
    raw = values.astype(str).str.lower().str.strip()
    if not raw.isin(("true", "false", "1", "0")).all():
        raise ValueError("track_valid must contain only true/false or 1/0")
    return raw.isin(("true", "1")).to_numpy()


def read_track_features(path: Path, joint_names: list[str], width: int, height: int,
                        min_quality: float) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    if width < 1 or height < 1 or not (0 <= min_quality <= 1):
        raise ValueError("Image dimensions must be positive and min_quality in [0,1]")
    if not joint_names or len(joint_names) != len(set(joint_names)):
        raise ValueError("joint_names must be unique and nonempty")
    table = pd.read_csv(path)
    missing = TRACK_COLUMNS - set(table)
    if missing:
        raise ValueError(f"Track CSV missing columns: {sorted(missing)}")
    if table.empty or table[["frame_index", "image", "joint_name"]].isna().any().any():
        raise ValueError("Track CSV is empty or has missing frame/joint identity")
    if table.duplicated(["image", "joint_name"]).any():
        raise ValueError("Duplicate image/joint rows")
    if set(table["joint_name"]) != set(joint_names):
        raise ValueError("Track joint set differs from requested joint_names")
    optional = [name for name in ("frame_sha256", "timestamp_ns") if name in table]
    frame_meta = table[["image", "frame_index", *optional]].drop_duplicates()
    if frame_meta.duplicated("image").any() or frame_meta.duplicated("frame_index").any():
        raise ValueError("Image and frame_index must map one-to-one")
    frame_meta["frame_index"] = pd.to_numeric(frame_meta["frame_index"], errors="raise")
    if not np.isfinite(frame_meta["frame_index"].to_numpy()).all():
        raise ValueError("frame_index must be finite")
    if "frame_sha256" in frame_meta and not frame_meta["frame_sha256"].astype(str).str.fullmatch(SHA256).all():
        raise ValueError("frame_sha256 must be a lowercase SHA-256 hex digest")
    if "timestamp_ns" in frame_meta:
        raw = frame_meta["timestamp_ns"]
        if raw.notna().any():
            parsed = pd.to_numeric(raw, errors="raise")
            if parsed.isna().any() or not np.isfinite(parsed.to_numpy(dtype=float)).all():
                raise ValueError("All timestamp_ns values must be finite when supplied")
            if (parsed < 0).any() or not (parsed % 1 == 0).all():
                raise ValueError("timestamp_ns must contain nonnegative integers")
            frame_meta["timestamp_ns"] = parsed.astype("int64")
    frame_meta = frame_meta.sort_values("frame_index").reset_index(drop=True)
    frame_indices = frame_meta["frame_index"].to_numpy()
    if np.any(np.diff(frame_indices) <= 0):
        raise ValueError("frame_index must increase")
    if "timestamp_ns" in frame_meta and frame_meta["timestamp_ns"].notna().any():
        if np.any(np.diff(frame_meta["timestamp_ns"].to_numpy(dtype=np.int64)) <= 0):
            raise ValueError("timestamp_ns must increase with frame_index")
    row_lookup = table.set_index(["image", "joint_name"])
    features = np.zeros((len(frame_meta), 4 * len(joint_names)), dtype=np.float64)
    complete = np.ones(len(frame_meta), dtype=bool)
    for row_index, image in enumerate(frame_meta["image"]):
        for joint_index, name in enumerate(joint_names):
            if (image, name) not in row_lookup.index:
                complete[row_index] = False
                continue
            row = row_lookup.loc[(image, name)]
            valid = bool(_booleans(pd.Series([row["track_valid"]]))[0])
            quality = float(row["quality"])
            if not np.isfinite(quality) or not (0 <= quality <= 1):
                raise ValueError("Track quality must be finite in [0,1]")
            if not valid or quality < min_quality:
                complete[row_index] = False
                continue
            u, v = float(row["u_px"]), float(row["v_px"])
            if not np.isfinite([u, v]).all() or not (0 <= u < width and 0 <= v < height):
                raise ValueError("Valid tracked point is missing or outside image bounds")
            position = 4 * joint_index
            features[row_index, position:position + 4] = (u / width, v / height, 1.0, quality)
    return frame_meta, features, complete


def _check_joint_types(joint_types: list[str], joint_count: int) -> None:
    if len(joint_types) != joint_count or any(
        kind not in ("revolute", "continuous", "prismatic") for kind in joint_types
    ):
        raise ValueError("joint_types must match joints and use revolute/continuous/prismatic")


def _support_map(joint_names: list[str], requested: dict[str, list[str]] | None
                 ) -> dict[str, list[str]]:
    """Define the visible landmarks required for each independent angle fit.

    The default pairs adjacent tracked points in a serial ordering. It is a
    feature-selection rule, not a claim of physical observability. A robot
    study should supply its own map and test it on held-out encoder labels.
    """
    if requested is None:
        requested = {}
        for index, name in enumerate(joint_names):
            neighbor = min(index + 1, len(joint_names) - 1)
            if neighbor == index and index > 0:
                neighbor = index - 1
            requested[name] = list(dict.fromkeys((name, joint_names[neighbor])))
    if set(requested) != set(joint_names):
        raise ValueError("support_map must have exactly one entry for each output joint")
    for name, landmarks in requested.items():
        if (type(landmarks) is not list or not landmarks or
                any(point not in joint_names for point in landmarks) or
                len(landmarks) != len(set(landmarks))):
            raise ValueError(f"Invalid support landmarks for {name}")
    return {name: list(requested[name]) for name in joint_names}


def _local_columns(joint_names: list[str], landmarks: list[str]) -> list[int]:
    return [4 * joint_names.index(name) + offset
            for name in landmarks for offset in (0, 1)]


def train(tracks: Path, labels: Path, model_path: Path, *,
          robot_id: str, camera_id: str, joint_names: list[str],
          label_columns: list[str], joint_types: list[str],
          width: int, height: int, min_quality: float = 0.15,
          ridge_alpha: float = 10.0,
          support_map: dict[str, list[str]] | None = None) -> dict:
    if not robot_id or not camera_id:
        raise ValueError("robot_id and camera_id are required")
    if len(joint_names) != len(label_columns) or len(set(label_columns)) != len(label_columns):
        raise ValueError("label_columns must map one-to-one to joint_names in order")
    _check_joint_types(joint_types, len(joint_names))
    if ridge_alpha <= 0:
        raise ValueError("ridge_alpha must be positive")
    supports = _support_map(joint_names, support_map)
    frame_meta, features, complete = read_track_features(
        tracks, joint_names, width, height, min_quality
    )
    label_table = pd.read_csv(labels)
    if "camera_time_ns" in label_table:
        if "timestamp_ns" in label_table:
            if not (label_table["camera_time_ns"] == label_table["timestamp_ns"]).all():
                raise ValueError("Encoder label camera_time_ns and timestamp_ns disagree")
        else:
            label_table = label_table.rename(columns={"camera_time_ns": "timestamp_ns"})
    if "image" not in label_table or not set(label_columns) <= set(label_table):
        raise ValueError("Labels need image and explicitly mapped joint columns")
    if label_table["image"].duplicated().any():
        raise ValueError("Labels have duplicate image names")
    label_metadata = [name for name in ("timestamp_ns", "frame_sha256")
                      if name in label_table]
    merged = frame_meta.merge(label_table[["image", *label_columns, *label_metadata]],
                              on="image", how="left", validate="one_to_one",
                              suffixes=("", "_label"))
    alignment_checks = []
    for column in ("timestamp_ns", "frame_sha256"):
        label_column = f"{column}_label"
        if column not in frame_meta or label_column not in merged:
            continue
        both = merged[column].notna() & merged[label_column].notna()
        if both.any():
            if column == "timestamp_ns":
                left = merged.loc[both, column].astype("int64")
                right = merged.loc[both, label_column].astype("int64")
            else:
                left = merged.loc[both, column].astype(str)
                right = merged.loc[both, label_column].astype(str)
            if not (left.to_numpy() == right.to_numpy()).all():
                raise ValueError(f"Encoder labels {column} differs from track frames")
            alignment_checks.append(column)
    raw_y = merged[label_columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    observed = features[:, 2::4] > 0
    models = {}
    per_joint_training_frames = {}
    per_joint_radius = {}
    for joint_index, name in enumerate(joint_names):
        landmark_indices = [joint_names.index(point) for point in supports[name]]
        eligible = observed[:, landmark_indices].all(axis=1)
        eligible &= np.isfinite(raw_y[:, joint_index])
        minimum = max(20, 4 * len(landmark_indices))
        if int(eligible.sum()) < minimum:
            raise ValueError(f"Need at least {minimum} labeled frames with landmarks "
                             f"{supports[name]} for {name}; have {int(eligible.sum())}")
        columns = _local_columns(joint_names, supports[name])
        x = features[eligible][:, columns]
        y = raw_y[eligible, joint_index].copy()
        if joint_types[joint_index] == "continuous":
            y = np.unwrap(y)
        scaler = StandardScaler().fit(x)
        z = scaler.transform(x)
        regressor = Ridge(alpha=ridge_alpha).fit(z, y)
        neighbors = NearestNeighbors(n_neighbors=2).fit(z)
        train_distances = neighbors.kneighbors(z, return_distance=True)[0][:, 1]
        radius = max(float(np.percentile(train_distances, 95) * 2), 0.25)
        models[name] = {"columns": columns, "scaler": scaler,
                        "regressor": regressor, "neighbors": neighbors,
                        "support_radius": radius}
        per_joint_training_frames[name] = int(eligible.sum())
        per_joint_radius[name] = radius
    bundle = {
        "model_version": MODEL_VERSION,
        "robot_id": robot_id,
        "camera_id": camera_id,
        "joint_names": list(joint_names),
        "label_columns": list(label_columns),
        "joint_types": list(joint_types),
        "training_size_by_joint": per_joint_training_frames,
        "image_size": [width, height],
        "min_quality": min_quality,
        "support_map": supports,
        "models": models,
        "source_tracks": str(tracks.resolve()),
        "source_labels": str(labels.resolve()),
        "source_tracks_sha256": _sha256(tracks),
        "source_labels_sha256": _sha256(labels),
        "label_alignment_checks": alignment_checks,
        "limitation": ("Per-robot, per-camera diagnostic fit; VLM pixels are unverified, "
                       "source-neighborhood support is uncalibrated, and no cross-robot "
                       "accuracy is implied."),
    }
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, model_path)
    report = {
        "model": str(model_path.resolve()),
        "joint_names": joint_names,
        "joint_types": joint_types,
        "robot_id": robot_id,
        "camera_id": camera_id,
        "total_track_frames": len(frame_meta),
        "fully_tracked_labeled_frames": int((complete & np.isfinite(raw_y).all(axis=1)).sum()),
        "source_coverage_by_joint": {name: count / len(frame_meta)
                                     for name, count in per_joint_training_frames.items()},
        "training_frames_by_joint": per_joint_training_frames,
        "support_radius_by_joint": per_joint_radius,
        "support_map": supports,
        "label_alignment_checks": alignment_checks,
        "label_timing_verified": "timestamp_ns" in alignment_checks,
        "warning": bundle["limitation"],
    }
    _save_json(model_path.with_suffix(".report.json"), report)
    return report


def infer(tracks: Path, model_path: Path, output: Path, *, robot_id: str,
          camera_id: str, width: int, height: int) -> dict:
    bundle = joblib.load(model_path)
    if bundle.get("model_version") != MODEL_VERSION:
        raise ValueError("Unknown model version")
    if robot_id != bundle["robot_id"] or camera_id != bundle["camera_id"]:
        raise ValueError("Robot/camera ID differs from calibration model")
    names = bundle["joint_names"]
    frame_meta, features, complete = read_track_features(
        tracks, names, width, height, bundle["min_quality"]
    )
    if bundle["image_size"] != [width, height]:
        raise ValueError("Image size differs from calibration model")
    angles = np.full((len(frame_meta), len(names)), np.nan)
    safe = angles.copy()
    distance = np.full_like(angles, np.nan)
    reliable = np.zeros_like(angles, dtype=bool)
    statuses = np.full(angles.shape, "missing_2d_observation", dtype=object)
    observed = features[:, 2::4] > 0
    for joint_index, name in enumerate(names):
        landmarks = bundle["support_map"][name]
        required = [names.index(point) for point in landmarks]
        eligible = observed[:, required].all(axis=1)
        if not eligible.any():
            continue
        model = bundle["models"][name]
        x = features[eligible][:, model["columns"]]
        z = model["scaler"].transform(x)
        predictions = model["regressor"].predict(z)
        support = model["neighbors"].kneighbors(
            z, n_neighbors=1, return_distance=True)[0][:, 0]
        angles[eligible, joint_index] = predictions
        distance[eligible, joint_index] = support
        accepted = support <= model["support_radius"]
        reliable[eligible, joint_index] = accepted
        safe[eligible, joint_index] = np.where(accepted, predictions, np.nan)
        statuses[eligible, joint_index] = np.where(
            accepted, "within_source_support", "out_of_source_support")
    result = frame_meta.copy()
    result["status"] = np.where(
        ~observed.any(axis=1), "missing_2d_observation",
        np.where(reliable.all(axis=1), "within_source_support",
                 "partial_or_out_of_source_support"))
    result["fully_tracked"] = complete
    result["nearest_source_distance"] = np.where(
        np.isfinite(distance).any(axis=1),
        np.nanmax(np.where(np.isfinite(distance), distance, -np.inf), axis=1),
        np.nan)
    for index, name in enumerate(names):
        result[f"pred__{name}"] = angles[:, index]
        result[f"safe__{name}"] = safe[:, index]
        result[f"reliable__{name}"] = reliable[:, index]
        result[f"status__{name}"] = statuses[:, index]
        result[f"nearest_source_distance__{name}"] = distance[:, index]
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    report = {
        "model": str(model_path.resolve()),
        "predictions": str(output.resolve()),
        "frame_count": len(result),
        "fully_tracked_fraction": float(complete.mean()),
        "safe_fraction": float(reliable.mean()),
        "safe_fraction_by_joint": {name: float(reliable[:, index].mean())
                                   for index, name in enumerate(names)},
        "support_map": bundle["support_map"],
        "warning": "2-D VLM tracks are not validated physical joint centers; pred__ values are diagnostic only, and safe__ is an uncalibrated support filter.",
    }
    _save_json(output.with_suffix(".report.json"), report)
    return report


def evaluate(predictions: Path, labels: Path, output: Path, *,
             model_path: Path, label_status: str) -> dict:
    if label_status not in ("verified", "provisional"):
        raise ValueError("label_status must be verified or provisional")
    bundle = joblib.load(model_path)
    names = bundle["joint_names"]
    columns = bundle["label_columns"]
    pred = pd.read_csv(predictions)
    truth = pd.read_csv(labels)
    if "image" not in pred or "image" not in truth or not set(columns) <= set(truth):
        raise ValueError("Predictions and labels need image and mapped joint columns")
    if pred["image"].duplicated().any() or truth["image"].duplicated().any():
        raise ValueError("Evaluation image names must be unique")
    merged = pred.merge(truth[["image", *columns]], on="image", how="inner", validate="one_to_one")
    if merged.empty:
        raise ValueError("No matching images")
    actual = merged[columns].to_numpy(dtype=np.float64)
    predicted = merged[[f"pred__{name}" for name in names]].to_numpy(dtype=np.float64)
    reliable = np.column_stack([
        _booleans(merged[f"reliable__{name}"]) for name in names
    ])
    errors = np.abs(actual - predicted)
    for index, kind in enumerate(bundle["joint_types"]):
        if kind == "continuous":
            errors[:, index] = np.abs((actual[:, index] - predicted[:, index] + np.pi) % (2 * np.pi) - np.pi)
    per_joint = []
    for index, name in enumerate(names):
        valid = np.isfinite(errors[:, index]) & np.isfinite(actual[:, index])
        accepted = valid & reliable[:, index]
        per_joint.append({
            "joint_name": name,
            "unit": "m" if bundle["joint_types"][index] == "prismatic" else "rad",
            "diagnostic_mae": float(np.mean(errors[valid, index])) if valid.any() else None,
            "safe_mae": float(np.mean(errors[accepted, index])) if accepted.any() else None,
            "safe_coverage": float(reliable[:, index].mean()),
            "matched_with_diagnostic": int(valid.sum()),
        })
    report = {
        "label_status": label_status,
        "matched_frames": len(merged),
        "per_joint": per_joint,
        "warning": "Provisional labels are not verified accuracy" if label_status == "provisional" else
                   "Verified means supplied labels were declared verified; this tool does not independently audit their source.",
    }
    _save_json(output, report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    p = actions.add_parser("train")
    p.add_argument("--tracks", type=Path, required=True)
    p.add_argument("--labels", type=Path, required=True)
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--robot-id", required=True)
    p.add_argument("--camera-id", required=True)
    p.add_argument("--joint-names", nargs="+", required=True)
    p.add_argument("--label-columns", nargs="+", required=True)
    p.add_argument("--joint-types", nargs="+", choices=("revolute", "continuous", "prismatic"))
    p.add_argument("--image-width", type=int, required=True)
    p.add_argument("--image-height", type=int, required=True)
    p.add_argument("--min-quality", type=float, default=0.15)
    p.add_argument("--ridge-alpha", type=float, default=10.0)
    p.add_argument("--support-map", type=Path,
                   help="JSON mapping each output joint to required tracked joint names")
    p = actions.add_parser("infer")
    p.add_argument("--tracks", type=Path, required=True)
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--robot-id", required=True)
    p.add_argument("--camera-id", required=True)
    p.add_argument("--image-width", type=int, required=True)
    p.add_argument("--image-height", type=int, required=True)
    p = actions.add_parser("evaluate")
    p.add_argument("--predictions", type=Path, required=True)
    p.add_argument("--labels", type=Path, required=True)
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--label-status", choices=("verified", "provisional"), required=True)
    p.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.action == "train":
        report = train(args.tracks, args.labels, args.model, robot_id=args.robot_id,
                       camera_id=args.camera_id, joint_names=args.joint_names,
                       label_columns=args.label_columns,
                       joint_types=args.joint_types or ["revolute"] * len(args.joint_names),
                       width=args.image_width, height=args.image_height,
                       min_quality=args.min_quality, ridge_alpha=args.ridge_alpha,
                       support_map=json.loads(args.support_map.read_text(encoding="utf-8"))
                       if args.support_map else None)
    elif args.action == "infer":
        report = infer(args.tracks, args.model, args.output, robot_id=args.robot_id,
                       camera_id=args.camera_id, width=args.image_width, height=args.image_height)
    else:
        report = evaluate(args.predictions, args.labels, args.output,
                          model_path=args.model, label_status=args.label_status)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
