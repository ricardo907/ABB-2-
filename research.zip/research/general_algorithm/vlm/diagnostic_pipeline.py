"""Reproducible VLM-keyframe to numeric *diagnostic* pipeline.

This entry point consumes semantic_keyframes.py JSON. Real VLM inference is a
separate prerequisite; a mock annotation does not establish 2-D or angle
accuracy. No output from this module is suitable for robot control.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

if __package__:
    from . import joint_track_regressor
    from .track_joint_points import TrackerConfig, _hash_file, run as run_tracker
else:
    import joint_track_regressor
    from track_joint_points import TrackerConfig, _hash_file, run as run_tracker


SCHEMA_VERSION = "robot-vlm-numeric-diagnostic-v1"


def _read_tracks(path: Path, names: list[str], frame_hashes: dict[str, str]
                 ) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or len(rows) % len(names):
        raise ValueError("Tracker CSV does not contain a full ordered joint grid")
    frames = []
    for start in range(0, len(rows), len(names)):
        group = rows[start:start + len(names)]
        if [row["joint_name"] for row in group] != names:
            raise ValueError("Tracker joint order differs from semantic joint order")
        first = group[0]
        if any((row["frame_index"], row["image"], row["frame_sha256"],
                row["timestamp_ns"]) !=
               (first["frame_index"], first["image"], first["frame_sha256"],
                first["timestamp_ns"]) for row in group):
            raise ValueError("Tracker rows disagree on frame identity or timestamp")
        if first["frame_sha256"] != frame_hashes[first["image"]]:
            raise ValueError("Tracker frame SHA-256 differs from frame manifest")
        frame_index = int(first["frame_index"])
        if frames and frame_index != frames[-1]["frame_index"] + 1:
            raise ValueError("Tracker frame indices must be consecutive")
        joints = []
        for row in group:
            valid = row["track_valid"].strip().lower() == "true"
            joints.append({
                "joint_name": row["joint_name"],
                "status": row["status"],
                "track_valid": valid,
                "u_px": float(row["u_px"]) if valid else None,
                "v_px": float(row["v_px"]) if valid else None,
                "quality": float(row["quality"]),
                "semantic_verified": row["semantic_verified"].strip().lower() == "true",
            })
        count = sum(joint["track_valid"] for joint in joints)
        frames.append({
            "frame_index": frame_index,
            "image": first["image"],
            "frame_sha256": first["frame_sha256"],
            "timestamp_ns": int(first["timestamp_ns"]) if first["timestamp_ns"] else None,
            "joint_names": list(names),
            "status": ("no_valid_2d_track" if count == 0 else
                       "full_2d_track_diagnostic_only" if count == len(names) else
                       "partial_2d_track_diagnostic_only"),
            "tracked_joint_count": count,
            "tracks": joints,
        })
    if {frame["image"] for frame in frames} != set(frame_hashes):
        raise ValueError("Tracker frame set differs from input frame manifest")
    return frames


def _attach_regressor(frames: list[dict[str, Any]], predictions: Path,
                      names: list[str]) -> None:
    with predictions.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != len(frames):
        raise ValueError("Regressor output frame count differs from tracks")
    for frame, row in zip(frames, rows):
        if (int(row["frame_index"]) != frame["frame_index"] or
                row["image"] != frame["image"] or
                row.get("frame_sha256") != frame["frame_sha256"]):
            raise ValueError("Regressor frame identity or SHA-256 differs from tracks")
        value = row.get("timestamp_ns", "")
        if (int(value) if value else None) != frame["timestamp_ns"]:
            raise ValueError("Regressor timestamp differs from tracks")
        joints = []
        for name in names:
            pred = row[f"pred__{name}"]
            accepted = row[f"safe__{name}"]
            joints.append({
                "joint_name": name,
                "status": row[f"status__{name}"],
                "diagnostic_q": float(pred) if pred else None,
                "source_supported_q": float(accepted) if accepted else None,
                "nearest_source_distance": (
                    float(row[f"nearest_source_distance__{name}"])
                    if row[f"nearest_source_distance__{name}"] else None),
            })
        frame["regressor"] = {"status": row["status"], "joints": joints}


def _attach_geometry(frames: list[dict[str, Any]], names: list[str],
                     urdf: Path, camera_json: Path,
                     landmarks_json: Path | None, base_link: str | None,
                     tip_link: str | None) -> None:
    if __package__:
        from .geometry.geometry_solver import (Camera, Landmark, PointObservation,
                                               load_serial_chain, solve_frame)
    else:
        from geometry.geometry_solver import (Camera, Landmark, PointObservation,
                                              load_serial_chain, solve_frame)
    spec = load_serial_chain(urdf, base_link=base_link, tip_link=tip_link)
    if list(spec.joint_names) != names:
        raise ValueError("URDF joint order differs from semantic joint order")
    camera_value = json.loads(camera_json.read_text(encoding="utf-8"))
    camera = Camera(camera_value["intrinsics_3x3"],
                    camera_value["T_camera_base_4x4"])
    landmark_values = (json.loads(landmarks_json.read_text(encoding="utf-8"))
                       if landmarks_json else [])
    landmarks = [Landmark(item["name"], item["link_name"],
                          tuple(item["xyz_link_m"])) for item in landmark_values]
    for frame in frames:
        try:
            observations = [PointObservation(
                joint["joint_name"], joint["u_px"], joint["v_px"],
                joint["quality"], joint["semantic_verified"])
                for joint in frame["tracks"] if joint["track_valid"]]
            result = solve_frame(spec, camera, observations, landmarks=landmarks)
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            result = {"status": "geometry_failed", "reason": str(exc),
                      "joint_names": names, "diagnostic_q": [None] * len(names),
                      "observable_q": [None] * len(names),
                      "used_observations": 0}
        frame["geometry"] = result


def run_diagnostic_pipeline(
    frames: Path, keyframes: Path, output_dir: Path, *,
    robot_id: str, camera_id: str,
    timestamp_file: Path | None = None, mask_dir: Path | None = None,
    regressor_model: Path | None = None, urdf: Path | None = None,
    camera_json: Path | None = None, landmarks_json: Path | None = None,
    base_link: str | None = None, tip_link: str | None = None,
    tracker_config: TrackerConfig = TrackerConfig(),
) -> dict[str, Any]:
    """Run provenance-checked tracking and optional numeric branches.

    Returns a manifest path and ordered JSONL records. The caller must train
    any regressor on independent, synchronized encoder labels beforehand.
    """
    if not robot_id or not camera_id:
        raise ValueError("robot_id and camera_id are required")
    if (urdf is None) != (camera_json is None):
        raise ValueError("Geometry needs both urdf and camera_json")
    if landmarks_json is not None and urdf is None:
        raise ValueError("landmarks_json needs urdf and camera_json")
    output_dir.mkdir(parents=True, exist_ok=True)
    tracks = output_dir / "joint_tracks.csv"
    tracker_report_path = output_dir / "joint_tracks.report.json"
    tracker_report = run_tracker(
        frames, keyframes, tracks, tracker_report_path, tracker_config,
        mask_dir, timestamp_file)
    names = tracker_report["joint_names"]
    records = _read_tracks(tracks, names, tracker_report["frame_sha256_by_image"])
    regression_report = None
    predictions = None
    if regressor_model is not None:
        predictions = output_dir / "joint_regressor_predictions.csv"
        width, height = tracker_report["image_size"]
        regression_report = joint_track_regressor.infer(
            tracks, regressor_model, predictions, robot_id=robot_id,
            camera_id=camera_id, width=width, height=height)
        _attach_regressor(records, predictions, names)
    if urdf is not None and camera_json is not None:
        _attach_geometry(records, names, urdf, camera_json,
                         landmarks_json, base_link, tip_link)
    records_path = output_dir / "diagnostic_frames.jsonl"
    with records_path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
    report = {
        "schema_version": SCHEMA_VERSION,
        "status": "diagnostic_only",
        "robot_id": robot_id,
        "camera_id": camera_id,
        "joint_names": names,
        "frame_count": len(records),
        "full_2d_frames": sum(record["tracked_joint_count"] == len(names)
                              for record in records),
        "partial_2d_frames": sum(0 < record["tracked_joint_count"] < len(names)
                                 for record in records),
        "no_2d_frames": sum(record["tracked_joint_count"] == 0 for record in records),
        "keyframes_file": str(keyframes.resolve()),
        "keyframes_sha256": _hash_file(keyframes),
        "timestamp_file": str(timestamp_file.resolve()) if timestamp_file else None,
        "timestamp_file_sha256": _hash_file(timestamp_file) if timestamp_file else None,
        "mask_dir": str(mask_dir.resolve()) if mask_dir else None,
        "tracker_report": str(tracker_report_path.resolve()),
        "tracker_csv": str(tracks.resolve()),
        "tracker_csv_sha256": _hash_file(tracks),
        "regressor_model": str(regressor_model.resolve()) if regressor_model else None,
        "regressor_model_sha256": _hash_file(regressor_model) if regressor_model else None,
        "regressor_predictions": str(predictions.resolve()) if predictions else None,
        "regressor_report": regression_report,
        "urdf": str(urdf.resolve()) if urdf else None,
        "urdf_sha256": _hash_file(urdf) if urdf else None,
        "camera_json": str(camera_json.resolve()) if camera_json else None,
        "camera_json_sha256": _hash_file(camera_json) if camera_json else None,
        "landmarks_json": str(landmarks_json.resolve()) if landmarks_json else None,
        "landmarks_json_sha256": _hash_file(landmarks_json) if landmarks_json else None,
        "records_jsonl": str(records_path.resolve()),
        "records_sha256": _hash_file(records_path),
        "warning": "Unverified VLM 2-D proposals and diagnostic numeric estimates; no validated angle accuracy or robot-control authorization.",
    }
    report_path = output_dir / "diagnostic_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frames", type=Path, required=True)
    parser.add_argument("--keyframes", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--robot-id", required=True)
    parser.add_argument("--camera-id", required=True)
    parser.add_argument("--timestamps", type=Path)
    parser.add_argument("--mask-dir", type=Path)
    parser.add_argument("--regressor-model", type=Path)
    parser.add_argument("--urdf", type=Path)
    parser.add_argument("--camera-json", type=Path)
    parser.add_argument("--landmarks-json", type=Path)
    parser.add_argument("--base-link")
    parser.add_argument("--tip-link")
    parser.add_argument("--max-gap-frames", type=int, default=60)
    parser.add_argument("--patch-radius-px", type=int, default=22)
    args = parser.parse_args()
    report = run_diagnostic_pipeline(
        args.frames, args.keyframes, args.output_dir,
        robot_id=args.robot_id, camera_id=args.camera_id,
        timestamp_file=args.timestamps, mask_dir=args.mask_dir,
        regressor_model=args.regressor_model, urdf=args.urdf,
        camera_json=args.camera_json, landmarks_json=args.landmarks_json,
        base_link=args.base_link, tip_link=args.tip_link,
        tracker_config=TrackerConfig(max_gap_frames=args.max_gap_frames,
                                     patch_radius_px=args.patch_radius_px),
    )
    print(json.dumps({"records_jsonl": report["records_jsonl"],
                      "frame_count": report["frame_count"],
                      "partial_2d_frames": report["partial_2d_frames"]},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
