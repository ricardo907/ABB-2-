# URDF–相机重投影几何分支（研究原型）

`geometry_solver.py` 接受一条串联 URDF、已知相机内参 (K)、从机械臂基座到相机的刚体变换 `T_camera_base`、单帧二维关节中心候选点和可选上一帧关节值。点坐标必须先去镜头畸变；相机标定、URDF 尺寸及关节轴必须正确。支持任意正整数个串联转动、连续转动和直线关节，单位分别为 rad / m。

VLM 和光流跟踪输出的二维点只是候选，并非真实关节中心。程序最小化按点质量加权的像素重投影残差及可选时间先验，受 URDF 关节限位约束。时间先验只稳定局部求解；**可观测性使用不含时间先验的投影雅可比**。返回雅可比奇异值、有效秩、逐关节条件敏感度和零空间参与度。`diagnostic_q` 是局部拟合值，`observable_q` 在点未独立核实、重投影不合格或该关节不可观测时填 `null`，不供机器人控制。

默认把 URDF 活动关节原点作为与二维点同名的几何点。关节自己的转角不会改变自己原点的位置，因此**仅靠所有关节中心一般看不到最后一轴**。可以用 `landmarks-json` 增加与末端刚性相连的可见工具点或连杆标记；如果该标记恰好在末轴旋转轴上，仍无法识别末轴。被遮挡点不参加拟合。

## 数据接口

- `camera-json`：`{"intrinsics_3x3": [[...]], "T_camera_base_4x4": [[...]]}`，其中后者把基座坐标映射到相机坐标。
- `landmarks-json`：可选数组，条目为 `{"name": "tool_marker", "link_name": "tool_link", "xyz_link_m": [x,y,z]}`。
- `track-csv`：沿用 VLM 跟踪长表，每帧每点一行，至少有 `frame_index,joint_name,u_px,v_px,track_valid,quality,semantic_verified`。`joint_name` 必须是 URDF 选中链的关节名或额外点名。缺失/无效点不参与计算。当前 VLM 跟踪器的 `semantic_verified=False`，所以其结果最多得到诊断值，`observable_q` 会全部留空。

## 合成验证与命令

```powershell
python research/general_algorithm/vlm/geometry/selfcheck.py
python research/general_algorithm/vlm/geometry/geometry_solver.py `
  --urdf robot.urdf `
  --camera-json camera.json `
  --landmarks-json landmarks.json `
  --track-csv joint_tracks.csv `
  --frame-index 0 --previous-q 0.1 -0.2 0.3 `
  --output geometry_frame0.json
```

自检在系统临时目录生成合成 URDF、相机参数和跟踪 CSV，并调用 CLI 检查端到端路径；结束后不留下合成输入文件。命令示例中的文件名需要替换为对应机器人真实文件，`--previous-q` 的数量须与 URDF 活动关节数一致。

合成自检覆盖 3 / 7 自由度、3 自由度混合直线关节、末端点遮挡、标记位于末轴上、无点输入与未核实点。完全可观测时 3 / 7 自由度最大绝对误差约 0.014 / 0.013（合成单位），局部秩分别为 3 / 7；末端点遮挡后末轴被拒绝。这些只是代码和可观测性行为检查，**不是实机估角精度**。目前没有真实机械臂的 URDF 与相机外参，也没有独立人工核实的二维关节中心，因此无法用现有视频验证这条几何分支，更不能据此声称 T-RO 级性能或算法首创。
