"""Synthetic 3/7-DOF checks for projection, occlusion and observability."""

from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

from geometry_solver import (
    Camera, Landmark, PointObservation, load_serial_chain,
    project_landmarks, solve_frame,
)


def make_urdf(joints: int, path: Path, *, mixed: bool = False) -> None:
    axes = ((0, 0, 1), (0, 1, 0), (1, 0, 0))
    lines = ['<robot name="synthetic_serial">', '<link name="base"/>']
    for index in range(joints):
        parent = "base" if index == 0 else f"link_{index}"
        child = f"link_{index + 1}"
        axis = " ".join(map(str, axes[index % len(axes)]))
        kind = "prismatic" if mixed and index == 1 else "revolute"
        lower, upper = ("-0.2", "0.2") if kind == "prismatic" else ("-1.8", "1.8")
        lines.extend((
            f'<link name="{child}"/>',
            f'<joint name="joint_{index + 1}" type="{kind}">',
            f'<parent link="{parent}"/><child link="{child}"/>',
            '<origin xyz="0.23 0.065 0.045" rpy="0 0 0"/>',
            f'<axis xyz="{axis}"/>',
            f'<limit lower="{lower}" upper="{upper}"/>',
            '</joint>',
        ))
    lines.append('</robot>')
    path.write_text("\n".join(lines), encoding="utf-8")


def candidate_points(spec, camera, q, landmarks, *, verified=True, noise=0.0):
    rng = np.random.default_rng(44)
    projected = project_landmarks(spec, camera, q, landmarks)
    return [PointObservation(name, float(u + rng.normal(scale=noise)),
                             float(v + rng.normal(scale=noise)),
                             1.0, verified)
            for name, (u, v, _) in projected.items()]


def one_case(joints: int, root: Path, *, mixed: bool = False) -> dict:
    path = root / f"synthetic_{joints}dof{'_mixed' if mixed else ''}.urdf"
    make_urdf(joints, path, mixed=mixed)
    spec = load_serial_chain(path)
    camera = Camera(np.array([[800, 0, 640], [0, 800, 360], [0, 0, 1]], dtype=float),
                    np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 3.5],
                              [0, 0, 0, 1]], dtype=float))
    q = np.array([0.20, -0.30, 0.27, 0.12, -0.22, 0.33, -0.15][:joints])
    if mixed:
        q[1] = 0.08
    previous = q + 0.04
    tip = f"link_{joints}"
    tool = Landmark("tool_marker", tip, (0.17, 0.09, 0.08))
    points = candidate_points(spec, camera, q, [tool], noise=0.1)
    if joints == 3 and not mixed:
        (root / "synthetic_camera.json").write_text(json.dumps({
            "intrinsics_3x3": camera.intrinsics.tolist(),
            "T_camera_base_4x4": camera.T_camera_base.tolist(),
        }, indent=2), encoding="utf-8")
        (root / "synthetic_landmarks.json").write_text(json.dumps([{
            "name": tool.name, "link_name": tool.link_name,
            "xyz_link_m": list(tool.xyz_link_m),
        }], indent=2), encoding="utf-8")
        with (root / "synthetic_tracks.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=[
                "frame_index", "image", "joint_name", "u_px", "v_px",
                "track_valid", "status", "quality", "semantic_verified",
            ])
            writer.writeheader()
            for point in points:
                writer.writerow({"frame_index": 0, "image": "synthetic_frame",
                                 "joint_name": point.name, "u_px": point.u_px,
                                 "v_px": point.v_px, "track_valid": True,
                                 "status": "synthetic", "quality": 1.0,
                                 "semantic_verified": True})
    full = solve_frame(spec, camera, points, landmarks=[tool], previous_q=previous)
    error = float(np.max(np.abs(np.asarray(full["diagnostic_q"]) - q)))
    if error > 0.10 or not all(full["locally_observable_by_joint"]):
        raise AssertionError(f"{joints}DOF full visibility failed: error={error}, report={full}")
    if any(value is None for value in full["observable_q"]):
        raise AssertionError("Verified full-rank points should be locally reportable")

    no_tool = solve_frame(spec, camera, points[:-1], previous_q=previous)
    if no_tool["locally_observable_by_joint"][-1] or no_tool["observable_q"][-1] is not None:
        raise AssertionError("Last joint cannot be observed from joint centres alone")
    no_points = solve_frame(spec, camera, [], previous_q=previous)
    if any(value is not None for value in no_points["diagnostic_q"]):
        raise AssertionError("Temporal prior alone must not create an angle estimate")
    unverified = solve_frame(
        spec, camera,
        [PointObservation(item.name, item.u_px, item.v_px, 1.0, False) for item in points],
        landmarks=[tool], previous_q=previous,
    )
    if any(value is not None for value in unverified["observable_q"]):
        raise AssertionError("Unverified VLM points must not become accepted angles")
    axis = tuple(spec.active_joints[-1].axis * 0.17)
    axial_marker = Landmark("axial_marker", tip, axis)
    axial_points = candidate_points(spec, camera, q, [axial_marker], noise=0.0)
    axial = solve_frame(spec, camera, axial_points, landmarks=[axial_marker], previous_q=previous)
    if axial["locally_observable_by_joint"][-1]:
        raise AssertionError("A marker on the last joint axis cannot reveal its angle")
    return {
        "joint_count": joints,
        "joint_types": list(spec.joint_types),
        "full_max_error": error,
        "full_effective_rank": full["effective_rank"],
        "occluded_tool_rank": no_tool["effective_rank"],
        "last_joint_occluded_rejected": no_tool["observable_q"][-1] is None,
        "last_joint_axial_marker_rejected": axial["observable_q"][-1] is None,
        "unverified_point_set_rejected": all(value is None for value in unverified["observable_q"]),
        "no_point_rejected": all(value is None for value in no_points["diagnostic_q"]),
    }


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="tro_vlm_geometry_") as temporary:
        root = Path(temporary)
        cases = [one_case(3, root), one_case(3, root, mixed=True), one_case(7, root)]
        output = root / "cli_report.json"
        command = [
            sys.executable, str(Path(__file__).with_name("geometry_solver.py")),
            "--urdf", str(root / "synthetic_3dof.urdf"),
            "--camera-json", str(root / "synthetic_camera.json"),
            "--landmarks-json", str(root / "synthetic_landmarks.json"),
            "--track-csv", str(root / "synthetic_tracks.csv"),
            "--frame-index", "0", "--previous-q", "0.24", "-0.26", "0.31",
            "--output", str(output),
        ]
        subprocess.run(command, check=True, capture_output=True, text=True)
        cli = json.loads(output.read_text(encoding="utf-8"))
        if cli["status"] != "local_solution" or any(
            value is None for value in cli["observable_q"]
        ):
            raise AssertionError("CLI integration did not recover the synthetic 3-DOF state")
        print(json.dumps({"status": "synthetic code check only", "cases": cases,
                          "cli_observable_joints": len(cli["observable_q"])}, indent=2))


if __name__ == "__main__":
    main()
