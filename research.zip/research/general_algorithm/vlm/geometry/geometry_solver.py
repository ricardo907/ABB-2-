"""Local URDF + camera geometry estimate from 2-D landmark candidates.

The input 2-D points may originate from a VLM/optical-flow tracker and are
treated as candidate observations, never as certified joint centres. The
optimizer reports a diagnostic q. A separate locally observable q is returned
only when all used landmarks are independently verified, reprojection fits,
and the *data-only* projection Jacobian identifies that joint. Temporal priors
are deliberately excluded from observability calculations. Neither output is
safe for robot control. The solver is local and does not establish a unique
global monocular solution.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from scipy.optimize import least_squares


HERE = Path(__file__).resolve().parent
SPEC_CANDIDATES = (
    HERE.parent / "new_robot_algorithm",
    HERE.parent / "optimized-project" / "ABB_Cup_2" / "research" / "general_algorithm",
    HERE.parent,
    HERE.parents[1],
)
SPEC_ROOT = next((path for path in SPEC_CANDIDATES
                  if (path / "spec" / "urdf_chain.py").is_file()), None)
if SPEC_ROOT is None:
    raise ImportError("Place this module under general_algorithm/vlm/geometry beside spec/")
sys.path.insert(0, str(SPEC_ROOT))
from spec.urdf_chain import (  # noqa: E402
    SerialArmSpec, _rotation_about_axis, _rotation_from_rpy, _transform,
    load_serial_chain,
)


@dataclass(frozen=True)
class Camera:
    """Pinhole camera; T_camera_base maps base coordinates into camera frame.

    Input pixels must be undistorted if the physical lens has distortion.
    """

    intrinsics: np.ndarray
    T_camera_base: np.ndarray

    def __post_init__(self) -> None:
        k = np.asarray(self.intrinsics, dtype=float)
        transform = np.asarray(self.T_camera_base, dtype=float)
        if k.shape != (3, 3) or transform.shape != (4, 4):
            raise ValueError("Camera intrinsics must be 3x3 and T_camera_base 4x4")
        if not np.isfinite(k).all() or not np.isfinite(transform).all():
            raise ValueError("Camera matrices must be finite")
        if k[0, 0] <= 0 or k[1, 1] <= 0 or not np.allclose(k[2], [0, 0, 1]):
            raise ValueError("Camera intrinsics must have positive focal lengths")
        if not np.allclose(transform[3], [0, 0, 0, 1]):
            raise ValueError("T_camera_base must be homogeneous")
        rotation = transform[:3, :3]
        if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-5) or not np.isclose(
            np.linalg.det(rotation), 1.0, atol=1e-5
        ):
            raise ValueError("T_camera_base rotation must be proper and orthonormal")
        object.__setattr__(self, "intrinsics", k)
        object.__setattr__(self, "T_camera_base", transform)


@dataclass(frozen=True)
class Landmark:
    """A rigid point in one URDF link frame, e.g. a visible tool marker."""

    name: str
    link_name: str
    xyz_link_m: tuple[float, float, float]


@dataclass(frozen=True)
class PointObservation:
    name: str
    u_px: float
    v_px: float
    quality: float = 1.0
    semantic_verified: bool = False


@dataclass(frozen=True)
class GeometryConfig:
    pixel_sigma: float = 2.0
    min_quality: float = 0.15
    max_reprojection_rmse_px: float = 5.0
    data_rank_abs_px: float = 2.0
    data_rank_relative: float = 0.01
    min_conditional_sensitivity_px: float = 2.0
    prior_sigma_revolute_rad: float = 0.35
    prior_sigma_prismatic_m: float = 0.05
    min_depth_m: float = 0.05
    max_nfev: int = 300


def _q_array(spec: SerialArmSpec, q: Sequence[float]) -> np.ndarray:
    array = np.asarray(q, dtype=float)
    if array.shape != (len(spec.joint_names),) or not np.isfinite(array).all():
        raise ValueError(f"Expected {len(spec.joint_names)} finite joint values")
    return array


def _kinematic_points(spec: SerialArmSpec, q: np.ndarray,
                      landmarks: Sequence[Landmark]) -> dict[str, np.ndarray]:
    """Joint origins before own motion; rigid link landmarks after motion."""
    transform = np.eye(4)
    link_transforms = {spec.base_link: transform.copy()}
    points: dict[str, np.ndarray] = {}
    active = 0
    for joint in spec.chain_joints:
        transform = transform @ _transform(
            _rotation_from_rpy(joint.origin_rpy), joint.origin_xyz,
        )
        if joint.active:
            points[joint.name] = transform[:3, 3].copy()
            value = float(q[active])
            active += 1
            if joint.kind in ("revolute", "continuous"):
                transform = transform @ _transform(
                    rotation=_rotation_about_axis(joint.axis, value)
                )
            elif joint.kind == "prismatic":
                transform = transform @ _transform(translation=joint.axis * value)
        link_transforms[joint.child] = transform.copy()
    for landmark in landmarks:
        if not landmark.name or landmark.name in points:
            raise ValueError(f"Duplicate/empty landmark name: {landmark.name!r}")
        if landmark.link_name not in link_transforms:
            raise ValueError(f"Landmark {landmark.name}: link outside selected chain")
        xyz = np.asarray(landmark.xyz_link_m, dtype=float)
        if xyz.shape != (3,) or not np.isfinite(xyz).all():
            raise ValueError(f"Landmark {landmark.name}: expected finite xyz_link_m")
        homo = np.r_[xyz, 1.0]
        points[landmark.name] = (link_transforms[landmark.link_name] @ homo)[:3]
    return points


def project_landmarks(spec: SerialArmSpec, camera: Camera, q: Sequence[float],
                      landmarks: Sequence[Landmark] = ()) -> dict[str, tuple[float, float, float]]:
    """Return name -> (u_px, v_px, depth_m) for joint origins and markers."""
    q = _q_array(spec, q)
    points = _kinematic_points(spec, q, landmarks)
    output = {}
    for name, xyz_base in points.items():
        xyz_camera = camera.T_camera_base[:3, :3] @ xyz_base + camera.T_camera_base[:3, 3]
        depth = float(xyz_camera[2])
        if depth <= 0:
            output[name] = (float("nan"), float("nan"), depth)
            continue
        pixel_h = camera.intrinsics @ xyz_camera
        output[name] = (float(pixel_h[0] / pixel_h[2]),
                        float(pixel_h[1] / pixel_h[2]), depth)
    return output


def _prepare_observations(observations: Sequence[PointObservation],
                          known_names: set[str], config: GeometryConfig) -> list[PointObservation]:
    if config.pixel_sigma <= 0 or config.max_reprojection_rmse_px <= 0 or config.max_nfev < 1:
        raise ValueError("Positive pixel_sigma, RMSE threshold and max_nfev are required")
    if not 0 <= config.min_quality <= 1:
        raise ValueError("min_quality must be in [0,1]")
    if (config.prior_sigma_revolute_rad <= 0 or config.prior_sigma_prismatic_m <= 0
            or config.min_depth_m <= 0 or config.data_rank_abs_px <= 0
            or config.data_rank_relative < 0 or config.min_conditional_sensitivity_px <= 0):
        raise ValueError("Prior scales, depth and rank thresholds must be positive")
    seen = set()
    selected = []
    for obs in observations:
        if obs.name in seen:
            raise ValueError(f"Duplicate observation for {obs.name}")
        seen.add(obs.name)
        if obs.name not in known_names:
            raise ValueError(f"Unknown observation landmark {obs.name}")
        if not math.isfinite(obs.quality) or not 0 <= obs.quality <= 1:
            raise ValueError(f"Quality for {obs.name} must be in [0,1]")
        if not math.isfinite(obs.u_px) or not math.isfinite(obs.v_px):
            continue
        if obs.quality >= config.min_quality:
            selected.append(obs)
    return selected


def _visible_projection(spec: SerialArmSpec, camera: Camera, q: np.ndarray,
                        landmarks: Sequence[Landmark], names: list[str],
                        min_depth: float) -> tuple[np.ndarray, np.ndarray]:
    projected = project_landmarks(spec, camera, q, landmarks)
    uv = np.empty((len(names), 2), dtype=float)
    depth = np.empty(len(names), dtype=float)
    for index, name in enumerate(names):
        u, v, z = projected[name]
        depth[index] = z
        if z <= min_depth or not math.isfinite(u + v):
            # Keep the least-squares residual finite while heavily penalizing
            # physically invalid projection. These poses cannot be accepted.
            uv[index] = [1e5 + 1e3 * (min_depth - z), 1e5]
        else:
            uv[index] = [u, v]
    return uv, depth


def _projection_jacobian(spec: SerialArmSpec, camera: Camera, q: np.ndarray,
                         landmarks: Sequence[Landmark], names: list[str],
                         min_depth: float) -> np.ndarray:
    columns = []
    for index, kind in enumerate(spec.joint_types):
        step = 1e-6 if kind == "prismatic" else 1e-5
        plus, minus = q.copy(), q.copy()
        plus[index] += step
        minus[index] -= step
        uv_plus, _ = _visible_projection(spec, camera, plus, landmarks, names, min_depth)
        uv_minus, _ = _visible_projection(spec, camera, minus, landmarks, names, min_depth)
        columns.append(((uv_plus - uv_minus) / (2 * step)).reshape(-1))
    return np.column_stack(columns)


def _observability(jacobian_px: np.ndarray, qualities: np.ndarray,
                   kinds: tuple[str, ...], config: GeometryConfig) -> dict:
    scales = np.asarray([0.1 if kind == "prismatic" else 1.0 for kind in kinds])
    row_weights = np.repeat(np.sqrt(qualities), 2)
    data_jacobian = jacobian_px * row_weights[:, None] * scales[None, :]
    _, singular, vh = np.linalg.svd(data_jacobian, full_matrices=True)
    threshold = max(config.data_rank_abs_px,
                    config.data_rank_relative * float(singular[0]) if len(singular) else 0.0)
    rank = int(np.sum(singular > threshold))
    n = len(kinds)
    null_basis = vh[rank:, :]
    null_leverage = np.sum(null_basis ** 2, axis=0) if len(null_basis) else np.zeros(n)
    conditional = np.empty(n)
    for index in range(n):
        column = data_jacobian[:, index]
        others = np.delete(data_jacobian, index, axis=1)
        if others.shape[1]:
            projected = others @ np.linalg.lstsq(others, column, rcond=1e-7)[0]
            conditional[index] = float(np.linalg.norm(column - projected))
        else:
            conditional[index] = float(np.linalg.norm(column))
    observable = (conditional >= config.min_conditional_sensitivity_px) & (null_leverage <= 0.1)
    return {
        "weighted_projection_singular_values_px": singular.tolist(),
        "effective_rank": rank,
        "joint_count": n,
        "rank_threshold_px": threshold,
        "parameter_scales": scales.tolist(),
        "conditional_sensitivity_px_by_joint": conditional.tolist(),
        "nullspace_leverage_by_joint": null_leverage.tolist(),
        "locally_observable_by_joint": observable.tolist(),
    }


def solve_frame(spec: SerialArmSpec, camera: Camera,
                observations: Sequence[PointObservation],
                *, landmarks: Sequence[Landmark] = (),
                previous_q: Sequence[float] | None = None,
                config: GeometryConfig = GeometryConfig()) -> dict:
    """Solve one frame; local observability uses 2-D data, never the time prior."""
    joint_count = len(spec.joint_names)
    known_names = set(spec.joint_names) | {item.name for item in landmarks}
    if len(known_names) != joint_count + len(landmarks):
        raise ValueError("Landmark names must be unique and distinct from joint names")
    selected = _prepare_observations(observations, known_names, config)
    empty = [None] * joint_count
    if not selected:
        return {
            "status": "abstained", "reason": "no_valid_2d_observations",
            "joint_names": list(spec.joint_names), "joint_types": list(spec.joint_types),
            "diagnostic_q": empty, "observable_q": empty,
            "locally_observable_by_joint": [False] * joint_count,
            "used_observations": 0,
            "warning": "No angle can be inferred from a missing 2-D observation",
        }
    names = [item.name for item in selected]
    target = np.asarray([[item.u_px, item.v_px] for item in selected], dtype=float)
    quality = np.asarray([item.quality for item in selected], dtype=float)
    row_weight = np.sqrt(quality)[:, None]
    previous = _q_array(spec, previous_q) if previous_q is not None else None
    bounds = spec.joint_limits.copy()
    # Infinite limits are accepted by scipy. Finite-limit joints use their
    # neutral midpoint; continuous joints use zero without a previous state.
    if previous is not None:
        q0 = previous.copy()
    else:
        q0 = np.zeros(joint_count, dtype=float)
        finite_pair = np.isfinite(bounds).all(axis=1)
        q0[finite_pair] = np.mean(bounds[finite_pair], axis=1)
    q0 = np.maximum(q0, np.where(np.isfinite(bounds[:, 0]), bounds[:, 0], -np.inf))
    q0 = np.minimum(q0, np.where(np.isfinite(bounds[:, 1]), bounds[:, 1], np.inf))
    prior_scale = np.asarray([
        config.prior_sigma_prismatic_m if kind == "prismatic"
        else config.prior_sigma_revolute_rad for kind in spec.joint_types
    ])

    def residual(q: np.ndarray) -> np.ndarray:
        uv, _ = _visible_projection(spec, camera, q, landmarks, names, config.min_depth_m)
        image_residual = ((uv - target) * row_weight / config.pixel_sigma).reshape(-1)
        if previous is None:
            return image_residual
        difference = q - previous
        for index, kind in enumerate(spec.joint_types):
            if kind == "continuous":
                difference[index] = (difference[index] + np.pi) % (2 * np.pi) - np.pi
        return np.r_[image_residual, difference / prior_scale]

    result = least_squares(
        residual, q0, bounds=(bounds[:, 0], bounds[:, 1]),
        loss="soft_l1", f_scale=2.0, max_nfev=config.max_nfev,
        xtol=1e-10, ftol=1e-10, gtol=1e-10,
    )
    fitted_uv, depths = _visible_projection(
        spec, camera, result.x, landmarks, names, config.min_depth_m
    )
    pixel_error = np.linalg.norm(fitted_uv - target, axis=1)
    rmse = float(np.sqrt(np.mean(pixel_error ** 2)))
    jacobian = _projection_jacobian(
        spec, camera, result.x, landmarks, names, config.min_depth_m
    )
    observability = _observability(jacobian, quality, spec.joint_types, config)
    data_good = (bool(result.success) and bool(np.all(depths > config.min_depth_m))
                 and rmse <= config.max_reprojection_rmse_px)
    all_verified = all(item.semantic_verified for item in selected)
    accepted = np.asarray(observability["locally_observable_by_joint"], dtype=bool)
    accepted &= data_good and all_verified
    observable_q = [float(value) if okay else None
                    for value, okay in zip(result.x, accepted)]
    return {
        "status": ("local_solution" if data_good and all_verified
                   else "unverified_candidate_fit" if data_good
                   else "diagnostic_only"),
        "reason": (None if data_good else "optimizer_depth_or_reprojection_failure"),
        "joint_names": list(spec.joint_names),
        "joint_types": list(spec.joint_types),
        "joint_units": ["m" if kind == "prismatic" else "rad" for kind in spec.joint_types],
        "diagnostic_q": result.x.tolist(),
        "observable_q": observable_q,
        "used_observations": len(selected),
        "used_names": names,
        "all_used_points_semantically_verified": all_verified,
        "reprojection_rmse_px": rmse,
        "reprojection_error_px_by_point": dict(zip(names, pixel_error.tolist())),
        "optimizer_success": bool(result.success),
        "optimizer_message": str(result.message),
        "used_temporal_prior": previous is not None,
        **observability,
        "warning": "Local geometric fit only; VLM candidates and camera calibration are not certified; never use for control",
    }


def load_tracker_frame(path: str | Path, frame_index: int) -> list[PointObservation]:
    """Load one frame from tracker long CSV; missing points remain missing."""
    selected = []
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            if int(row["frame_index"]) != frame_index or row["track_valid"].lower() != "true":
                continue
            if not row["u_px"] or not row["v_px"]:
                continue
            selected.append(PointObservation(
                row["joint_name"], float(row["u_px"]), float(row["v_px"]),
                float(row["quality"]), row["semantic_verified"].lower() == "true",
            ))
    return selected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--urdf", type=Path, required=True)
    parser.add_argument("--base-link")
    parser.add_argument("--tip-link")
    parser.add_argument("--camera-json", type=Path, required=True,
                        help="JSON with intrinsics_3x3 and T_camera_base_4x4")
    parser.add_argument("--landmarks-json", type=Path,
                        help="Optional list of {name,link_name,xyz_link_m} rigid markers")
    parser.add_argument("--track-csv", type=Path, required=True)
    parser.add_argument("--frame-index", type=int, required=True)
    parser.add_argument("--previous-q", nargs="+", type=float)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    spec = load_serial_chain(args.urdf, base_link=args.base_link, tip_link=args.tip_link)
    value = json.loads(args.camera_json.read_text(encoding="utf-8"))
    camera = Camera(value["intrinsics_3x3"], value["T_camera_base_4x4"])
    landmark_values = (json.loads(args.landmarks_json.read_text(encoding="utf-8"))
                       if args.landmarks_json else [])
    landmarks = [Landmark(item["name"], item["link_name"], tuple(item["xyz_link_m"]))
                 for item in landmark_values]
    observations = load_tracker_frame(args.track_csv, args.frame_index)
    report = solve_frame(spec, camera, observations, landmarks=landmarks,
                         previous_q=args.previous_q)
    report["provenance"] = {
        "urdf": str(args.urdf), "camera_json": str(args.camera_json),
        "landmarks_json": str(args.landmarks_json) if args.landmarks_json else None,
        "track_csv": str(args.track_csv), "frame_index": args.frame_index,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), "status": report["status"],
                      "observable_joints": sum(value is not None for value in report["observable_q"])},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
