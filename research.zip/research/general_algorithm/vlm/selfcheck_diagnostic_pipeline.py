"""Synthetic end-to-end checks; these do not measure real VLM accuracy."""

from __future__ import annotations

import csv
import json
import tempfile
from pathlib import Path

import cv2
import numpy as np

from diagnostic_pipeline import run_diagnostic_pipeline
from selfcheck_regressor import synth
from track_joint_points import _hash_file


def _make_urdf(path: Path) -> None:
    parts = ['<robot name="test_arm">', '<link name="base"/>']
    for index in range(3):
        parts.extend((
            f'<link name="link_{index + 1}"/>',
            f'<joint name="joint_{index + 1}" type="revolute">',
            f'<parent link="{("base" if index == 0 else f"link_{index}")}"/>',
            f'<child link="link_{index + 1}"/>',
            '<origin xyz="0.15 0.02 0.04" rpy="0 0 0"/>',
            '<axis xyz="0 0 1"/>',
            '<limit lower="-1.8" upper="1.8"/>',
            '</joint>',
        ))
    parts.append('</robot>')
    path.write_text('\n'.join(parts), encoding='utf-8')


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        base = Path(temporary)
        fit = base / "fit"
        fit.mkdir()
        synth(fit, 3)
        frames = base / "frames"
        masks = base / "masks"
        frames.mkdir()
        masks.mkdir()
        rng = np.random.default_rng(71)
        textures = [rng.integers(40, 230, size=(23, 23), dtype=np.uint8)
                    for _ in range(2)]
        paths = []
        for index in range(9):
            image = np.full((160, 200), 14, dtype=np.uint8)
            mask = np.zeros_like(image)
            locations = ((42 + 2 * index, 33), (102 - index, 88))
            for joint, (left, top) in enumerate(locations):
                if joint == 1 and index == 4:
                    continue
                image[top:top + 23, left:left + 23] = textures[joint]
                mask[top:top + 23, left:left + 23] = 255
            path = frames / f"frame_{index:04d}.png"
            assert cv2.imwrite(str(path), image)
            assert cv2.imwrite(str(masks / path.name), mask)
            paths.append(path)
        records = []
        for index in (0, 4, 8):
            joints = []
            for joint in range(3):
                visible = joint == 0 or (joint == 1 and index != 4)
                locations = ((42 + 2 * index, 33), (102 - index, 88))
                uv = ([locations[joint][0] + 11, locations[joint][1] + 11]
                      if visible else None)
                joints.append({"joint_name": f"joint_{joint + 1}",
                               "visibility": ("visible" if visible else
                                              "occluded" if joint == 1 and index == 4
                                              else "unknown"),
                               "uv": uv, "link_name": None})
            records.append({"frame": str(paths[index].resolve()),
                            "frame_sha256": _hash_file(paths[index]),
                            "original_size": [200, 160],
                            "inference_size": [200, 160],
                            "status": "parsed_diagnostic_only",
                            "annotation": {"joints": joints}})
        keyframes = base / "semantic_keyframes.json"
        keyframes.write_text(json.dumps({
            "schema_version": "robot-joint-semantic-keyframe-v1",
            "joint_names": ["joint_1", "joint_2", "joint_3"],
            "records": records,
        }), encoding="utf-8")
        timestamps = base / "timestamps.csv"
        with timestamps.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(("frame_index", "timestamp_ns"))
            writer.writerows((index, 1_000_000_000 + 33_333_333 * index)
                             for index in range(9))
        urdf = base / "arm.urdf"
        _make_urdf(urdf)
        camera = base / "camera.json"
        camera.write_text(json.dumps({
            "intrinsics_3x3": [[120, 0, 100], [0, 120, 80], [0, 0, 1]],
            "T_camera_base_4x4": [[1, 0, 0, 0], [0, 1, 0, 0],
                                  [0, 0, 1, 2], [0, 0, 0, 1]],
        }), encoding="utf-8")
        report = run_diagnostic_pipeline(
            frames, keyframes, base / "result", robot_id="robot_3",
            camera_id="cam_1", timestamp_file=timestamps, mask_dir=masks,
            regressor_model=fit / "model.joblib", urdf=urdf,
            camera_json=camera)
        assert report["joint_names"] == ["joint_1", "joint_2", "joint_3"]
        assert report["frame_count"] == 9
        assert report["partial_2d_frames"] >= 1
        values = [json.loads(line) for line in Path(report["records_jsonl"]).read_text(
            encoding="utf-8").splitlines()]
        assert values[0]["timestamp_ns"] == 1_000_000_000
        assert values[0]["frame_sha256"] == _hash_file(paths[0])
        assert values[4]["tracks"][1]["status"] == "occluded_keyframe"
        assert values[4]["tracks"][0]["track_valid"] is True
        assert values[4]["regressor"]["joints"][1]["diagnostic_q"] is None
        assert values[1]["regressor"]["joints"][0]["diagnostic_q"] is not None
        assert all(all(q is None for q in record["geometry"]["observable_q"])
                   for record in values)
        no_clock = run_diagnostic_pipeline(
            frames, keyframes, base / "result_without_camera_clock",
            robot_id="robot_3", camera_id="cam_1", mask_dir=masks,
            regressor_model=fit / "model.joblib")
        first_no_clock = json.loads(Path(no_clock["records_jsonl"]).read_text(
            encoding="utf-8").splitlines()[0])
        assert first_no_clock["timestamp_ns"] is None
        assert first_no_clock["regressor"]["joints"][0]["diagnostic_q"] is not None
        print("VLM diagnostic pipeline selfcheck passed: provenance, partial joints, numeric branches")


if __name__ == "__main__":
    main()
