"""Small deterministic checks for the offline and optional causal frontends.

Run from this directory with ``python selfcheck_frontend.py``. Add ``--real``
to probe the supplied Exp001/Exp002 recordings without reading angle labels.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from frontend import (CanonicalVideoFrontend, iter_frame_directory,
                      list_frame_names, load_frame_directory,
                      robot_centered_descriptor)


def synthetic_check() -> dict:
    rng = np.random.default_rng(3)
    background = rng.integers(35, 210, size=(192, 256), dtype=np.uint8)
    unrelated = rng.integers(35, 210, size=background.shape, dtype=np.uint8)

    def robot_frame(canvas: np.ndarray, x: int) -> tuple[np.ndarray, np.ndarray]:
        frame = canvas.copy()
        mask = np.zeros_like(frame)
        cv2.rectangle(mask, (x, 45), (x + 30, 135), 255, -1)
        frame[mask != 0] = 235
        return frame, mask

    reference = [robot_frame(background, 20 + 7 * i)[0] for i in range(8)]
    same_scene = [robot_frame(background, 25 + 6 * i)[0] for i in range(8)]
    changed_scene = [robot_frame(unrelated, 50 + 5 * i) for i in range(2)]
    all_target = same_scene + [frame for frame, _ in changed_scene]

    frontend = CanonicalVideoFrontend().fit_reference(reference)
    prefix = frontend.transform_causal(iter(same_scene))
    full = frontend.transform_causal(iter(all_target))
    np.testing.assert_array_equal(prefix.appearance, full.appearance[:8])
    np.testing.assert_array_equal(prefix.motion, full.motion[:8])
    np.testing.assert_array_equal(prefix.quality, full.quality[:8])
    np.testing.assert_array_equal(prefix.frame_usable, full.frame_usable[:8])
    assert prefix.usable
    assert not full.usable
    assert full.frame_usable[:8].all()
    assert not full.frame_usable[8:].any()
    assert np.all(full.appearance[8:] == 0)

    masked = robot_centered_descriptor(*changed_scene[0])
    assert masked.shape == (2052,)
    assert np.isfinite(masked).all()
    probability_mask = changed_scene[0][1].astype(np.float32) / 255.0
    np.testing.assert_array_equal(
        masked, robot_centered_descriptor(changed_scene[0][0], probability_mask))
    try:
        robot_centered_descriptor(changed_scene[0][0], np.zeros_like(background))
    except ValueError:
        pass
    else:
        raise AssertionError("An empty robot mask must abstain")

    bounded = CanonicalVideoFrontend().fit_reference_bounded(iter(reference), max_frames=4)
    assert bounded.reference_background.shape == background.shape
    return {
        "prefix_invariance": True,
        "same_scene_registered": int(prefix.frame_usable.sum()),
        "same_scene_frames": len(prefix.frame_usable),
        "changed_scene_registered": int(full.frame_usable[8:].sum()),
        "changed_scene_frames": 2,
        "mask_descriptor_length": int(masked.size),
    }


def real_probe(source_folder: Path, target_folder: Path) -> dict:
    # A bounded reference fit and streaming target probe avoid retaining videos.
    frontend = CanonicalVideoFrontend().fit_reference_bounded(
        iter_frame_directory(source_folder), max_frames=64)
    causal = frontend.transform_causal(iter_frame_directory(target_folder))
    _, source = load_frame_directory(source_folder)
    _, target = load_frame_directory(target_folder)
    assert len(list_frame_names(source_folder)) == len(source)
    assert len(list_frame_names(target_folder)) == len(target)
    offline = CanonicalVideoFrontend().fit_reference(source).transform(target)
    appearance_difference = np.mean(np.abs(
        causal.appearance - offline.appearance), axis=1)
    return {
        "source_frames": int(len(source)),
        "target_frames": int(len(target)),
        "offline_registration": offline.registration,
        "offline_usable": offline.usable,
        "causal_registration": causal.registration,
        "causal_usable": causal.usable,
        "causal_registered_fraction": float(causal.frame_usable.mean()),
        "causal_vs_offline_appearance_mae_median": float(np.median(appearance_difference)),
        "causal_vs_offline_appearance_mae_p95": float(np.percentile(appearance_difference, 95)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--real", action="store_true")
    args = parser.parse_args()
    results = {"synthetic": synthetic_check()}
    if args.real:
        root = Path(__file__).resolve().parents[3]
        exp001 = root / "data" / "train" / "Exp001" / "frames"
        exp002 = root / "data2" / "test" / "Exp002" / "frames"
        results["exp001_to_exp002"] = real_probe(exp001, exp002)
        results["exp002_to_exp001"] = real_probe(exp002, exp001)
    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
