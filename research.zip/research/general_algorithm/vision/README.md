# Video frontend modes

`CanonicalVideoFrontend.transform()` is the existing **offline** mode. It uses
the median of the complete target video for one ORB registration and for the
foreground quality score. It is appropriate only when the complete recording
is available before prediction. Its default behavior and 1024/384/3 feature
dimensions remain unchanged for existing models.

`transform_causal()` is an optional **online** mode. Fit a reference recording
first, then pass target frames in time order. Each frame is registered to the
fixed reference on its own. Its appearance, motion, and quality for frame *t*
use only that frame, the preceding registered frame, and the fitted reference.
`frame_usable[t]` reports registration validity. An invalid frame gets zero
features, and `usable` is false if **any** frame fails. Downstream angle
estimation must skip invalid frames. The reference may be fitted from an
earlier calibration recording; it must not include future frames of the
target deployment video.
The implementation decodes frames incrementally but returns feature arrays
after the recording is processed; it does not yet provide a live per-frame
output API or measured end-to-end latency.

For long recordings, `iter_frame_directory()` and `iter_video_frames()` decode
one frame at a time. `list_frame_names()` checks frame numbering without image
decoding, using the same validation as both directory loaders.
`fit_reference_bounded()` uses a fixed-size reservoir of
reference frames to approximate the reference median. The causal transform
stores output features and validity flags, but not decoded video frames.

```python
from frontend import CanonicalVideoFrontend, iter_frame_directory

frontend = CanonicalVideoFrontend().fit_reference_bounded(
    iter_frame_directory(reference_folder), max_frames=64
)
features = frontend.transform_causal(iter_frame_directory(target_folder))
safe_rows = features.frame_usable  # Do not infer angles for False rows.
```

`robot_centered_descriptor(frame, mask)` offers an **experimental**
registration-free feature for a foreground mask supplied by a separate
segmenter, human annotation, or VLM-assisted tracker. It returns a 2052-value
vector: masked grayscale crop, robot silhouette, and normalized bounding box.
It rejects absent/tiny masks. Train and inference must both use this descriptor
and the same mask convention. A valid-looking mask does not establish that it
contains the robot, so mask accuracy and cross-scene angle accuracy still need
independent evaluation. This descriptor is a separate input representation;
it must not be fed into a model trained on the default 1024-value appearance.

Run `python selfcheck_frontend.py --real` from this directory for deterministic
synthetic checks and a label-free Exp001→Exp002 registration probe. The probe
does not measure joint-angle error.
