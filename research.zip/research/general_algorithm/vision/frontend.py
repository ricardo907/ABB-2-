"""Label-free visual frontend for the supplied fixed-camera robot videos.

The default offline path retains full-video median registration for existing
models. The optional causal path registers each incoming frame against a
previously fitted reference, without looking at later target frames. Neither
path reads joint angles. Failed registration is an abstention.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np


DEFAULT_ROI_FRACTIONS = (0.03, 0.05, 0.95, 0.90)


@dataclass
class VisualFeatures:
    appearance: np.ndarray  # (T, 1024): canonical gray32, [0, 1]
    motion: np.ndarray  # (T, 384): signed difference and 2-D optical flow
    quality: np.ndarray  # (T, 3): motion energy, foreground fraction, blur
    registration: dict
    usable: bool  # False when no trustworthy common-camera registration exists
    frame_usable: np.ndarray | None = None  # Optional per-frame causal validity


def _gray_frame(frame: np.ndarray) -> np.ndarray:
    image = np.asarray(frame)
    if image.dtype != np.uint8:
        raise ValueError("Frames must be uint8 images")
    if image.ndim == 3 and image.shape[2] == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if image.ndim != 2:
        raise ValueError("Frames must be grayscale or BGR")
    return image


def gray_frames(frames: Iterable[np.ndarray]) -> np.ndarray:
    """Validate and convert an ordered, constant-size frame sequence to uint8."""
    result = []
    for frame in frames:
        result.append(_gray_frame(frame))
    if not result:
        raise ValueError("At least one frame is needed")
    if len({tuple(frame.shape) for frame in result}) != 1:
        raise ValueError("Frame sizes must be constant within a recording")
    return np.stack(result)


def list_frame_names(folder: str | Path) -> list[str]:
    """Validate consecutive frame names without decoding any images."""
    folder = Path(folder)
    files = sorted(folder.glob("frame_*.jpg"))
    expected = [f"frame_{i:04d}.jpg" for i in range(len(files))]
    if not files or [file.name for file in files] != expected:
        raise ValueError(f"Missing or nonconsecutive frames in {folder}")
    return expected


def load_frame_directory(folder: str | Path) -> tuple[list[str], np.ndarray]:
    """Load extracted frame_0000.jpg ... frames; no label CSV is accessed."""
    folder = Path(folder)
    expected = list_frame_names(folder)
    frames = []
    for name in expected:
        file = folder / name
        frame = cv2.imread(str(file), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise OSError(f"Cannot decode {file}")
        frames.append(frame)
    return expected, gray_frames(frames)


def iter_frame_directory(folder: str | Path) -> Iterable[np.ndarray]:
    """Decode consecutive extracted frames one at a time for causal processing."""
    folder = Path(folder)
    for name in list_frame_names(folder):
        file = folder / name
        frame = cv2.imread(str(file), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise OSError(f"Cannot decode {file}")
        yield frame


def iter_video_frames(path: str | Path) -> Iterable[np.ndarray]:
    """Decode a video sequentially without retaining its image frames."""
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise OSError(path)
    try:
        while True:
            okay, bgr = capture.read()
            if not okay:
                break
            yield cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    finally:
        capture.release()


def sample_video(path: str | Path, samples: int = 30) -> np.ndarray:
    """Uniformly sample an unlabeled MP4 for scene-registration probing."""
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise OSError(path)
    count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    if count <= 0:
        capture.release()
        raise ValueError(f"Video has no frames: {path}")
    positions = np.linspace(0, count - 1, min(samples, count)).round().astype(int)
    frames = []
    try:
        for position in positions:
            capture.set(cv2.CAP_PROP_POS_FRAMES, int(position))
            okay, bgr = capture.read()
            if not okay:
                raise OSError(f"Cannot decode frame {position} in {path}")
            frames.append(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY))
    finally:
        capture.release()
    return gray_frames(frames)


def median_background(frames: np.ndarray) -> np.ndarray:
    return np.median(frames, axis=0).astype(np.uint8)


def _orb_registration(reference: np.ndarray, moving: np.ndarray) -> tuple[np.ndarray | None, dict]:
    orb = cv2.ORB_create(nfeatures=4000)
    key_ref, desc_ref = orb.detectAndCompute(reference, None)
    key_mov, desc_mov = orb.detectAndCompute(moving, None)
    if desc_ref is None or desc_mov is None:
        return None, {"status": "failed", "reason": "insufficient ORB keypoints"}
    pairs = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(desc_mov, desc_ref, k=2)
    good = [pair[0] for pair in pairs
            if len(pair) == 2 and pair[0].distance < 0.75 * pair[1].distance]
    if len(good) < 15:
        return None, {"status": "failed", "reason": "insufficient descriptor matches",
                      "good_matches": len(good)}
    source = np.float32([key_mov[match.queryIdx].pt for match in good])
    target = np.float32([key_ref[match.trainIdx].pt for match in good])
    matrix, inliers = cv2.estimateAffinePartial2D(source, target, method=cv2.RANSAC,
                                                  ransacReprojThreshold=3.0)
    if matrix is None or inliers is None:
        return None, {"status": "failed", "reason": "RANSAC failed",
                      "good_matches": len(good)}
    inlier_count = int(inliers.sum())
    fraction = inlier_count / len(good)
    scale = float(np.hypot(matrix[0, 0], matrix[1, 0]))
    transformed = cv2.transform(source.reshape(1, -1, 2), matrix).reshape(-1, 2)
    reprojection = np.linalg.norm(transformed - target, axis=1)
    median_error = (float(np.median(reprojection[inliers.ravel() != 0]))
                    if inlier_count else float("inf"))
    accepted = inlier_count >= 30 and fraction >= 0.5 and 0.5 <= scale <= 2.0
    details = {"status": "ok" if accepted else "failed",
               "reason": None if accepted else "registration quality threshold",
               "good_matches": len(good), "ransac_inliers": inlier_count,
               "inlier_fraction": fraction, "scale": scale,
               "median_inlier_reprojection_px": median_error,
               "affine_moving_to_reference": matrix.tolist()}
    return (matrix if accepted else None), details


class CanonicalVideoFrontend:
    """Offline visual normalization and a pair of simple, label-free features."""

    def __init__(self, roi: tuple[int, int, int, int] | None = None):
        self.roi = roi
        self.reference_background: np.ndarray | None = None

    def fit_reference(self, frames: Iterable[np.ndarray]) -> "CanonicalVideoFrontend":
        reference = gray_frames(frames)
        self.reference_background = median_background(reference)
        h, w = self.reference_background.shape
        if self.roi is None:
            xl, yt, xr, yb = DEFAULT_ROI_FRACTIONS
            self.roi = (round(xl * w), round(yt * h), round(xr * w), round(yb * h))
        left, top, right, bottom = self.roi
        if not (0 <= left < right <= w and 0 <= top < bottom <= h):
            raise ValueError(f"ROI {self.roi} lies outside reference frame {(w, h)}")
        return self

    def fit_reference_bounded(self, frames: Iterable[np.ndarray], *,
                              max_frames: int = 64) -> "CanonicalVideoFrontend":
        """Approximate a reference median using bounded-memory reservoir sampling.

        This reads the reference recording once and stores at most ``max_frames``
        images. It is intended for long calibration recordings; the default
        ``fit_reference`` still uses the exact full-recording median.
        """
        if max_frames < 1:
            raise ValueError("max_frames must be positive")
        rng = np.random.default_rng(0)
        selected: list[np.ndarray] = []
        shape = None
        for index, frame in enumerate(frames):
            gray = _gray_frame(frame)
            if shape is None:
                shape = gray.shape
            elif gray.shape != shape:
                raise ValueError("Frame sizes must be constant within a recording")
            if index < max_frames:
                selected.append(gray.copy())
            else:
                slot = int(rng.integers(0, index + 1))
                if slot < max_frames:
                    selected[slot] = gray.copy()
        if not selected:
            raise ValueError("At least one frame is needed")
        return self.fit_reference(selected)

    def transform(self, frames: Iterable[np.ndarray], *, reference: bool = False,
                  allow_unregistered: bool = False) -> VisualFeatures:
        if self.reference_background is None:
            raise RuntimeError("Call fit_reference before transform")
        gray = gray_frames(frames)
        if reference:
            if gray.shape[1:] != self.reference_background.shape:
                raise ValueError("Reference frames differ from the fitted canvas")
            aligned = gray
            registration = {"status": "ok", "method": "identity reference"}
        else:
            matrix, registration = _orb_registration(
                self.reference_background, median_background(gray)
            )
            if matrix is None:
                if not allow_unregistered:
                    return VisualFeatures(
                        appearance=np.empty((len(gray), 0), dtype=np.float32),
                        motion=np.empty((len(gray), 0), dtype=np.float32),
                        quality=np.empty((len(gray), 0), dtype=np.float32),
                        registration=registration,
                        usable=False,
                    )
                h, w = self.reference_background.shape
                aligned = np.stack([_letterbox_gray(frame, (h, w)) for frame in gray])
                registration["status"] = "unregistered"
                registration["method"] = "letterbox only; scene alignment failed"
                usable = False
            else:
                h, w = self.reference_background.shape
                aligned = np.stack([
                    cv2.warpAffine(frame, matrix, (w, h), flags=cv2.INTER_LINEAR)
                    for frame in gray
                ])
                registration["method"] = "ORB + RANSAC on full-video medians"
                usable = True
        if reference:
            usable = True

        left, top, right, bottom = self.roi
        cropped = aligned[:, top:bottom, left:right]
        background_crop = median_background(aligned)[top:bottom, left:right]
        appearance = []
        motion = []
        quality = []
        previous = None
        for frame in cropped:
            gray32 = cv2.resize(frame, (32, 32), interpolation=cv2.INTER_AREA)
            appearance.append(gray32.reshape(-1).astype(np.float32) / 255.0)
            small = cv2.resize(frame, (96, 96), interpolation=cv2.INTER_AREA)
            if previous is None:
                movement = np.zeros(384, dtype=np.float32)
                energy = 0.0
            else:
                delta = small.astype(np.float32) - previous.astype(np.float32)
                signed = cv2.resize(delta, (16, 16), interpolation=cv2.INTER_AREA).reshape(-1) / 255.0
                flow = cv2.calcOpticalFlowFarneback(
                    previous, small, None, pyr_scale=0.5, levels=2, winsize=13,
                    iterations=2, poly_n=5, poly_sigma=1.2, flags=0,
                )
                flow_x = cv2.resize(flow[..., 0], (8, 8), interpolation=cv2.INTER_AREA).reshape(-1) / 96.0
                flow_y = cv2.resize(flow[..., 1], (8, 8), interpolation=cv2.INTER_AREA).reshape(-1) / 96.0
                movement = np.r_[signed, flow_x, flow_y].astype(np.float32)
                energy = float(np.mean(np.abs(delta)) / 255.0)
            motion.append(movement)
            foreground = float(np.mean(cv2.absdiff(frame, background_crop) > 22))
            sharpness = float(cv2.Laplacian(small, cv2.CV_32F).var())
            quality.append((energy, foreground, sharpness))
            previous = small
        return VisualFeatures(
            appearance=np.stack(appearance),
            motion=np.stack(motion),
            quality=np.asarray(quality, dtype=np.float32),
            registration=registration,
            usable=usable,
        )

    def transform_causal(self, frames: Iterable[np.ndarray], *,
                         reference: bool = False) -> VisualFeatures:
        """Extract features from a target stream using only past/current frames.

        Calibration must have been fitted first. Each frame is independently
        registered to the fixed reference background. Failed frames receive
        zero features and ``frame_usable=False``; ``usable`` is only True if
        every frame registers. The fixed reference is also used for foreground
        quality, so target-video future frames never enter any output.

        Frame images are consumed one at a time. Returned feature arrays and
        the validity vector still grow with the number of frames.
        """
        if self.reference_background is None or self.roi is None:
            raise RuntimeError("Call fit_reference before transform_causal")
        h, w = self.reference_background.shape
        left, top, right, bottom = self.roi
        background_crop = self.reference_background[top:bottom, left:right]
        appearance: list[np.ndarray] = []
        motion: list[np.ndarray] = []
        quality: list[tuple[float, float, float]] = []
        valid: list[bool] = []
        failed_indices: list[int] = []
        inliers: list[int] = []
        previous = None
        source_shape = None
        for index, frame in enumerate(frames):
            gray = _gray_frame(frame)
            if source_shape is None:
                source_shape = gray.shape
            elif gray.shape != source_shape:
                raise ValueError("Frame sizes must be constant within a recording")
            if reference:
                if gray.shape != (h, w):
                    raise ValueError("Reference frames differ from the fitted canvas")
                aligned = gray
                okay = True
            else:
                matrix, details = _orb_registration(self.reference_background, gray)
                okay = matrix is not None
                if okay:
                    aligned = cv2.warpAffine(gray, matrix, (w, h),
                                             flags=cv2.INTER_LINEAR)
                    inliers.append(details["ransac_inliers"])
            valid.append(okay)
            if not okay:
                failed_indices.append(index)
                appearance.append(np.zeros(1024, dtype=np.float32))
                motion.append(np.zeros(384, dtype=np.float32))
                quality.append((0.0, 0.0, 0.0))
                previous = None
                continue
            cropped = aligned[top:bottom, left:right]
            gray32 = cv2.resize(cropped, (32, 32), interpolation=cv2.INTER_AREA)
            appearance.append(gray32.reshape(-1).astype(np.float32) / 255.0)
            small = cv2.resize(cropped, (96, 96), interpolation=cv2.INTER_AREA)
            if previous is None:
                movement = np.zeros(384, dtype=np.float32)
                energy = 0.0
            else:
                delta = small.astype(np.float32) - previous.astype(np.float32)
                signed = cv2.resize(delta, (16, 16), interpolation=cv2.INTER_AREA).reshape(-1) / 255.0
                flow = cv2.calcOpticalFlowFarneback(
                    previous, small, None, pyr_scale=0.5, levels=2, winsize=13,
                    iterations=2, poly_n=5, poly_sigma=1.2, flags=0,
                )
                flow_x = cv2.resize(flow[..., 0], (8, 8), interpolation=cv2.INTER_AREA).reshape(-1) / 96.0
                flow_y = cv2.resize(flow[..., 1], (8, 8), interpolation=cv2.INTER_AREA).reshape(-1) / 96.0
                movement = np.r_[signed, flow_x, flow_y].astype(np.float32)
                energy = float(np.mean(np.abs(delta)) / 255.0)
            motion.append(movement)
            foreground = float(np.mean(cv2.absdiff(cropped, background_crop) > 22))
            sharpness = float(cv2.Laplacian(small, cv2.CV_32F).var())
            quality.append((energy, foreground, sharpness))
            previous = small
        if not valid:
            raise ValueError("At least one frame is needed")
        registration = {
            "status": "ok" if not failed_indices else "failed",
            "method": ("identity reference" if reference else
                       "causal per-frame ORB + RANSAC against fitted reference"),
            "frames": len(valid),
            "registered_frames": len(valid) - len(failed_indices),
            "failed_frame_indices": failed_indices,
            "median_ransac_inliers": float(np.median(inliers)) if inliers else None,
        }
        return VisualFeatures(
            appearance=np.stack(appearance),
            motion=np.stack(motion),
            quality=np.asarray(quality, dtype=np.float32),
            registration=registration,
            usable=not failed_indices,
            frame_usable=np.asarray(valid, dtype=bool),
        )


def robot_centered_descriptor(frame: np.ndarray, mask: np.ndarray, *,
                              output_size: int = 32,
                              min_mask_pixels: int = 32,
                              mask_threshold: float = 0.5) -> np.ndarray:
    """Describe a verified robot mask, independent of scene registration.

    Returns masked grayscale, binary silhouette, and normalized bounding box
    center/size (``2 * output_size**2 + 4`` floats). A caller must provide a
    robot foreground mask; this function cannot verify its semantic accuracy.
    Invalid or empty masks fail explicitly instead of yielding plausible data.
    Train and inference must use this same descriptor and mask convention.
    """
    gray = _gray_frame(frame)
    foreground = np.asarray(mask)
    if foreground.ndim != 2 or foreground.shape != gray.shape:
        raise ValueError("Robot mask must be 2-D and match the frame size")
    if output_size < 4 or min_mask_pixels < 1 or not 0 < mask_threshold <= 1:
        raise ValueError("Invalid output_size, min_mask_pixels, or mask_threshold")
    if foreground.dtype == bool:
        pass
    elif np.issubdtype(foreground.dtype, np.floating):
        if not np.isfinite(foreground).all():
            raise ValueError("Robot mask contains non-finite values")
        if foreground.min() < 0 or foreground.max() > 1:
            raise ValueError("Floating robot mask values must lie in [0, 1]")
        foreground = foreground >= mask_threshold
    elif np.issubdtype(foreground.dtype, np.integer):
        foreground = foreground != 0
    else:
        raise ValueError("Robot mask must be bool, integer, or probability values")
    if int(foreground.sum()) < min_mask_pixels:
        raise ValueError("Robot mask is empty or too small")
    ys, xs = np.nonzero(foreground)
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    height, width = gray.shape
    margin = max(2, round(0.1 * max(x1 - x0, y1 - y0)))
    top, bottom = max(0, y0 - margin), min(height, y1 + margin)
    left, right = max(0, x0 - margin), min(width, x1 + margin)
    cropped_mask = foreground[top:bottom, left:right].astype(np.uint8)
    cropped_gray = gray[top:bottom, left:right] * cropped_mask
    image32 = cv2.resize(cropped_gray, (output_size, output_size),
                         interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
    mask32 = cv2.resize(cropped_mask, (output_size, output_size),
                        interpolation=cv2.INTER_AREA).astype(np.float32)
    box = np.array(((x0 + x1) / (2 * width), (y0 + y1) / (2 * height),
                    (x1 - x0) / width, (y1 - y0) / height), dtype=np.float32)
    return np.r_[image32.ravel(), mask32.ravel(), box].astype(np.float32)


def _letterbox_gray(frame: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    """Preserve aspect ratio when extracting diagnostics from an unseen scene."""
    target_h, target_w = shape
    source_h, source_w = frame.shape
    factor = min(target_h / source_h, target_w / source_w)
    width = max(1, round(source_w * factor))
    height = max(1, round(source_h * factor))
    resized = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
    canvas = np.full((target_h, target_w), 128, dtype=np.uint8)
    x = (target_w - width) // 2
    y = (target_h - height) // 2
    canvas[y:y + height, x:x + width] = resized
    return canvas
