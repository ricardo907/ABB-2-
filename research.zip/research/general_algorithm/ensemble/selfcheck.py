"""Synthetic checks for log coverage, arbitrary joint count, and aggregation."""

from __future__ import annotations

import numpy as np

from offset_ensemble import OffsetHypothesis, OffsetHypothesisEnsemble, scenarios_from_scan
from trajectory import JointTrajectoryEstimator


def run_case(fps: int, joints: int) -> dict:
    rng = np.random.default_rng(fps + joints)
    count = 5 * fps
    frame_time = np.arange(count, dtype=np.float64) / fps
    log_time = np.arange(0.0, 5.5, 0.004)
    phases = np.arange(joints) * 0.2

    def pose(time):
        return np.sin(time[:, None] * (1.2 + np.arange(joints)[None, :] * 0.04) + phases)

    log_angles = pose(log_time)
    visually_aligned = pose(frame_time + 0.5)
    appearance = np.c_[visually_aligned + rng.normal(0, 0.02, visually_aligned.shape),
                       np.sin(visually_aligned)]
    increments = np.diff(visually_aligned, axis=0, prepend=visually_aligned[[0]])
    motion = np.c_[increments + rng.normal(0, 0.005, increments.shape), increments * 0.7]
    hypotheses = [
        OffsetHypothesis(0.4, 2.0),
        OffsetHypothesis(0.5, 3.0),
        OffsetHypothesis(1.0, 1.0),
        OffsetHypothesis(10.0, 2.0),  # No video frame has log support.
    ]
    ensemble = OffsetHypothesisEnsemble().fit(
        appearance, motion, fps, log_time, log_angles,
        [f"joint_{joint + 1}" for joint in range(joints)], hypotheses,
    )
    prediction = ensemble.predict(appearance, motion)
    assert len(ensemble.models) == 3
    assert len(ensemble.dropped_hypotheses) == 1
    assert len(ensemble.joint_names) == joints
    assert np.isclose(ensemble.weights.sum(), 1.0)
    assert prediction["angles"].shape == (count, joints)
    assert prediction["hypothesis_angles"].shape == (3, count, joints)
    assert prediction["timing_disagreement"].shape == (count, joints)
    assert np.isfinite(prediction["angles"]).all()
    assert np.all(prediction["timing_disagreement"] >= 0)
    manual = np.sum(ensemble.weights[:, None, None] * prediction["hypothesis_angles"], axis=0)
    assert np.allclose(manual, prediction["angles"])
    assert all(item["last_log_query_time_s"] <= log_time[-1] + 1e-12
               for item in ensemble.hypotheses)
    assert ensemble.hypotheses[-1]["last_frame"] < count - 1
    return {
        "fps": fps,
        "joints": joints,
        "offsets": [item["offset_s"] for item in ensemble.hypotheses],
        "valid_frame_counts": [item["train_frames"] for item in ensemble.hypotheses],
        "mean_timing_disagreement": float(prediction["timing_disagreement"].mean()),
        "reliable_fraction": float(prediction["consensus_reliable"].mean()),
    }


def check_measured_frame_intervals() -> None:
    """The same visual speed must integrate over actual elapsed time."""
    frames = 80
    nominal_dt = 0.05
    times = np.arange(frames, dtype=float) * nominal_dt
    angles = np.c_[0.4 * np.sin(1.1 * times), 0.2 * np.cos(0.8 * times)]
    appearance = np.c_[angles, np.sin(2 * angles), np.ones(frames)]
    motion = np.zeros((frames, 3))
    motion[1:, :2] = np.diff(angles, axis=0)
    motion[1:, 2] = nominal_dt
    model = JointTrajectoryEstimator().fit(
        appearance, motion, angles, ["shoulder", "elbow"], frame_times_s=times
    )
    regular = model.predict(appearance[:12], motion[:12], frame_times_s=times[:12])
    spaced_times = np.arange(12, dtype=float) * (2 * nominal_dt)
    spaced_motion = motion[:12].copy()
    spaced_motion[1:] *= 2
    spaced = model.predict(appearance[:12], spaced_motion, frame_times_s=spaced_times)
    assert np.allclose(spaced["predicted_increment"][1:],
                       2 * regular["predicted_increment"][1:], atol=1e-10)
    assert np.allclose(spaced["frame_time_delta_s"][1:], 2 * nominal_dt)
    gap_times = times[:12].copy()
    gap_times[6:] += 4 * nominal_dt
    gap = model.predict(appearance[:12], motion[:12], frame_times_s=gap_times)
    assert not gap["reliable"][6].any()
    try:
        model.predict(appearance[:12], motion[:12], frame_times_s=np.zeros(12))
    except ValueError:
        pass
    else:
        raise AssertionError("Duplicate target timestamps were accepted")


if __name__ == "__main__":
    check_measured_frame_intervals()
    print(run_case(24, 3))
    print(run_case(30, 7))
    sensitivity = scenarios_from_scan({
        "best_offset_s": 1.0,
        "block_bootstrap_peak_quantiles_5_50_95_s": [0.96, 1.0, 1.21],
        "candidate_step_s": 1.0 / 24.0,
    })
    assert [item.offset_s for item in sensitivity] == [1.0, 0.96, 1.21, 0.0]
    print({"sensitivity_offsets": [item.offset_s for item in sensitivity]})
