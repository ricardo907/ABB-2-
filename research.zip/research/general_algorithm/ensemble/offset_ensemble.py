"""Marginalize provisional video/log offsets in a variable-joint estimator.

The input weights describe *scenarios*, not calibrated probabilities. Neither
the between-scenario spread nor the returned standard deviation has a coverage
guarantee. An external synchronization event is still required for validation.
"""

from __future__ import annotations

import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np


# The module is deliberately runnable both in this work directory and after
# copying ensemble/ beside trajectory.py into a user-facing package.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from trajectory import EstimatorConfig, JointTrajectoryEstimator  # noqa: E402


@dataclass(frozen=True)
class OffsetHypothesis:
    """One assumed mapping: encoder_time = video_time + offset_s."""

    offset_s: float
    weight: float = 1.0


def scenarios_from_scan(scan: dict, *, include_zero: bool = True) -> list[OffsetHypothesis]:
    """Choose uniform sensitivity scenarios from a weak offset scan.

    The peak and bootstrap peak quantiles are diagnostic candidates only. The
    resulting equal weights are **not** posterior probabilities. Keeping zero
    offset exposes the assumption used by the original supplied labels.
    """
    values = [float(scan["best_offset_s"])]
    quantiles = scan.get("block_bootstrap_peak_quantiles_5_50_95_s")
    if quantiles is not None:
        if len(quantiles) != 3:
            raise ValueError("Peak quantiles must be [p05, p50, p95]")
        values.extend((float(quantiles[0]), float(quantiles[2])))
    if include_zero:
        values.append(0.0)
    step = float(scan.get("candidate_step_s", 0.0))
    tolerance = max(step * 0.51, 1e-6)
    unique = []
    for value in values:
        if not math.isfinite(value):
            raise ValueError("Scan contains a nonfinite candidate offset")
        if not any(abs(value - previous) <= tolerance for previous in unique):
            unique.append(value)
    return [OffsetHypothesis(value, 1.0) for value in unique]


def _matrix(name: str, values: np.ndarray, rows: int | None = None) -> np.ndarray:
    result = np.asarray(values, dtype=np.float64)
    if result.ndim != 2 or result.shape[0] < 1 or result.shape[1] < 1:
        raise ValueError(f"{name} must be a nonempty two-dimensional array")
    if rows is not None and len(result) != rows:
        raise ValueError(f"{name} has {len(result)} rows, expected {rows}")
    if not np.isfinite(result).all():
        raise ValueError(f"{name} must contain only finite values")
    return result


class OffsetHypothesisEnsemble:
    """Train one visual trajectory model per plausible source-log offset.

    All estimators share the same source video and joint order. A candidate is
    fitted only on consecutive source frames whose queried log time is inside
    the log. The target video needs no encoder log at prediction time, but the
    caller must establish that its visual registration is usable.
    """

    def __init__(
        self,
        estimator_config: EstimatorConfig = EstimatorConfig(),
        *,
        min_reliable_weight: float = 0.8,
        max_disagreement_fraction_of_range: float = 0.25,
    ) -> None:
        if not 0 < min_reliable_weight <= 1:
            raise ValueError("min_reliable_weight must be in (0, 1]")
        if max_disagreement_fraction_of_range <= 0:
            raise ValueError("max_disagreement_fraction_of_range must be positive")
        self.estimator_config = estimator_config
        self.min_reliable_weight = min_reliable_weight
        self.max_disagreement_fraction_of_range = max_disagreement_fraction_of_range
        self.fitted = False

    def fit(
        self,
        appearance: np.ndarray,
        motion: np.ndarray,
        fps: float,
        log_times: np.ndarray,
        log_angles: np.ndarray,
        joint_names: Sequence[str],
        hypotheses: Sequence[OffsetHypothesis],
        joint_limits: np.ndarray | None = None,
        joint_types: Sequence[str] | None = None,
        *,
        frame_times_s: np.ndarray | None = None,
    ) -> "OffsetHypothesisEnsemble":
        x_abs = _matrix("appearance", appearance)
        x_motion = _matrix("motion", motion, len(x_abs))
        if not math.isfinite(fps) or fps <= 0:
            raise ValueError("fps must be finite and positive")
        times = np.asarray(log_times, dtype=np.float64)
        if times.ndim != 1 or len(times) < 2 or not np.isfinite(times).all():
            raise ValueError("log_times must contain at least two finite timestamps")
        if np.any(np.diff(times) <= 0):
            raise ValueError("log_times must be strictly increasing")
        y_log = _matrix("log_angles", log_angles, len(times))
        names = tuple(str(name) for name in joint_names)
        if len(names) != y_log.shape[1] or len(set(names)) != len(names):
            raise ValueError("joint_names must be unique and match log columns")
        if joint_types is not None:
            if len(joint_types) != y_log.shape[1]:
                raise ValueError("joint_types must match log columns")
            y_log = y_log.copy()
            for index, kind in enumerate(joint_types):
                if kind == "continuous":
                    y_log[:, index] = np.unwrap(y_log[:, index])
        if not hypotheses:
            raise ValueError("At least one offset hypothesis is required")
        offsets = [float(item.offset_s) for item in hypotheses]
        weights = [float(item.weight) for item in hypotheses]
        if any(not math.isfinite(value) for value in offsets + weights):
            raise ValueError("Hypothesis offsets/weights must be finite")
        if any(value <= 0 for value in weights):
            raise ValueError("Hypothesis weights must be positive")
        if len(set(offsets)) != len(offsets):
            raise ValueError("Duplicate offsets would count the same scenario twice")

        if frame_times_s is None:
            frame_times = np.arange(len(x_abs), dtype=np.float64) / fps
        else:
            frame_times = np.asarray(frame_times_s, dtype=np.float64)
            if frame_times.shape != (len(x_abs),) or not np.isfinite(frame_times).all():
                raise ValueError("frame_times_s must contain one finite timestamp per frame")
            if np.any(np.diff(frame_times) <= 0):
                raise ValueError("frame_times_s must be strictly increasing")
        models = []
        retained = []
        dropped = []
        for item in hypotheses:
            query = frame_times + float(item.offset_s)
            valid = (query >= times[0]) & (query <= times[-1])
            indices = np.flatnonzero(valid)
            required = max(12, self.estimator_config.neighbor_count + 2)
            if len(indices) < required:
                dropped.append({"offset_s": float(item.offset_s),
                                "weight": float(item.weight),
                                "reason": f"only {len(indices)} log-supported frames; need {required}"})
                continue
            if np.any(np.diff(indices) != 1):
                raise RuntimeError("Log-supported source frames must form one interval")
            labels = np.column_stack([
                np.interp(query[indices], times, y_log[:, joint])
                for joint in range(y_log.shape[1])
            ])
            aligned_motion = x_motion[indices].copy()
            # Row zero of a sub-trajectory has no preceding valid frame. The
            # estimator trains increments only from row one onward.
            aligned_motion[0] = 0.0
            model = JointTrajectoryEstimator(self.estimator_config).fit(
                x_abs[indices], aligned_motion, labels, list(names), joint_limits,
                list(joint_types) if joint_types is not None else None,
                frame_times_s=frame_times[indices],
            )
            models.append(model)
            retained.append({"offset_s": float(item.offset_s),
                             "input_weight": float(item.weight),
                             "first_frame": int(indices[0]),
                             "last_frame": int(indices[-1]),
                             "train_frames": len(indices),
                             "last_log_query_time_s": float(query[indices[-1]])})
        if not models:
            raise ValueError("No offset hypothesis has enough log-supported training frames")
        normalized = np.asarray([item["input_weight"] for item in retained], dtype=np.float64)
        normalized /= normalized.sum()
        for item, weight in zip(retained, normalized):
            item["normalized_weight"] = float(weight)
        self.models = models
        self.hypotheses = retained
        self.dropped_hypotheses = dropped
        self.weights = normalized
        self.joint_names = names
        self.fps = float(fps)
        self.training_range = np.maximum.reduce([model.train_max for model in models]) - np.minimum.reduce(
            [model.train_min for model in models]
        )
        self.training_range = np.maximum(self.training_range, 1e-9)
        self.fitted = True
        return self

    def predict(self, appearance: np.ndarray, motion: np.ndarray, *,
                frame_times_s: np.ndarray | None = None,
                temporal_mode: str = "smoothed") -> dict[str, np.ndarray]:
        if not self.fitted:
            raise RuntimeError("Fit the ensemble before prediction")
        if temporal_mode not in {"smoothed", "causal"}:
            raise ValueError("temporal_mode must be smoothed or causal")
        x_abs = _matrix("appearance", appearance)
        x_motion = _matrix("motion", motion, len(x_abs))
        time_aware = all(hasattr(model, "reference_dt_s") for model in self.models)
        if frame_times_s is not None and not time_aware:
            raise ValueError("This saved model predates timestamp-aware training; retrain it")
        if time_aware and frame_times_s is None:
            frame_times_s = np.arange(len(x_abs), dtype=np.float64) / self.fps
        predictions = [model.predict(x_abs, x_motion, frame_times_s=frame_times_s)
                       if time_aware else model.predict(x_abs, x_motion)
                       for model in self.models]
        angle_key = "angles" if temporal_mode == "smoothed" else "causal_angles"
        sd_key = "heuristic_sd" if temporal_mode == "smoothed" else "causal_sd"
        members = np.stack([item[angle_key] for item in predictions], axis=0)
        members_sd = np.stack([item[sd_key] for item in predictions], axis=0)
        members_reliable = np.stack([item["reliable"] for item in predictions], axis=0)
        members_quality = np.stack([item["quality"] for item in predictions], axis=0)
        weight = self.weights[:, None, None]
        mean = np.sum(weight * members, axis=0)
        between_var = np.sum(weight * (members - mean[None, :, :]) ** 2, axis=0)
        within_var = np.sum(weight * members_sd ** 2, axis=0)
        spread = np.sqrt(np.maximum(between_var, 0.0))
        support = np.sum(weight * members_reliable, axis=0)
        consensus = (
            (support >= self.min_reliable_weight)
            & (spread <= self.max_disagreement_fraction_of_range * self.training_range[None, :])
        )
        safe = mean.copy()
        safe[~consensus] = np.nan
        return {
            "angles": mean,
            "safe_angles": safe,
            "consensus_reliable": consensus,
            "reliable_weight": support,
            "weighted_quality": np.sum(weight * members_quality, axis=0),
            "timing_disagreement": spread,
            "heuristic_sd": np.sqrt(np.maximum(within_var + between_var, 0.0)),
            "hypothesis_angles": members,
            "temporal_mode": temporal_mode,
            "frame_time_delta_s": predictions[0]["frame_time_delta_s"] if time_aware else
                np.r_[0.0, np.full(len(x_abs) - 1, 1.0 / getattr(self, "fps", 1.0))],
        }
