"""Meaningful self-check: recover a hidden lag from noisy 4-joint motion."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from time_sync import interpolate_frame_labels, read_encoder_log, scan_offsets


HERE = Path(__file__).resolve().parent


def main() -> None:
    rng = np.random.default_rng(19)
    fps = 24.0
    true_lag = 20 / fps
    log_times = np.arange(0, 10.0 + 0.0001, 0.004)
    angles = np.column_stack([
        0.75 * np.sin(0.77 * log_times + 0.13 * log_times**2)
        + 0.13 * np.sin(3.7 * log_times + 0.3),
        0.42 * np.cos(1.16 * log_times + 0.025 * log_times**2)
        + 0.09 * np.sin(4.3 * log_times + 1.1),
        0.53 * np.sin(0.55 * log_times + 0.046 * log_times**2 + 0.9),
        0.23 * np.cos(1.43 * log_times + 0.071 * log_times**2 + 0.4),
    ])
    frame_count = 218
    transitions = np.arange(1, frame_count) / fps
    before = transitions - 1 / fps + true_lag
    after = transitions + true_lag
    prior = np.column_stack([np.interp(before, log_times, angles[:, i]) for i in range(4)])
    next_ = np.column_stack([np.interp(after, log_times, angles[:, i]) for i in range(4)])
    visual = np.linalg.norm(next_ - prior, axis=1)
    visual = 2.2 * visual + rng.normal(0, 0.0025, size=len(visual))
    visual[rng.choice(len(visual), size=5, replace=False)] += 0.04
    visual = np.maximum(visual, 0)
    trace = {"fps": fps, "frame_count": frame_count,
             "transition_times_s": transitions, "visual_motion": visual}
    scan = scan_offsets(trace, log_times, angles, bootstrap_repeats=40)
    recovered = scan["best_offset_s"]
    if abs(recovered - true_lag) > 1 / fps + 1e-8:
        raise AssertionError(f"Hidden offset {true_lag:.4f}s recovered as {recovered:.4f}s")

    # Frame-rate handling is data driven, not fixed to ABB's 24 fps videos.
    other_fps = 30.0
    other_lag = 0.8
    other_transitions = np.arange(1, 271) / other_fps
    other_prior = np.column_stack([
        np.interp(other_transitions - 1 / other_fps + other_lag,
                  log_times, angles[:, i]) for i in range(4)
    ])
    other_next = np.column_stack([
        np.interp(other_transitions + other_lag,
                  log_times, angles[:, i]) for i in range(4)
    ])
    other_trace = {
        "fps": other_fps,
        "frame_count": 271,
        "transition_times_s": other_transitions,
        "visual_motion": np.linalg.norm(other_next - other_prior, axis=1),
    }
    other_scan = scan_offsets(other_trace, log_times, angles, bootstrap_repeats=0)
    if abs(other_scan["best_offset_s"] - other_lag) > 1 / other_fps + 1e-8:
        raise AssertionError("30 fps hidden offset was not recovered")

    # Check generic joint discovery and source-name mapping.
    temporary = HERE / "synthetic_log.xlsx"
    table = pd.DataFrame({"Time(s)": log_times})
    joint_names = [f"joint_{i}" for i in range(1, 5)]
    for index, name in enumerate(joint_names):
        table[name] = angles[:, index]
    table.to_excel(temporary, index=False)
    try:
        reread_times, reread_angles, reread_names = read_encoder_log(temporary)
    finally:
        temporary.unlink(missing_ok=True)
    assert reread_names == joint_names
    assert np.allclose(reread_times, log_times)
    assert np.allclose(reread_angles, angles)

    # A short log must exclude out-of-support video frames; it must not clamp.
    truncated = interpolate_frame_labels(frame_count, fps, log_times[:2350],
                                         angles[:2350], offset_s=1.333)
    if truncated.iloc[-1]["image"] != "frame_0193.jpg":
        raise AssertionError("Unexpected valid-frame boundary")
    print({"true_lag_s": true_lag, "recovered_lag_s": recovered,
           "other_fps_lag_s": other_scan["best_offset_s"],
           "peak_score": scan["best_score"], "generic_joint_count": len(reread_names),
           "last_valid_frame": truncated.iloc[-1]["image"]})


if __name__ == "__main__":
    main()
