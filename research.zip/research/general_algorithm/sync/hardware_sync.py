"""Pair camera exposures with encoder samples using measured clock events.

The fitted map is a data-processing step, not proof that a physical trigger was
wired correctly. The capture manifest and independent setup audit must verify
that provenance separately.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


def _integer_column(table: pd.DataFrame, name: str) -> np.ndarray:
    if name not in table:
        raise ValueError(f"Missing timestamp column: {name}")
    values = pd.to_numeric(table[name], errors="raise")
    if values.isna().any() or not np.issubdtype(values.dtype, np.integer):
        raise ValueError(f"{name} must contain integer nanoseconds without nulls")
    return values.to_numpy(dtype=np.int64)


def _increasing(values: np.ndarray, name: str) -> None:
    if len(values) < 2 or np.any(np.diff(values) <= 0):
        raise ValueError(f"{name} must be strictly increasing")


@dataclass(frozen=True)
class ClockMap:
    """camera_ns = camera_ref_ns + slope*(controller_ns-controller_ref_ns) + intercept_ns."""

    camera_ref_ns: int
    controller_ref_ns: int
    slope: float
    intercept_ns: float
    residual_ms_p95: float
    residual_ms_max: float
    first_camera_event_ns: int
    last_camera_event_ns: int
    event_count: int

    def controller_relative_seconds(self, camera_ns: np.ndarray,
                                    controller_origin_ns: int) -> np.ndarray:
        camera = np.asarray(camera_ns, dtype=np.int64)
        delta_controller_ns = (
            ((camera - np.int64(self.camera_ref_ns)).astype(np.float64) - self.intercept_ns)
            / self.slope
        )
        return (
            float(self.controller_ref_ns - controller_origin_ns) + delta_controller_ns
        ) / 1e9

    def report(self) -> dict:
        return {
            "event_count": self.event_count,
            "clock_drift_ppm": (self.slope - 1.0) * 1e6,
            "fit_residual_ms_p95": self.residual_ms_p95,
            "fit_residual_ms_max": self.residual_ms_max,
            "warning": "Clock-fit residual does not verify trigger wiring or image exposure semantics",
        }


def fit_clock_events(path: str | Path) -> ClockMap:
    events = pd.read_csv(path)
    for name in ("event_id", "camera_time_ns", "controller_time_ns"):
        if name not in events:
            raise ValueError(f"Sync events missing {name}")
    if len(events) < 3 or events["event_id"].isna().any() or not events["event_id"].is_unique:
        raise ValueError("Need at least three uniquely identified paired sync events")
    camera = _integer_column(events, "camera_time_ns")
    controller = _integer_column(events, "controller_time_ns")
    _increasing(camera, "camera_time_ns")
    _increasing(controller, "controller_time_ns")
    x = (controller - controller[0]).astype(np.float64)
    y = (camera - camera[0]).astype(np.float64)
    centered_x = x - x.mean()
    centered_y = y - y.mean()
    denominator = float(centered_x @ centered_x)
    if denominator <= 0:
        raise ValueError("Sync events have no measurable clock span")
    slope = float((centered_x @ centered_y) / denominator)
    intercept = float(y.mean() - slope * x.mean())
    if not np.isfinite(slope) or slope <= 0:
        raise ValueError("Clock fit has an invalid slope")
    residual_ms = np.abs(y - slope * x - intercept) / 1e6
    return ClockMap(
        int(camera[0]), int(controller[0]), slope, intercept,
        float(np.percentile(residual_ms, 95)), float(residual_ms.max()),
        int(camera[0]), int(camera[-1]), len(events),
    )


def read_hardware_encoder(path: str | Path, joint_columns: list[str]) -> tuple[np.ndarray, np.ndarray, int]:
    if Path(path).suffix.lower() != ".csv":
        raise ValueError("Hardware-timestamp encoder input must be CSV")
    if not joint_columns or len(joint_columns) != len(set(joint_columns)):
        raise ValueError("Pass unique --joint-columns in robot joint order")
    table = pd.read_csv(path)
    controller = _integer_column(table, "controller_time_ns")
    _increasing(controller, "controller_time_ns")
    absent = sorted(set(joint_columns) - set(table.columns))
    if absent:
        raise ValueError(f"Missing encoder joint columns: {absent}")
    angles = table[joint_columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=np.float64)
    if not np.isfinite(angles).all():
        raise ValueError("Encoder joint values must be finite")
    return (controller - controller[0]).astype(np.float64) / 1e9, angles, int(controller[0])


def aligned_frame_times(
    path: str | Path,
    frame_names: list[str],
    encoder_times_s: np.ndarray,
    controller_origin_ns: int,
    clock: ClockMap,
    fps: float,
    *,
    max_fit_residual_ms: float = 2.0,
    max_label_gap_ms: float = 10.0,
) -> tuple[np.ndarray, dict]:
    if max_fit_residual_ms <= 0 or max_label_gap_ms <= 0:
        raise ValueError("Sync and label-gap limits must be positive")
    if not np.isfinite(fps) or fps <= 0:
        raise ValueError("fps must be finite and positive")
    frames = pd.read_csv(path)
    indices = _integer_column(frames, "frame_index")
    camera = _integer_column(frames, "camera_time_ns")
    triggers = _integer_column(frames, "trigger_id")
    if len(indices) != len(frame_names) or not np.array_equal(indices, np.arange(len(frame_names))):
        raise ValueError("Frame timestamp rows must match the sorted frame directory, indexed 0..N-1")
    if "image" in frames and frames["image"].tolist() != list(frame_names):
        raise ValueError("Frame timestamp image names differ from the frame directory")
    _increasing(camera, "camera_time_ns")
    _increasing(triggers, "trigger_id")
    if np.any(np.diff(triggers) != 1):
        raise ValueError("Trigger IDs contain a gap: dropped capture or missing trigger")
    intervals = np.diff(camera).astype(np.float64) / 1e9
    median_interval = float(np.median(intervals))
    if abs(median_interval - 1.0 / fps) > max(0.0005, 0.02 / fps):
        raise ValueError("Measured camera frame interval differs from --fps")
    # A real exposure interval is retained for the time-aware trajectory model.
    # Trigger continuity is checked above; a delayed exposure is reported here.
    if clock.residual_ms_p95 > max_fit_residual_ms:
        raise ValueError("Clock-fit residual exceeds --max-sync-residual-ms")
    if clock.last_camera_event_ns - clock.first_camera_event_ns < 0.8 * int(camera[-1] - camera[0]):
        raise ValueError("Sync events do not span at least 80% of the video")
    mapped = clock.controller_relative_seconds(camera, controller_origin_ns)
    if mapped[0] < encoder_times_s[0] or mapped[-1] > encoder_times_s[-1]:
        raise ValueError("Encoder samples do not cover all mapped camera exposures")
    right = np.searchsorted(encoder_times_s, mapped)
    left = np.clip(right - 1, 0, len(encoder_times_s) - 1)
    right = np.clip(right, 0, len(encoder_times_s) - 1)
    nearest_gap_ms = np.minimum(
        np.abs(mapped - encoder_times_s[left]),
        np.abs(mapped - encoder_times_s[right]),
    ) * 1000.0
    gap_p95 = float(np.percentile(nearest_gap_ms, 95))
    if float(nearest_gap_ms.max()) > max_label_gap_ms:
        raise ValueError("At least one frame's nearest encoder gap exceeds --max-label-gap-ms")
    report = {
        "mode": "paired hardware clock events",
        "frame_count": len(frame_names),
        "median_frame_interval_ms": median_interval * 1000,
        "max_frame_interval_ms": float(intervals.max() * 1000),
        "intervals_over_3x_median": int(np.count_nonzero(intervals > 3 * median_interval)),
        "nearest_encoder_gap_ms_p95": gap_p95,
        "nearest_encoder_gap_ms_max": float(nearest_gap_ms.max()),
        "clock_fit": clock.report(),
        "sync_event_span_fraction": float(
            (clock.last_camera_event_ns - clock.first_camera_event_ns) / (camera[-1] - camera[0])
        ),
        "extrapolated_frame_edges": bool(
            camera[0] < clock.first_camera_event_ns or camera[-1] > clock.last_camera_event_ns
        ),
    }
    return mapped, report
