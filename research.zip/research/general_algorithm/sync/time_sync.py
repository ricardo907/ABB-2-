"""Weak video/encoder time-offset evidence and strict provisional labels.

The motion-correlation peak is useful for diagnosing a timestamp problem, but
it is not a hardware synchronization event or verified ground truth.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d
from scipy.stats import rankdata


WARNING = (
    "Visual-motion/encoder-speed correlation is weak synchronization evidence; "
    "verify the camera/log offset with a shared timestamp or visible trigger."
)


def read_encoder_log(
    path: str | Path,
    *,
    time_column: str = "Time(s)",
    joint_columns: list[str] | None = None,
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    suffix = Path(path).suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        table = pd.read_excel(path)
    elif suffix == ".csv":
        table = pd.read_csv(path)
    elif suffix == ".tsv":
        table = pd.read_csv(path, sep="\t")
    else:
        raise ValueError("Encoder log must be .xlsx, .xls, .csv, or .tsv")
    if joint_columns is None:
        candidates = []
        for name in table.columns:
            if name == time_column:
                continue
            match = re.search(r"(?:axis|joint)[_ -]?(\d+)(?!\d)", str(name), re.I)
            if match:
                candidates.append((int(match.group(1)), name))
        indices = [index for index, _ in candidates]
        if len(indices) != len(set(indices)):
            raise ValueError("Multiple log columns match the same joint index; pass --joints explicitly")
        joint_columns = [name for _, name in sorted(candidates)]
    if not joint_columns:
        raise ValueError("No joint columns found; pass --joints with explicit column names")
    if len(set(joint_columns)) != len(joint_columns):
        raise ValueError("Joint column names must be unique")
    columns = [time_column, *joint_columns]
    absent = sorted(set(columns) - set(table.columns))
    if absent:
        raise ValueError(f"Missing Excel columns: {absent}")
    values = table[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=np.float64)
    if not np.isfinite(values).all():
        raise ValueError("Encoder timestamps/angles contain nonfinite values")
    times = values[:, 0]
    if len(times) < 2 or np.any(np.diff(times) <= 0):
        raise ValueError("Encoder timestamps must be strictly increasing")
    return times - times[0], values[:, 1:], list(joint_columns)


def extract_motion_trace(video: str | Path,
                         roi_xyxy: tuple[float, float, float, float] = (0.03, 0.08, 0.85, 0.90)) -> dict:
    """Read every video frame and measure camera-space foreground movement."""
    left, top, right, bottom = roi_xyxy
    if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
        raise ValueError("ROI must satisfy 0 <= left < right <= 1 and 0 <= top < bottom <= 1")
    capture = cv2.VideoCapture(str(video))
    if not capture.isOpened():
        raise OSError(f"Cannot open video: {video}")
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    if not np.isfinite(fps) or fps <= 0:
        capture.release()
        raise ValueError(f"Invalid video FPS: {fps}")
    previous = None
    motion = []
    frame_count = 0
    try:
        while True:
            success, frame = capture.read()
            if not success:
                break
            frame_count += 1
            height, width = frame.shape[:2]
            roi = frame[int(height * top):int(height * bottom),
                        int(width * left):int(width * right)]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            reduced = cv2.resize(gray, (128, 128), interpolation=cv2.INTER_AREA).astype(np.float32)
            if previous is not None:
                # Ignore tiny compression/flicker differences.
                motion.append(float(np.maximum(np.abs(reduced - previous) - 2.0, 0.0).mean()))
            previous = reduced
    finally:
        capture.release()
    if frame_count < 4:
        raise ValueError("At least four decoded video frames are required")
    return {
        "fps": fps,
        "frame_count": frame_count,
        "roi_xyxy_fraction": list(roi_xyxy),
        "transition_times_s": np.arange(1, frame_count, dtype=np.float64) / fps,
        "visual_motion": np.asarray(motion, dtype=np.float64),
    }


def _winsorized_correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=np.float64)
    second = np.asarray(second, dtype=np.float64)
    if first.size < 8 or first.shape != second.shape:
        raise ValueError("Correlation needs at least eight paired samples")
    low_a, high_a = np.quantile(first, [0.05, 0.95])
    low_b, high_b = np.quantile(second, [0.05, 0.95])
    a = np.clip(first, low_a, high_a)
    b = np.clip(second, low_b, high_b)
    a = a - a.mean()
    b = b - b.mean()
    denominator = np.linalg.norm(a) * np.linalg.norm(b)
    if denominator <= 1e-12:
        return 0.0
    return float(a @ b / denominator)


def _rank_correlation(first: np.ndarray, second: np.ndarray) -> float:
    return _winsorized_correlation(rankdata(first), rankdata(second))


def _encoder_step_norm(query_times: np.ndarray, period: float,
                       log_times: np.ndarray, angles: np.ndarray, offset: float) -> np.ndarray:
    before = query_times - period + offset
    after = query_times + offset
    if before[0] < log_times[0] - 1e-9 or after[-1] > log_times[-1] + 1e-9:
        raise ValueError("Offset queries beyond encoder log support")
    prior = np.column_stack([
        np.interp(before, log_times, angles[:, axis]) for axis in range(angles.shape[1])
    ])
    next_ = np.column_stack([
        np.interp(after, log_times, angles[:, axis]) for axis in range(angles.shape[1])
    ])
    return np.linalg.norm(next_ - prior, axis=1)


def scan_offsets(
    trace: dict,
    log_times: np.ndarray,
    angles: np.ndarray,
    *,
    lag_min_s: float = -1.5,
    lag_max_s: float = 1.5,
    window_s: tuple[float, float] | None = None,
    bootstrap_repeats: int = 200,
    block_frames: int = 12,
    seed: int = 42,
) -> dict:
    """Compare all offsets on exactly the same video transitions.

    Block-bootstrap quantiles describe peak stability under the observed motion
    trace. They are not a statistical confidence interval for true sync error.
    """
    fps = float(trace["fps"])
    transition_times = np.asarray(trace["transition_times_s"], dtype=np.float64)
    visual_all = np.asarray(trace["visual_motion"], dtype=np.float64)
    if transition_times.shape != visual_all.shape:
        raise ValueError("Transition times and visual motion must have equal lengths")
    if angles.ndim != 2 or len(angles) != len(log_times) or angles.shape[1] < 1:
        raise ValueError("Encoder angles must be an N-by-J matrix with J >= 1")
    if not np.isfinite(visual_all).all():
        raise ValueError("Visual motion contains nonfinite values")
    if not lag_min_s < lag_max_s:
        raise ValueError("Invalid offset limits")
    period = 1.0 / fps
    if window_s is None:
        # One common support interval for every candidate. Trim both ends to
        # reduce start/stop artifacts without assuming a particular duration.
        overlap_start = max(transition_times[0], log_times[0] + period - lag_min_s)
        overlap_end = min(transition_times[-1], log_times[-1] - lag_max_s)
        margin = max(period, 0.05 * (overlap_end - overlap_start))
        window_s = (overlap_start + margin, overlap_end - margin)
    if not window_s[0] < window_s[1]:
        raise ValueError("No valid common window for all candidate offsets")
    selected = (transition_times >= window_s[0]) & (transition_times <= window_s[1])
    query_times = transition_times[selected]
    if len(query_times) < 40:
        raise ValueError("Fixed common window contains fewer than 40 frame transitions")
    if query_times[0] - period + lag_min_s < log_times[0] - 1e-9:
        raise ValueError("Window starts too early for the minimum candidate offset")
    if query_times[-1] + lag_max_s > log_times[-1] + 1e-9:
        raise ValueError("Window ends too late for the maximum candidate offset")
    offsets = np.arange(lag_min_s, lag_max_s + period * 0.5, period)
    if len(offsets) < 3:
        raise ValueError("Offset range has fewer than three candidates")
    visual = gaussian_filter1d(visual_all, 1.0)[selected]
    encoder_rows = []
    for offset in offsets:
        steps = _encoder_step_norm(query_times, period, log_times, angles, float(offset))
        encoder_rows.append(gaussian_filter1d(steps, 1.0))
    encoder = np.stack(encoder_rows)

    def score_at_indices(indices: np.ndarray) -> np.ndarray:
        current_visual = visual[indices]
        return np.asarray([
            0.7 * _winsorized_correlation(current_visual, row[indices])
            + 0.3 * _rank_correlation(current_visual, row[indices])
            for row in encoder
        ])

    scores = score_at_indices(np.arange(len(visual)))
    best_index = int(np.argmax(scores))
    zero_index = int(np.argmin(np.abs(offsets)))
    midpoint = (window_s[0] + window_s[1]) / 2.0
    first_half = np.flatnonzero(query_times <= midpoint)
    second_half = np.flatnonzero(query_times > midpoint)
    halves = []
    for indices in (first_half, second_half):
        partial_scores = score_at_indices(indices)
        peak = int(np.argmax(partial_scores))
        halves.append({
            "window_s": [float(query_times[indices[0]]), float(query_times[indices[-1]])],
            "best_offset_s": float(offsets[peak]),
            "peak_score": float(partial_scores[peak]),
        })

    rng = np.random.default_rng(seed)
    block = min(max(2, block_frames), len(visual))
    bootstrap_peaks = []
    for _ in range(bootstrap_repeats):
        starts = rng.integers(0, len(visual) - block + 1,
                              size=int(np.ceil(len(visual) / block)))
        indices = np.concatenate([np.arange(start, start + block) for start in starts])[:len(visual)]
        bootstrap_peaks.append(float(offsets[int(np.argmax(score_at_indices(indices)))]))
    quantiles = np.quantile(bootstrap_peaks, [0.05, 0.5, 0.95]).tolist() if bootstrap_peaks else None

    return {
        "warning": WARNING,
        "offset_convention": "encoder_log_time = video_time + offset_s",
        "score_definition": "0.7 winsorized Pearson + 0.3 rank correlation of smoothed motion magnitudes",
        "fixed_common_video_window_s": list(window_s),
        "fixed_window_transitions": len(query_times),
        "candidate_step_s": period,
        "best_offset_s": float(offsets[best_index]),
        "best_score": float(scores[best_index]),
        "zero_offset_score": float(scores[zero_index]),
        "best_at_scan_boundary": best_index in (0, len(offsets) - 1),
        "half_window_peaks": halves,
        "block_bootstrap_peak_quantiles_5_50_95_s": quantiles,
        "bootstrap_warning": "Peak-stability interval only; not a calibrated sync confidence interval",
        "candidates": [
            {"offset_s": float(offset), "score": float(score)}
            for offset, score in zip(offsets, scores)
        ],
    }


def interpolate_frame_labels(frame_count: int, fps: float,
                             log_times: np.ndarray, angles: np.ndarray,
                             offset_s: float) -> pd.DataFrame:
    """Return only frames whose entire query time lies inside the encoder log."""
    if frame_count <= 0 or not np.isfinite(fps) or fps <= 0:
        raise ValueError("Invalid frame count or FPS")
    frame_times = np.arange(frame_count, dtype=np.float64) / fps
    query = frame_times + offset_s
    valid = (query >= log_times[0] - 1e-9) & (query <= log_times[-1] + 1e-9)
    ids = np.flatnonzero(valid)
    if len(ids) == 0:
        raise ValueError("Offset leaves no video frames covered by the encoder log")
    values = np.column_stack([
        np.interp(query[ids], log_times, angles[:, axis]) for axis in range(angles.shape[1])
    ])
    table = pd.DataFrame(values, columns=[f"joint_{axis}" for axis in range(1, angles.shape[1] + 1)])
    table.insert(0, "log_query_time_s", query[ids])
    table.insert(0, "video_time_s", frame_times[ids])
    table.insert(0, "image", [f"frame_{index:04d}.jpg" for index in ids])
    return table


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--excel", type=Path, required=True)
    parser.add_argument("--time-column", default="Time(s)")
    parser.add_argument("--joints", nargs="+", help="Explicit joint columns; auto-detects axisN/jointN otherwise")
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--labels", type=Path, help="Write provisional frame labels")
    parser.add_argument("--label-offset", type=float,
                        help="Explicit video-to-log offset for --labels; default is scan peak")
    parser.add_argument("--lag-min", type=float, default=-1.5)
    parser.add_argument("--lag-max", type=float, default=1.5)
    parser.add_argument("--window-start", type=float,
                        help="Start of fixed common video window; default is auto common overlap")
    parser.add_argument("--window-end", type=float,
                        help="End of fixed common video window; default is auto common overlap")
    parser.add_argument("--roi", type=float, nargs=4, default=(0.03, 0.08, 0.85, 0.90),
                        metavar=("LEFT", "TOP", "RIGHT", "BOTTOM"),
                        help="Fractional image ROI used for motion; change for other camera layouts")
    parser.add_argument("--bootstrap", type=int, default=200)
    args = parser.parse_args()
    trace = extract_motion_trace(args.video, tuple(args.roi))
    times, angles, joint_names = read_encoder_log(
        args.excel, time_column=args.time_column, joint_columns=args.joints
    )
    if (args.window_start is None) != (args.window_end is None):
        parser.error("Pass both --window-start and --window-end, or neither")
    common_window = None if args.window_start is None else (args.window_start, args.window_end)
    result = scan_offsets(
        trace, times, angles,
        lag_min_s=args.lag_min,
        lag_max_s=args.lag_max,
        window_s=common_window,
        bootstrap_repeats=args.bootstrap,
    )
    result["video"] = str(args.video)
    result["excel"] = str(args.excel)
    result["video_frames"] = trace["frame_count"]
    result["video_fps"] = trace["fps"]
    result["roi_xyxy_fraction"] = trace["roi_xyxy_fraction"]
    result["log_last_time_s"] = float(times[-1])
    result["joint_names"] = joint_names
    result["label_columns"] = [f"joint_{index}" for index in range(1, len(joint_names) + 1)]
    if args.labels:
        chosen = args.label_offset if args.label_offset is not None else result["best_offset_s"]
        labels = interpolate_frame_labels(trace["frame_count"], trace["fps"], times, angles, chosen)
        args.labels.parent.mkdir(parents=True, exist_ok=True)
        labels.to_csv(args.labels, index=False)
        result["provisional_labels"] = {
            "path": str(args.labels),
            "offset_s": float(chosen),
            "valid_frames": len(labels),
            "first_frame": str(labels.iloc[0]["image"]),
            "last_frame": str(labels.iloc[-1]["image"]),
            "warning": WARNING,
        }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "candidates"},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
