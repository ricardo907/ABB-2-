"""Parse one serial arm chain from URDF and compute its forward kinematics.

The module supports independent revolute, continuous and prismatic joints;
fixed joints are included in geometry but omitted from the output vector.
Floating/planar joints, mimic joints on the chosen path and branched actuators
are rejected unless another serial path is explicitly selected and branches
are explicitly allowed. This is a URDF serial-chain adapter, not a parser for
every possible robot mechanism.
"""

from __future__ import annotations

import argparse
import json
import math
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np


SUPPORTED_ACTIVE = {"revolute", "continuous", "prismatic"}
SUPPORTED = SUPPORTED_ACTIVE | {"fixed"}


def _vector(text: str | None, default: Sequence[float], label: str) -> np.ndarray:
    if text is None:
        values = np.asarray(default, dtype=float)
    else:
        try:
            values = np.asarray([float(item) for item in text.split()], dtype=float)
        except ValueError as error:
            raise ValueError(f"{label}: expected three numbers") from error
    if values.shape != (3,) or not np.isfinite(values).all():
        raise ValueError(f"{label}: expected three finite numbers")
    return values


def _rotation_from_rpy(rpy: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = rpy
    sr, cr = math.sin(roll), math.cos(roll)
    sp, cp = math.sin(pitch), math.cos(pitch)
    sy, cy = math.sin(yaw), math.cos(yaw)
    rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=float)
    ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=float)
    rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=float)
    return rz @ ry @ rx


def _rotation_about_axis(axis: np.ndarray, angle: float) -> np.ndarray:
    x, y, z = axis
    skew = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]], dtype=float)
    return np.eye(3) * math.cos(angle) + (1 - math.cos(angle)) * np.outer(axis, axis) + math.sin(angle) * skew


def _transform(rotation: np.ndarray | None = None, translation: np.ndarray | None = None) -> np.ndarray:
    result = np.eye(4, dtype=float)
    if rotation is not None:
        result[:3, :3] = rotation
    if translation is not None:
        result[:3, 3] = translation
    return result


@dataclass(frozen=True)
class UrdfJoint:
    name: str
    kind: str
    parent: str
    child: str
    origin_xyz: np.ndarray
    origin_rpy: np.ndarray
    axis: np.ndarray
    lower: float
    upper: float
    mimic: str | None

    @property
    def active(self) -> bool:
        return self.kind in SUPPORTED_ACTIVE


@dataclass(frozen=True)
class SerialArmSpec:
    robot_name: str
    base_link: str
    tip_link: str
    chain_joints: tuple[UrdfJoint, ...]
    excluded_actuated_joints: tuple[str, ...]

    @property
    def active_joints(self) -> tuple[UrdfJoint, ...]:
        return tuple(joint for joint in self.chain_joints if joint.active)

    @property
    def joint_names(self) -> tuple[str, ...]:
        return tuple(joint.name for joint in self.active_joints)

    @property
    def joint_types(self) -> tuple[str, ...]:
        return tuple(joint.kind for joint in self.active_joints)

    @property
    def joint_limits(self) -> np.ndarray:
        """Shape (N,2); unbounded sides are +/-inf for tracker np.clip."""
        return np.asarray([(joint.lower, joint.upper) for joint in self.active_joints], dtype=float).reshape(-1, 2)

    def forward_kinematics(self, values: Sequence[float] | Mapping[str, float]) -> np.ndarray:
        """Return 4x4 base-to-tip transform; radians for rotations, metres for slides."""
        if isinstance(values, Mapping):
            missing = set(self.joint_names) - set(values)
            extra = set(values) - set(self.joint_names)
            if missing or extra:
                raise ValueError(f"Joint value names differ: missing={sorted(missing)}, extra={sorted(extra)}")
            q = np.asarray([values[name] for name in self.joint_names], dtype=float)
        else:
            q = np.asarray(values, dtype=float)
        if q.shape != (len(self.active_joints),) or not np.isfinite(q).all():
            raise ValueError(f"Expected {len(self.active_joints)} finite joint values")
        result = np.eye(4, dtype=float)
        active_index = 0
        for joint in self.chain_joints:
            result = result @ _transform(
                _rotation_from_rpy(joint.origin_rpy), joint.origin_xyz
            )
            if not joint.active:
                continue
            value = float(q[active_index])
            active_index += 1
            if joint.kind in {"revolute", "continuous"}:
                result = result @ _transform(rotation=_rotation_about_axis(joint.axis, value))
            elif joint.kind == "prismatic":
                result = result @ _transform(translation=joint.axis * value)
        return result

    def limit_violations(self, values: Sequence[float]) -> tuple[str, ...]:
        q = np.asarray(values, dtype=float)
        if q.shape != (len(self.active_joints),) or not np.isfinite(q).all():
            raise ValueError(f"Expected {len(self.active_joints)} finite joint values")
        bounds = self.joint_limits
        return tuple(self.joint_names[index] for index in range(len(q))
                     if q[index] < bounds[index, 0] or q[index] > bounds[index, 1])

    def to_dict(self, values: Sequence[float] | None = None) -> dict:
        bounds = [
            [None if not math.isfinite(float(bound)) else float(bound) for bound in pair]
            for pair in self.joint_limits
        ]
        result = {
            "robot_name": self.robot_name,
            "base_link": self.base_link,
            "tip_link": self.tip_link,
            "joint_count": len(self.active_joints),
            "joint_names": list(self.joint_names),
            "joint_types": list(self.joint_types),
            "joint_limits": bounds,
            "joint_units": ["m" if kind == "prismatic" else "rad" for kind in self.joint_types],
            "chain": [
                {
                    "name": joint.name,
                    "type": joint.kind,
                    "parent": joint.parent,
                    "child": joint.child,
                    "origin_xyz_m": joint.origin_xyz.tolist(),
                    "origin_rpy_rad": joint.origin_rpy.tolist(),
                    "axis": joint.axis.tolist(),
                }
                for joint in self.chain_joints
            ],
            "excluded_actuated_joints": list(self.excluded_actuated_joints),
            "scope": "one selected serial URDF chain; not arbitrary parallel or deformable robots",
        }
        if values is not None:
            result["tip_transform_4x4"] = self.forward_kinematics(values).tolist()
            result["limit_violations"] = list(self.limit_violations(values))
        return result


def _read_joint(element: ET.Element) -> UrdfJoint:
    name = element.get("name")
    kind = element.get("type")
    if not name or not kind:
        raise ValueError("Every URDF joint must have name and type")
    parent_element = element.find("parent")
    child_element = element.find("child")
    parent = parent_element.get("link") if parent_element is not None else None
    child = child_element.get("link") if child_element is not None else None
    if not parent or not child or parent == child:
        raise ValueError(f"Joint {name}: invalid parent/child links")
    origin = element.find("origin")
    xyz = _vector(origin.get("xyz") if origin is not None else None, (0, 0, 0), f"{name} origin xyz")
    rpy = _vector(origin.get("rpy") if origin is not None else None, (0, 0, 0), f"{name} origin rpy")
    axis_element = element.find("axis")
    axis = _vector(axis_element.get("xyz") if axis_element is not None else None,
                   (1, 0, 0), f"{name} axis")
    if kind != "fixed":
        length = np.linalg.norm(axis)
        if length <= 1e-12:
            raise ValueError(f"Joint {name}: motion axis has zero length")
        axis = axis / length
    lower = -math.inf
    upper = math.inf
    limit = element.find("limit")
    if kind in {"revolute", "prismatic"} and limit is not None:
        try:
            if limit.get("lower") is not None:
                lower = float(limit.get("lower"))
            if limit.get("upper") is not None:
                upper = float(limit.get("upper"))
        except ValueError as error:
            raise ValueError(f"Joint {name}: invalid limit") from error
        if math.isnan(lower) or math.isnan(upper) or lower >= upper:
            raise ValueError(f"Joint {name}: lower limit must be below upper limit")
    mimic_element = element.find("mimic")
    mimic = mimic_element.get("joint") if mimic_element is not None else None
    return UrdfJoint(name, kind, parent, child, xyz, rpy, axis, lower, upper, mimic)


def load_serial_chain(
    path: str | Path,
    *,
    base_link: str | None = None,
    tip_link: str | None = None,
    allow_branches: bool = False,
) -> SerialArmSpec:
    """Select a base-to-tip serial path from URDF, rejecting implicit branches."""
    path = Path(path)
    root = ET.parse(path).getroot()
    if root.tag != "robot":
        raise ValueError("URDF root must be <robot>")
    link_names = [link.get("name") for link in root.findall("link")]
    if not link_names or any(not name for name in link_names) or len(set(link_names)) != len(link_names):
        raise ValueError("URDF needs unique, named links")
    link_set = set(link_names)
    joints = [_read_joint(element) for element in root.findall("joint")]
    if len(set(joint.name for joint in joints)) != len(joints):
        raise ValueError("URDF joint names must be unique")
    child_to_joint = {}
    for joint in joints:
        if joint.parent not in link_set or joint.child not in link_set:
            raise ValueError(f"Joint {joint.name}: referenced link is not declared")
        if joint.child in child_to_joint:
            raise ValueError(f"Link {joint.child} has multiple parent joints; not a URDF tree")
        child_to_joint[joint.child] = joint
    roots = link_set - set(child_to_joint)
    if len(roots) != 1:
        raise ValueError(f"Expected one root link, found {sorted(roots)}")
    inferred_root = next(iter(roots))
    for link in link_set:
        cursor = link
        seen = set()
        while cursor in child_to_joint:
            if cursor in seen:
                raise ValueError(f"Cycle detected in URDF links near {cursor}")
            seen.add(cursor)
            cursor = child_to_joint[cursor].parent
        if cursor != inferred_root:
            raise ValueError(f"Link {link} is disconnected from root {inferred_root}")
    if base_link is None:
        base_link = inferred_root
    if base_link not in link_set:
        raise ValueError(f"Unknown base link: {base_link}")
    if tip_link is None:
        parent_links = {joint.parent for joint in joints}
        leaves = sorted(link_set - parent_links)
        if len(leaves) != 1:
            raise ValueError(f"Multiple tips {leaves}; specify tip_link explicitly")
        tip_link = leaves[0]
    if tip_link not in link_set:
        raise ValueError(f"Unknown tip link: {tip_link}")

    selected = []
    cursor = tip_link
    visited = set()
    while cursor != base_link:
        if cursor in visited:
            raise ValueError("Cycle detected in URDF links")
        visited.add(cursor)
        joint = child_to_joint.get(cursor)
        if joint is None:
            raise ValueError(f"Base link {base_link} is not an ancestor of tip {tip_link}")
        selected.append(joint)
        cursor = joint.parent
    selected.reverse()
    if not selected:
        raise ValueError("Selected base and tip are identical; no arm chain")
    unsupported = [joint.name for joint in selected if joint.kind not in SUPPORTED]
    if unsupported:
        raise ValueError(f"Unsupported joint types on selected chain: {unsupported}")
    mimics = [joint.name for joint in selected if joint.mimic is not None]
    if mimics:
        raise ValueError(f"Mimic joints on selected chain are not independent DOF: {mimics}")
    selected_names = {joint.name for joint in selected}
    outside_actuated = tuple(joint.name for joint in joints
                             if joint.name not in selected_names and joint.kind != "fixed")
    if outside_actuated and not allow_branches:
        raise ValueError(f"Branched actuators outside selected chain {outside_actuated}; "
                         "choose a tip and pass allow_branches=True to exclude them explicitly")
    if not any(joint.active for joint in selected):
        raise ValueError("Selected chain has no independent actuated joints")
    return SerialArmSpec(root.get("name", path.stem), base_link, tip_link,
                         tuple(selected), outside_actuated)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("urdf", type=Path)
    parser.add_argument("--base", dest="base_link")
    parser.add_argument("--tip", dest="tip_link")
    parser.add_argument("--allow-branches", action="store_true")
    parser.add_argument("--angles", nargs="+", type=float,
                        help="One value per independent joint, in chain order")
    args = parser.parse_args()
    spec = load_serial_chain(args.urdf, base_link=args.base_link, tip_link=args.tip_link,
                             allow_branches=args.allow_branches)
    values = args.angles if args.angles is not None else [0.0] * len(spec.joint_names)
    print(json.dumps(spec.to_dict(values), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
