"""Small analytic URDF checks for joint order, FK, limits and branch rejection."""

from __future__ import annotations

import json
import math
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from urdf_chain import load_serial_chain


URDF = """<robot name="sample_arm">
  <link name="base"/><link name="l1"/><link name="l2"/>
  <link name="l3"/><link name="tip"/>
  <joint name="joint1" type="revolute">
    <parent link="base"/><child link="l1"/>
    <axis xyz="0 0 1"/><limit lower="-3.14" upper="3.14"/>
  </joint>
  <joint name="mount" type="fixed">
    <parent link="l1"/><child link="l2"/><origin xyz="1 0 0"/>
  </joint>
  <joint name="joint2" type="prismatic">
    <parent link="l2"/><child link="l3"/>
    <axis xyz="1 0 0"/><limit lower="0" upper="0.5"/>
  </joint>
  <joint name="joint3" type="continuous">
    <parent link="l3"/><child link="tip"/><axis xyz="0 0 1"/>
  </joint>
</robot>"""


def expect_rejected(path: Path, phrase: str, **kwargs) -> None:
    try:
        load_serial_chain(path, **kwargs)
    except ValueError as error:
        if phrase not in str(error):
            raise AssertionError(f"Expected {phrase!r} in error: {error}") from error
    else:
        raise AssertionError(f"Expected rejection containing {phrase!r}")


def main() -> None:
    with TemporaryDirectory(prefix="robot_spec_check_") as folder:
        path = Path(folder) / "arm.urdf"
        path.write_text(URDF, encoding="utf-8")
        spec = load_serial_chain(path)
        assert spec.joint_names == ("joint1", "joint2", "joint3")
        assert spec.joint_types == ("revolute", "prismatic", "continuous")
        np.testing.assert_allclose(spec.joint_limits[:2], [[-3.14, 3.14], [0, 0.5]])
        assert np.isneginf(spec.joint_limits[2, 0])
        assert np.isposinf(spec.joint_limits[2, 1])
        pose = spec.forward_kinematics([math.pi / 2, 0.2, math.pi / 4])
        np.testing.assert_allclose(pose[:3, 3], [0, 1.2, 0], atol=1e-9)
        angle = 3 * math.pi / 4
        expected_rotation = [[math.cos(angle), -math.sin(angle), 0],
                             [math.sin(angle), math.cos(angle), 0], [0, 0, 1]]
        np.testing.assert_allclose(pose[:3, :3], expected_rotation, atol=1e-9)
        assert spec.limit_violations([0, 0.6, 0]) == ("joint2",)
        json.dumps(spec.to_dict([0, 0.2, 0]))  # no nonstandard Infinity values

        branch = URDF.replace('<link name="base"/>', '<link name="side"/><link name="base"/>')
        branch = branch.replace('</robot>',
                                '<joint name="gripper" type="revolute">'
                                '<parent link="l1"/><child link="side"/>'
                                '<axis xyz="0 1 0"/></joint></robot>')
        path.write_text(branch, encoding="utf-8")
        expect_rejected(path, "Multiple tips")
        expect_rejected(path, "Branched actuators", tip_link="tip")
        selected = load_serial_chain(path, tip_link="tip", allow_branches=True)
        assert selected.excluded_actuated_joints == ("gripper",)

        mimic = URDF.replace('<joint name="joint3" type="continuous">',
                             '<joint name="joint3" type="continuous"><mimic joint="joint1"/>')
        path.write_text(mimic, encoding="utf-8")
        expect_rejected(path, "Mimic joints")

        unsupported = URDF.replace('name="joint3" type="continuous"',
                                   'name="joint3" type="planar"')
        path.write_text(unsupported, encoding="utf-8")
        expect_rejected(path, "Unsupported joint types")

        links = ''.join(f'<link name="q{i}"/>' for i in range(8))
        joints = ''.join(
            f'<joint name="a{i}" type="revolute"><parent link="q{i}"/>'
            f'<child link="q{i+1}"/><axis xyz="0 0 1"/></joint>'
            for i in range(7)
        )
        path.write_text(f'<robot name="seven">{links}{joints}</robot>', encoding="utf-8")
        seven = load_serial_chain(path)
        assert len(seven.joint_names) == 7
        np.testing.assert_allclose(seven.forward_kinematics(np.zeros(7)), np.eye(4))

    print("URDF serial-chain self-check passed: 3/7 DOF, FK, limits, branches, mimic, unsupported types")


if __name__ == "__main__":
    main()
