"""Offline, exploratory angle prediction for the two supplied ABB recordings.

The source CSV labels have an unverified video/log time offset. Predictions are
therefore research diagnostics, not calibrated joint measurements or commands.
Registration uses unlabeled frames from the complete target recording.

Example (from ABB_Cup_2):
    python research/predict_registered.py --train Exp001 --target Exp002
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

from compare_two_videos import ROI, SEQUENCES, register_medians, temporal_median


AXES = [f"axis{i}" for i in range(1, 7)]
LABEL_FILES = {"Exp001": "train_labels.csv", "Exp002": "test_labels.csv"}
ALPHA = 100.0
Z_LIMIT = 5.0


def read_frames(name: str) -> tuple[list[str], np.ndarray]:
    folder = SEQUENCES[name] / "frames"
    files = sorted(folder.glob("frame_*.jpg"))
    expected = [f"frame_{i:04d}.jpg" for i in range(len(files))]
    if not files or [file.name for file in files] != expected:
        raise ValueError(f"{name}: frames are missing or not consecutively numbered")
    images = []
    for file in files:
        frame = cv2.imread(str(file), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise OSError(f"Cannot decode {file}")
        images.append(frame)
    return expected, np.stack(images)


def gray32(frames: np.ndarray) -> np.ndarray:
    left, top, right, bottom = ROI
    features = []
    for frame in frames:
        crop = frame[top:bottom, left:right]
        if crop.size == 0:
            raise ValueError("Registration left no image inside the fixed ROI")
        small = cv2.resize(crop, (32, 32), interpolation=cv2.INTER_AREA)
        features.append(small.reshape(-1).astype(np.float64) / 255.0)
    return np.stack(features)


def to_exp001_canvas(name: str, frames: np.ndarray, exp001_frames: np.ndarray):
    """Use the same canonical canvas in both train/test directions."""
    if name == "Exp001":
        return frames, {"mode": "identity"}
    matrix, matches, inliers = register_medians(
        temporal_median(exp001_frames), temporal_median(frames)
    )
    inlier_fraction = inliers / matches
    if inliers < 30 or inlier_fraction < 0.5:
        raise RuntimeError(
            f"Background registration is unreliable: {inliers}/{matches} ORB matches"
        )
    height, width = exp001_frames.shape[1:]
    aligned = np.stack([
        cv2.warpAffine(frame, matrix, (width, height), flags=cv2.INTER_LINEAR)
        for frame in frames
    ])
    metadata = {
        "mode": "ORB + RANSAC to Exp001 complete-video median background",
        "affine_to_exp001": matrix.tolist(),
        "orb_matches": matches,
        "ransac_inliers": inliers,
        "inlier_fraction": inlier_fraction,
    }
    return aligned, metadata


def fit_predict(train_name: str, target_name: str):
    train_names, original_train_frames = read_frames(train_name)
    target_names, original_target_frames = read_frames(target_name)
    exp001_frames = (
        original_train_frames if train_name == "Exp001" else original_target_frames
    )
    train_frames, train_registration = to_exp001_canvas(
        train_name, original_train_frames, exp001_frames
    )
    target_frames, target_registration = to_exp001_canvas(
        target_name, original_target_frames, exp001_frames
    )
    labels = pd.read_csv(SEQUENCES[train_name] / LABEL_FILES[train_name])
    if list(labels["image"]) != train_names:
        raise ValueError(f"{train_name}: labels and frames do not match")
    y_train = labels[AXES].to_numpy(dtype=np.float64)
    if not np.isfinite(y_train).all():
        raise ValueError("Nonfinite training labels")

    scaler = StandardScaler().fit(gray32(train_frames))
    x_train = np.clip(scaler.transform(gray32(train_frames)), -Z_LIMIT, Z_LIMIT)
    x_target = np.clip(scaler.transform(gray32(target_frames)), -Z_LIMIT, Z_LIMIT)
    model = Ridge(alpha=ALPHA).fit(x_train, y_train)
    raw = model.predict(x_target)
    lower = y_train.min(axis=0)
    upper = y_train.max(axis=0)
    clipped = (raw < lower) | (raw > upper)
    prediction = np.clip(raw, lower, upper)
    return target_names, prediction, clipped, {
        "train": train_name,
        "target": target_name,
        "train_frames": len(train_frames),
        "target_frames": len(target_frames),
        "registration": {"train": train_registration, "target": target_registration},
        "feature": "gray32 fixed ROI",
        "ridge_alpha": ALPHA,
        "standardized_input_limit": Z_LIMIT,
        "train_angle_min_rad": lower.tolist(),
        "train_angle_max_rad": upper.tolist(),
        "fraction_predictions_clipped_by_axis": clipped.mean(axis=0).tolist(),
        "limitation": "Training labels have unverified time alignment; train-range clipping cannot recover unseen angles.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train", choices=sorted(SEQUENCES), default="Exp001")
    parser.add_argument("--target", choices=sorted(SEQUENCES), default="Exp002")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    if args.train == args.target:
        raise ValueError("Choose two different recordings; fitting and predicting the same video is misleading")
    names, predictions, clipped, metadata = fit_predict(args.train, args.target)
    output = args.output or Path(__file__).resolve().parent / (
        f"predictions_{args.train}_to_{args.target}_provisional.csv"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame({"image": names})
    for index, axis in enumerate(AXES):
        table[f"predicted_{axis}_rad"] = predictions[:, index]
        table[f"clipped_{axis}"] = clipped[:, index]
    table.to_csv(output, index=False)
    metadata_path = output.with_suffix(".metadata.json")
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"predictions": str(output), "metadata": str(metadata_path),
                      **metadata}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
