"""Prespecified label-time-offset sensitivity analysis on two ABB videos.

This is an exploratory analysis, not a correction to ground-truth labels.
Only raw video frames and original Excel logs are read. Both label variants use
linear interpolation with no time extrapolation. Model/ROI/preprocessing are
fixed from compare_two_videos.py before running this script.

Run: ``python -B research/offset_sensitivity.py`` from the project root.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

from compare_two_videos import CANVAS, ROI, SEQUENCES, register_medians, temporal_median


OFFSETS_SECONDS = {"Exp001": 1.0, "Exp002": 1.333}
AXIS_COLUMNS = [f"position(rad)_axis_{i}" for i in range(1, 7)]
MAX_FRAME_INDEX = {"Exp001": 201, "Exp002": 196}
ALPHA = 100.0
Z_LIMIT = 5.0
OUT = Path(__file__).resolve().parent


def read_raw(name: str):
    folder = SEQUENCES[name]
    video_path = next(folder.glob("*.mp4"))
    excel_path = next(folder.glob("*.xlsx"))
    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise OSError(f"Cannot open {video_path}")
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    capture.release()
    if not np.isfinite(fps) or fps <= 0:
        raise ValueError(f"Invalid {name} video FPS: {fps}")

    files = sorted((folder / "frames").glob("frame_*.jpg"))
    count = MAX_FRAME_INDEX[name] + 1
    if len(files) < count:
        raise ValueError(f"{name}: need at least {count} image frames")
    expected = [f"frame_{i:04d}.jpg" for i in range(count)]
    if [f.name for f in files[:count]] != expected:
        raise ValueError(f"{name}: nonconsecutive frame sequence")
    frames = []
    for file in files[:count]:
        frame = cv2.imread(str(file), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise OSError(f"Cannot decode {file}")
        frames.append(frame)
    frames = np.stack(frames)

    sheet = pd.read_excel(excel_path)
    fields = ["Time(s)", *AXIS_COLUMNS]
    numeric = sheet[fields].apply(pd.to_numeric, errors="raise")
    if not np.isfinite(numeric.to_numpy(dtype=np.float64)).all():
        raise ValueError(f"{name}: Excel log has nonfinite values")
    log_time = numeric["Time(s)"].to_numpy(dtype=np.float64)
    if np.any(np.diff(log_time) <= 0):
        raise ValueError(f"{name}: Excel timestamps are not strictly increasing")
    frame_time = np.arange(count, dtype=np.float64) / fps
    shifted_time = frame_time + OFFSETS_SECONDS[name]
    if frame_time[0] < log_time[0] or shifted_time[-1] > log_time[-1]:
        raise ValueError(f"{name}: offset goes beyond Excel log time range")

    angles = numeric[AXIS_COLUMNS].to_numpy(dtype=np.float64)
    labels = {}
    for label_name, times in (("original_t", frame_time),
                              ("prespecified_shift", shifted_time)):
        labels[label_name] = np.column_stack([
            np.interp(times, log_time, angles[:, axis]) for axis in range(6)
        ])
    return frames, labels, {"fps": fps, "valid_frames": count,
                            "last_frame_index": count - 1,
                            "last_video_time_s": float(frame_time[-1]),
                            "offset_s": OFFSETS_SECONDS[name],
                            "last_query_time_s": float(shifted_time[-1]),
                            "excel_last_time_s": float(log_time[-1])}


def gray32_features(frames: np.ndarray):
    left, top, right, bottom = ROI
    rows = []
    for frame in frames:
        crop = frame[top:bottom, left:right]
        small = cv2.resize(crop, (32, 32), interpolation=cv2.INTER_AREA)
        rows.append((small.reshape(-1) / 255.0).astype(np.float32))
    return np.stack(rows)


def evaluate(source, target, x, labels, variant):
    y_train = labels[source][variant]
    y_test = labels[target][variant]
    scaler = StandardScaler()
    train = np.clip(scaler.fit_transform(x[source]), -Z_LIMIT, Z_LIMIT)
    test = np.clip(scaler.transform(x[target]), -Z_LIMIT, Z_LIMIT)
    model = Ridge(alpha=ALPHA).fit(train, y_train)
    prediction = np.clip(model.predict(test), y_train.min(axis=0), y_train.max(axis=0))
    baseline_prediction = np.broadcast_to(y_train.mean(axis=0), y_test.shape)
    errors = np.abs(prediction - y_test).mean(axis=0)
    baseline_errors = np.abs(baseline_prediction - y_test).mean(axis=0)
    return {"source": source, "target": target, "label_variant": variant,
            "model_per_axis_mae_rad": errors.tolist(),
            "model_mean_mae_rad": float(errors.mean()),
            "train_mean_per_axis_mae_rad": baseline_errors.tolist(),
            "train_mean_mae_rad": float(baseline_errors.mean())}


def main():
    started = time.perf_counter()
    frames, labels, metadata = {}, {}, {}
    for name in SEQUENCES:
        frames[name], labels[name], metadata[name] = read_raw(name)
    matrix, matches, inliers = register_medians(
        temporal_median(frames["Exp001"]), temporal_median(frames["Exp002"])
    )
    aligned = {"Exp001": frames["Exp001"], "Exp002": np.stack([
        cv2.warpAffine(frame, matrix, CANVAS, flags=cv2.INTER_LINEAR)
        for frame in frames["Exp002"]
    ])}
    x = {name: gray32_features(value) for name, value in aligned.items()}
    results = [evaluate(source, target, x, labels, variant)
               for variant in ("original_t", "prespecified_shift")
               for source, target in (("Exp001", "Exp002"), ("Exp002", "Exp001"))]
    report = {
        "status": "EXPLORATORY OFFSET SENSITIVITY; offsets inferred from motion, not verified truth",
        "fixed_model": {"input": "ORB registered gray32 within fixed ROI",
                        "roi_xyxy": list(ROI), "ridge_alpha": ALPHA,
                        "standardized_input_z_clip": Z_LIMIT,
                        "output_clip": "per-axis source train min/max",
                        "no_hyperparameter_tuning": True},
        "label_source": "original Excel logs, linear interpolation at frame time + offset",
        "metadata": metadata,
        "registration": {"exp002_to_exp001_affine_matrix": matrix.tolist(),
                         "good_matches": matches, "ransac_inliers": inliers,
                         "unlabeled_frames_from_both_videos": True},
        "results": results,
        "elapsed_seconds": time.perf_counter() - started,
    }
    path = OUT / "offset_sensitivity_results.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": report["status"], "metadata": metadata,
                      "registration": report["registration"], "results": results,
                      "elapsed_seconds": report["elapsed_seconds"]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
