"""Exploratory camera-shift augmentation with a pretrained pose regressor.

Exp001 tail selects the epoch. Exp002 has already been inspected, so its result
is a development diagnostic, not an independent test or publication score.
"""

from __future__ import annotations

import copy
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageOps
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from torchvision.models import ResNet18_Weights, resnet18


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
AXES = [f"axis{i}" for i in range(1, 7)]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH = 16
MAX_EPOCHS = 25
PATIENCE = 7


class Frames(Dataset):
    def __init__(self, table: pd.DataFrame, frame_dir: Path, center, scale, augment: bool):
        self.table = table.reset_index(drop=True)
        self.frame_dir = frame_dir
        self.center = np.asarray(center, dtype=np.float32)
        self.scale = np.asarray(scale, dtype=np.float32)
        steps = []
        if augment:
            steps += [
                transforms.RandomAffine(
                    degrees=0,
                    translate=(0.14, 0.12),
                    scale=(0.72, 1.28),
                    fill=(128, 128, 128),
                ),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.15),
            ]
        steps += [
            transforms.ToTensor(),
            transforms.Normalize(mean=ResNet18_Weights.DEFAULT.transforms().mean,
                                 std=ResNet18_Weights.DEFAULT.transforms().std),
        ]
        self.transform = transforms.Compose(steps)

    def __len__(self):
        return len(self.table)

    def __getitem__(self, index):
        row = self.table.iloc[index]
        with Image.open(self.frame_dir / str(row["image"])) as source:
            image = ImageOps.pad(source.convert("RGB"), (224, 224), method=Image.Resampling.BILINEAR,
                                 color=(128, 128, 128))
        angles = row[AXES].to_numpy(dtype=np.float32)
        return self.transform(image), torch.from_numpy((angles - self.center) / self.scale)


def build_model():
    model = resnet18(weights=ResNet18_Weights.DEFAULT)
    for layer in (model.conv1, model.bn1, model.layer1, model.layer2):
        for parameter in layer.parameters():
            parameter.requires_grad_(False)
    model.fc = nn.Linear(model.fc.in_features, 6)
    nn.init.zeros_(model.fc.weight)
    nn.init.zeros_(model.fc.bias)
    return model.to(DEVICE)


def train_epoch(model, loader, optimizer):
    model.train()
    model.bn1.eval()
    model.layer1.eval()
    model.layer2.eval()
    loss_sum = 0.0
    for images, target in loader:
        images = images.to(DEVICE)
        target = target.to(DEVICE)
        optimizer.zero_grad(set_to_none=True)
        loss = nn.functional.smooth_l1_loss(model(images), target)
        loss.backward()
        optimizer.step()
        loss_sum += float(loss.item()) * len(images)
    return loss_sum / len(loader.dataset)


def fit(table, frame_dir, center, scale, epochs, validation=None):
    torch.manual_seed(42)
    model = build_model()
    optimizer = torch.optim.AdamW([
        {"params": model.layer3.parameters(), "lr": 0.00005},
        {"params": model.layer4.parameters(), "lr": 0.00005},
        {"params": model.fc.parameters(), "lr": 0.0005},
    ], weight_decay=0.0001)
    loader = DataLoader(Frames(table, frame_dir, center, scale, True),
                        batch_size=BATCH, shuffle=True, num_workers=0)
    best_mae = math.inf
    best_epoch = 0
    best_state = None
    stale = 0
    history = []
    for epoch in range(1, epochs + 1):
        train_loss = train_epoch(model, loader, optimizer)
        record = {"epoch": epoch, "train_huber_normalized": train_loss}
        if validation is not None:
            pred = predict(model, validation[0], validation[1], center, scale)
            truth = validation[0][AXES].to_numpy(dtype=np.float64)
            val_mae = float(np.abs(pred - truth).mean())
            record["validation_mae_rad"] = val_mae
            if val_mae < best_mae:
                best_mae = val_mae
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
                stale = 0
            else:
                stale += 1
        history.append(record)
        print(record, flush=True)
        if validation is not None and stale >= PATIENCE:
            break
    if validation is not None:
        model.load_state_dict(best_state)
    return model, best_epoch, history


def predict(model, table, frame_dir, center, scale):
    loader = DataLoader(Frames(table, frame_dir, center, scale, False),
                        batch_size=BATCH, shuffle=False, num_workers=0)
    model.eval()
    pieces = []
    with torch.inference_mode():
        for images, _ in loader:
            pieces.append(model(images.to(DEVICE)).cpu().numpy())
    return np.concatenate(pieces, axis=0) * scale + center


def main():
    train_dir = PROJECT / "data/train/Exp001"
    test_dir = PROJECT / "data2/test/Exp002"
    train = pd.read_csv(train_dir / "train_labels.csv")
    test = pd.read_csv(test_dir / "test_labels.csv")
    fit_table = train.iloc[:150]
    val_table = train.iloc[161:]
    center = fit_table[AXES].mean().to_numpy(dtype=np.float32)
    scale = np.maximum(fit_table[AXES].std().to_numpy(dtype=np.float32), 0.2)
    model, selected_epoch, history = fit(
        fit_table, train_dir / "frames", center, scale, MAX_EPOCHS,
        validation=(val_table, train_dir / "frames"),
    )
    val_pred = predict(model, val_table, train_dir / "frames", center, scale)
    val_truth = val_table[AXES].to_numpy(dtype=np.float64)
    full_center = train[AXES].mean().to_numpy(dtype=np.float32)
    full_scale = np.maximum(train[AXES].std().to_numpy(dtype=np.float32), 0.2)
    full_model, _, full_history = fit(
        train, train_dir / "frames", full_center, full_scale, selected_epoch
    )
    torch.save(full_model.state_dict(), HERE / "resnet18_augmented_full_exp001.pth")
    test_pred = predict(full_model, test, test_dir / "frames", full_center, full_scale)
    test_truth = test[AXES].to_numpy(dtype=np.float64)
    def measure(truth, pred):
        absolute = np.abs(truth - pred)
        return {"mae_rad": float(absolute.mean()),
                "per_axis_mae_rad": absolute.mean(axis=0).tolist(),
                "per_axis_p95_rad": np.percentile(absolute, 95, axis=0).tolist()}
    result = {
        "note": "Exploratory development result; Exp002 had already been inspected",
        "train_frames": 150,
        "gap_frames": 11,
        "validation_frames": 41,
        "selected_epoch": selected_epoch,
        "validation": measure(val_truth, val_pred),
        "exp002": measure(test_truth, test_pred),
        "exp002_train_mean_baseline": measure(test_truth, np.broadcast_to(full_center, test_truth.shape)),
        "selection_history": history,
        "full_fit_history": full_history,
    }
    (HERE / "resnet18_augmented_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if "history" not in key}, indent=2))


if __name__ == "__main__":
    main()
