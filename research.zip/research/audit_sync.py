"""Read-only diagnostic of video/encoder timing; no labels are modified."""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d
from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
AXES = [f"position(rad)_axis_{i}" for i in range(1, 7)]
CASES = {
    "Exp001": (ROOT / "data/train/Exp001/Train_Angle1_real.mp4", ROOT / "data/train/Exp001/Train_Angle1_real.xlsx"),
    "Exp002": (ROOT / "data2/test/Exp002/Test_Angle2_real.mp4", ROOT / "data2/test/Exp002/Test_Angle2_real.xlsx"),
}


def video_motion(path: Path):
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise OSError(path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    dims = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
    previous = None
    motion = []
    count = 0
    try:
        while True:
            okay, frame = cap.read()
            if not okay:
                break
            count += 1
            h, w = frame.shape[:2]
            crop = frame[int(h * .08):int(h * .90), int(w * .03):int(w * .85)]
            gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(gray, (128, 128), interpolation=cv2.INTER_AREA).astype(np.float32)
            if previous is not None:
                delta = np.abs(gray - previous)
                motion.append(float(np.mean(np.maximum(delta - 2, 0))))
            previous = gray
    finally:
        cap.release()
    return fps, dims, count, np.asarray(motion)


def angle_speed(log_times, angles, camera_times, offset):
    sample_times = camera_times + offset
    good = (sample_times[0] >= log_times[0]) and (sample_times[-1] <= log_times[-1])
    if not good:
        return None
    sampled = np.column_stack([np.interp(sample_times, log_times, angles[:, j]) for j in range(6)])
    return np.linalg.norm(np.diff(sampled, axis=0), axis=1)


def analyze(video_path, log_path):
    log = pd.read_excel(log_path)
    times = log["Time(s)"].to_numpy(float)
    angles = log[AXES].to_numpy(float)
    fps, dims, count, motion = video_motion(video_path)
    camera_times = np.arange(count) / fps
    # A single lag from generic image motion and joint speed is only diagnostic.
    candidates = []
    for lag in np.arange(0, 1.51, 1 / fps):
        speed = angle_speed(times - times[0], angles, camera_times, lag)
        if speed is None:
            continue
        visual = gaussian_filter1d(motion, 1.0)
        encoder = gaussian_filter1d(speed, 1.0)
        pearson = np.corrcoef(visual, encoder)[0, 1]
        rank = spearmanr(visual, encoder).statistic
        candidates.append((float(lag), float(pearson), float(rank)))
    best = max(candidates, key=lambda row: row[1]) if candidates else None
    zero = candidates[0] if candidates else None
    # Motion onset uses a deliberately simple fixed signal criterion, not a fit.
    motion_scale = np.percentile(motion, [10, 50, 90, 99]).tolist()
    angle0 = angle_speed(times - times[0], angles, camera_times, 0.0)
    summary = {
        "video": str(video_path), "excel": str(log_path),
        "fps": fps, "size": dims, "decoded_frames": count,
        "first_frame_time_s": 0.0, "last_frame_time_s": float(camera_times[-1]),
        "nominal_video_duration_s": float(count / fps),
        "excel_rows": len(log), "excel_first_time_s": float(times[0]),
        "excel_last_time_s": float(times[-1]),
        "excel_duration_s": float(times[-1] - times[0]),
        "excel_dt_median_s": float(np.median(np.diff(times))),
        "excel_dt_min_s": float(np.min(np.diff(times))),
        "excel_dt_max_s": float(np.max(np.diff(times))),
        "log_minus_video_duration_s": float(times[-1] - times[0] - count / fps),
        "motion_quantiles_10_50_90_99": motion_scale,
        "zero_lag_motion_speed_correlations": zero,
        "best_lag_motion_speed_correlations": best,
        "first_10_visual_motion": motion[:10].tolist(),
        "first_10_joint_displacement": angle0[:10].tolist() if angle0 is not None else None,
    }
    return summary, pd.DataFrame({"frame_transition": np.arange(1, count),
                                  "image_motion": motion,
                                  "joint_displacement_zero_lag": angle0})


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    all_results = {}
    for name, (video, excel) in CASES.items():
        report, trace = analyze(video, excel)
        all_results[name] = report
        trace.to_csv(OUT / f"{name}_motion_trace.csv", index=False)
    (OUT / "sync_diagnostic.json").write_text(json.dumps(all_results, indent=2), encoding="utf-8")
    print(json.dumps(all_results, indent=2))


if __name__ == "__main__":
    main()
