"""Exploratory two-sequence experiment; both folds are development data.

Uses only Exp001/Exp002 frames and their provisional CSV labels. Image registration
and median backgrounds use *unlabeled* frames from both videos (offline,
transductive). No legacy prediction files, model outputs, or old results are
read. Run with ``python -B research/compare_two_videos.py`` from the project root.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from skimage.feature import hog
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[1]
SEQUENCES = {
    "Exp001": ROOT / "data" / "train" / "Exp001",
    "Exp002": ROOT / "data2" / "test" / "Exp002",
}
LABEL_FILES = {"Exp001": "train_labels.csv", "Exp002": "test_labels.csv"}
AXES = [f"axis{i}" for i in range(1, 7)]
OUT = Path(__file__).resolve().parent
CANVAS = (640, 640)
# The common field of view after background registration. Robot base remains
# visible and static table / overlaid timer occupy less of this rectangle.
ROI = (20, 30, 600, 560)  # left, top, right, bottom


def load_sequence(name: str):
    folder = SEQUENCES[name]
    labels = pd.read_csv(folder / LABEL_FILES[name])
    required = ["image", *AXES]
    if not all(col in labels for col in required):
        raise ValueError(f"{name}: labels must have {required}")
    ids = labels["image"].str.extract(r"frame_(\d+)\.jpg$", expand=False)
    if ids.isna().any():
        raise ValueError(f"{name}: malformed frame name")
    labels = labels.assign(_frame=ids.astype(int)).sort_values("_frame")
    if labels["_frame"].tolist() != list(range(len(labels))):
        raise ValueError(f"{name}: missing or duplicated frame")
    frames = []
    for filename in labels["image"]:
        image = cv2.imread(str(folder / "frames" / filename), cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise OSError(f"{name}: cannot decode {filename}")
        frames.append(image)
    return np.stack(frames), labels[AXES].to_numpy(dtype=np.float64)


def temporal_median(frames: np.ndarray) -> np.ndarray:
    return np.median(frames, axis=0).astype(np.uint8)


def register_medians(reference: np.ndarray, moving: np.ndarray):
    orb = cv2.ORB_create(nfeatures=4000)
    kp_ref, desc_ref = orb.detectAndCompute(reference, None)
    kp_mov, desc_mov = orb.detectAndCompute(moving, None)
    if desc_ref is None or desc_mov is None:
        raise RuntimeError("Insufficient features for video background registration")
    pairs = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(desc_mov, desc_ref, k=2)
    good = [a for a, b in pairs if a.distance < 0.75 * b.distance]
    if len(good) < 15:
        raise RuntimeError(f"Only {len(good)} background matches")
    source = np.float32([kp_mov[m.queryIdx].pt for m in good])
    target = np.float32([kp_ref[m.trainIdx].pt for m in good])
    matrix, inliers = cv2.estimateAffinePartial2D(
        source, target, method=cv2.RANSAC, ransacReprojThreshold=3.0
    )
    if matrix is None or int(inliers.sum()) < 15:
        raise RuntimeError("Video background affine registration failed")
    return matrix, len(good), int(inliers.sum())


def extract_features(frames: np.ndarray):
    left, top, right, bottom = ROI
    median = temporal_median(frames)
    rows = {kind: [] for kind in ("gray32", "hog",
                                   "median_diff32", "median_diff_hog", "shape")}
    kernel = np.ones((3, 3), dtype=np.uint8)
    for frame in frames:
        image = frame[top:bottom, left:right]
        difference = cv2.absdiff(frame, median)[top:bottom, left:right]
        mask = np.uint8(difference >= 22) * 255
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        gray32 = cv2.resize(image, (32, 32), interpolation=cv2.INTER_AREA)
        diff32 = cv2.resize(mask, (32, 32), interpolation=cv2.INTER_AREA)
        rows["gray32"].append((gray32.reshape(-1) / 255.0).astype(np.float32))
        rows["median_diff32"].append((diff32.reshape(-1) / 255.0).astype(np.float32))
        for key, source in (("hog", image), ("median_diff_hog", mask)):
            resized = cv2.resize(source, (128, 128), interpolation=cv2.INTER_AREA)
            rows[key].append(hog(resized, orientations=9,
                                 pixels_per_cell=(16, 16), cells_per_block=(2, 2),
                                 block_norm="L2-Hys", feature_vector=True).astype(np.float32))
        # Soft 16x16 occupancy and its horizontal/vertical projections.
        low = cv2.resize(mask, (16, 16), interpolation=cv2.INTER_AREA) / 255.0
        shape = np.r_[low.ravel(), low.mean(axis=0), low.mean(axis=1)]
        rows["shape"].append(shape.astype(np.float32))
    return {kind: np.stack(v) for kind, v in rows.items()}


def per_axis_mae(y: np.ndarray, prediction: np.ndarray):
    return np.abs(y - prediction).mean(axis=0)


def evaluate(source: str, target: str, features, labels):
    x_train = features[source]
    x_test = features[target]
    y_train = labels[source]
    y_test = labels[target]
    train_min, train_max = y_train.min(axis=0), y_train.max(axis=0)
    mean_prediction = np.broadcast_to(y_train.mean(axis=0), y_test.shape)
    oracle_prediction = np.clip(y_test, train_min, train_max)
    baseline = per_axis_mae(y_test, mean_prediction)
    lower_bound = per_axis_mae(y_test, oracle_prediction)
    candidates = []
    for feature in x_train:
        scaler = StandardScaler()
        train = np.clip(scaler.fit_transform(x_train[feature]), -5.0, 5.0)
        test = np.clip(scaler.transform(x_test[feature]), -5.0, 5.0)
        for alpha in (1.0, 100.0, 10000.0):
            started = time.perf_counter()
            model = Ridge(alpha=alpha)
            model.fit(train, y_train)
            prediction = np.clip(model.predict(test), train_min, train_max)
            fit_predict_seconds = time.perf_counter() - started
            errors = per_axis_mae(y_test, prediction)
            candidates.append({
                "feature": feature, "ridge_alpha": alpha,
                "per_axis_mae_rad": errors.tolist(), "mean_mae_rad": float(errors.mean()),
                "fit_predict_seconds": fit_predict_seconds,
            })
    return {
        "source": source, "target": target, "source_frames": len(y_train),
        "target_frames": len(y_test),
        "train_min_rad": train_min.tolist(), "train_max_rad": train_max.tolist(),
        "mean_baseline_per_axis_mae_rad": baseline.tolist(),
        "mean_baseline_mae_rad": float(baseline.mean()),
        "train_range_oracle_per_axis_mae_rad": lower_bound.tolist(),
        "train_range_oracle_mae_rad": float(lower_bound.mean()),
        "target_outside_train_range_fraction_by_axis":
            ((y_test < train_min) | (y_test > train_max)).mean(axis=0).tolist(),
        "candidates": candidates,
    }


def main():
    started = time.perf_counter()
    frames = {}
    labels = {}
    for name in SEQUENCES:
        frames[name], labels[name] = load_sequence(name)
    medians = {name: temporal_median(x) for name, x in frames.items()}
    matrix, matches, inliers = register_medians(medians["Exp001"], medians["Exp002"])
    naive_frames = {"Exp001": frames["Exp001"],
                    "Exp002": np.stack([cv2.resize(frame, CANVAS, interpolation=cv2.INTER_LINEAR)
                                        for frame in frames["Exp002"]])}
    registered_frames = {"Exp001": frames["Exp001"], "Exp002": np.stack([
        cv2.warpAffine(frame, matrix, CANVAS, flags=cv2.INTER_LINEAR)
        for frame in frames["Exp002"]
    ])}
    # Controlled comparison: the same ROI, features, scaler, Ridge, and output
    # clipping are used with naive whole-frame resize and ORB registration.
    feature_start = time.perf_counter()
    features_by_geometry = {
        geometry: {name: extract_features(x) for name, x in frame_sets.items()}
        for geometry, frame_sets in (("naive_resize", naive_frames),
                                     ("orb_registered", registered_frames))
    }
    feature_seconds = time.perf_counter() - feature_start
    comparisons = {}
    for geometry, features in features_by_geometry.items():
        folds = [evaluate("Exp001", "Exp002", features, labels),
                 evaluate("Exp002", "Exp001", features, labels)]
        by_config = {}
        for fold in folds:
            for result in fold["candidates"]:
                config = (result["feature"], result["ridge_alpha"])
                by_config.setdefault(config, []).append(result["mean_mae_rad"])
        ranked = sorted(({"feature": key[0], "ridge_alpha": key[1],
                         "two_fold_mean_mae_rad": float(np.mean(values)),
                         "fold_mae_rad": values}
                        for key, values in by_config.items()),
                        key=lambda row: row["two_fold_mean_mae_rad"])
        comparisons[geometry] = {"folds": folds, "ranked_by_two_fold_mae": ranked}
    report = {
        "status": "EXPLORATORY: both video folds used for comparison; no untouched test set",
        "transductive_processing": "Registration and median background use unlabeled frames of both videos",
        "preprocessing": {"registration": "ORB + RANSAC partial affine on video medians",
                          "exp002_to_exp001_affine_matrix": matrix.tolist(),
                          "orb_good_matches": matches, "ransac_inliers": inliers,
                          "roi_xyxy": list(ROI), "input_standardized_z_clip": 5.0,
                          "prediction_clip": "source sequence per-axis min/max"},
        "feature_seconds": feature_seconds,
        "total_seconds": time.perf_counter() - started,
        "comparisons": comparisons,
    }
    (OUT / "comparison_results.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    compact = {"status": report["status"], "preprocessing": report["preprocessing"],
               "feature_seconds": feature_seconds, "total_seconds": report["total_seconds"],
               "comparisons": {
                   geometry: {"ranked_top_five": value["ranked_by_two_fold_mae"][:5],
                              "folds": [{"source": f["source"], "target": f["target"],
                                         "mean_baseline_mae_rad": f["mean_baseline_mae_rad"],
                                         "train_range_oracle_mae_rad":
                                             f["train_range_oracle_mae_rad"]}
                                        for f in value["folds"]]}
                   for geometry, value in comparisons.items()}}
    print(json.dumps(compact, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
