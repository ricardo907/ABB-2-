"""Read-only visual audit of unlabeled robot-arm videos.

Samples five frames per video and measures frozen ResNet18 cosine distance to
Exp001 frames. No joint-angle labels are read or inferred.
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torch import nn
from torchvision import models, transforms


VIDEOS = Path.home() / "Desktop" / "机械臂"
PROJECT = Path(__file__).resolve().parents[1]
EXP001 = PROJECT / "data" / "train" / "Exp001" / "frames"
EXP002 = PROJECT / "data2" / "test" / "Exp002" / "frames"
WEIGHTS = Path.home() / ".cache/torch/hub/checkpoints/resnet18-f37072fd.pth"
OUT = Path(__file__).parent
FRACTIONS = (0.1, 0.3, 0.5, 0.7, 0.9)


def sorted_frames(directory: Path) -> list[Path]:
    return sorted(directory.glob("frame_*.jpg"), key=lambda p: int(p.stem.split("_")[-1]))


def sample_paths(directory: Path, count: int) -> list[tuple[str, Image.Image]]:
    paths = sorted_frames(directory)
    if len(paths) < count:
        raise ValueError(f"Insufficient frames in {directory}")
    indices = np.linspace(0, len(paths) - 1, count).round().astype(int)
    return [(paths[i].name, Image.open(paths[i]).convert("RGB")) for i in indices]


def sample_video(path: Path) -> tuple[list[tuple[str, Image.Image]], dict]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"Cannot open {path}")
    count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    samples = []
    for fraction in FRACTIONS:
        index = min(count - 1, int(round((count - 1) * fraction)))
        cap.set(cv2.CAP_PROP_POS_FRAMES, index)
        ok, bgr = cap.read()
        if not ok:
            raise ValueError(f"Could not decode {path.name} frame {index}")
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        samples.append((f"frame {index}", Image.fromarray(rgb)))
    cap.release()
    return samples, {"frames": count, "fps": fps, "seconds": count / fps if fps > 0 else None,
                     "resolution": [width, height]}


def embeddings(images: list[Image.Image]) -> np.ndarray:
    if not WEIGHTS.is_file():
        raise FileNotFoundError(f"No local pretrained weights: {WEIGHTS}")
    model = models.resnet18(weights=None)
    model.load_state_dict(torch.load(WEIGHTS, map_location="cpu", weights_only=True), strict=True)
    model.fc = nn.Identity()
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    preprocess = transforms.Compose([
        transforms.Resize((224, 224)), transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
    ])
    chunks = []
    with torch.inference_mode():
        for start in range(0, len(images), 16):
            x = torch.stack([preprocess(image) for image in images[start : start + 16]]).to(device)
            chunks.append(model(x).cpu().numpy())
    vectors = np.concatenate(chunks)
    return vectors / np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-12)


def nearest_cosine_distance(query: np.ndarray, reference: np.ndarray) -> np.ndarray:
    return 1 - np.max(query @ reference.T, axis=1)


def stats(values: np.ndarray) -> dict:
    return {"median": float(np.median(values)), "min": float(np.min(values)),
            "max": float(np.max(values)), "values": values.tolist()}


def contact_sheet(rows: list[tuple[str, list[tuple[str, Image.Image]]]]) -> None:
    cell_w, cell_h, label_h = 256, 160, 27
    canvas = Image.new("RGB", (cell_w * 5, (cell_h + label_h) * len(rows)), "white")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default()
    for row_idx, (label, samples) in enumerate(rows):
        for col, (frame_label, source) in enumerate(samples):
            image = source.copy()
            image.thumbnail((cell_w, cell_h))
            x = col * cell_w + (cell_w - image.width) // 2
            y = row_idx * (cell_h + label_h) + (cell_h - image.height) // 2
            canvas.paste(image, (x, y))
            draw.text((col * cell_w + 3, row_idx * (cell_h + label_h) + cell_h + 3),
                      f"{label} | {frame_label}", fill="black", font=font)
    canvas.save(OUT / "sample_contact_sheet.jpg", quality=85)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    video_paths = sorted(VIDEOS.glob("*.mp4"))
    if not video_paths:
        raise ValueError(f"No MP4 videos found in {VIDEOS}")
    ref001 = sample_paths(EXP001, 25)
    ref002 = sample_paths(EXP002, 25)
    rows = [("Exp001", [ref001[i] for i in (0, 6, 12, 18, 24)]),
            ("Exp002", [ref002[i] for i in (0, 6, 12, 18, 24)])]
    videos = []
    for path in video_paths:
        samples, meta = sample_video(path)
        rows.append((path.stem[:8], samples))
        videos.append((path, samples, meta))
    contact_sheet(rows)

    all_images = [image for _, image in ref001 + ref002]
    all_images.extend(image for _, samples, _ in videos for _, image in samples)
    vectors = embeddings(all_images)
    r001, r002 = vectors[:25], vectors[25:50]
    internal = 1 - r001 @ r001.T
    np.fill_diagonal(internal, np.inf)
    internal_nearest = internal.min(axis=1)
    result = {
        "method": "Frozen local ImageNet ResNet18 pooled 512D features; cosine distance to nearest of 25 evenly sampled Exp001 frames. Lower means more similar. No labels used.",
        "sample_fractions_video": list(FRACTIONS),
        "calibration_exp001_leave_one_out": stats(internal_nearest),
        "exp002_to_exp001": stats(nearest_cosine_distance(r002, r001)),
        "videos": [],
        "contact_sheet": str(OUT / "sample_contact_sheet.jpg"),
        "limitation": "Appearance OOD is not a six-axis prediction error; these MP4 files have no aligned joint-angle ground truth.",
    }
    offset = 50
    for path, samples, meta in videos:
        current = vectors[offset : offset + len(samples)]
        result["videos"].append({"file": path.name, **meta,
                                  "sample_indices": [label for label, _ in samples],
                                  "to_exp001": stats(nearest_cosine_distance(current, r001))})
        offset += len(samples)
    (OUT / "audit_results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    for _, image in ref001 + ref002:
        image.close()
    for _, samples, _ in videos:
        for _, image in samples:
            image.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
