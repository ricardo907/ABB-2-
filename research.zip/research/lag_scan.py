"""Exploratory lag scan; motion energy is not a trustworthy sync marker."""

from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d

from audit_sync import CASES, AXES


OUT = Path(__file__).resolve().parent
summary = {}
for name, (_, excel) in CASES.items():
    trace = pd.read_csv(OUT / f"{name}_motion_trace.csv")
    image = gaussian_filter1d(trace.image_motion.to_numpy(float), 1.0)
    log = pd.read_excel(excel)
    t = log["Time(s)"].to_numpy(float)
    a = log[AXES].to_numpy(float)
    video_t = trace.frame_transition.to_numpy(float) / 24
    best = []
    for axis in range(7):
        records = []
        for lag in np.arange(-1.5, 1.501, 1 / 24):
            before = video_t - 1 / 24 + lag
            after = video_t + lag
            mask = (before >= t[0]) & (after <= t[-1])
            if mask.sum() < 140:
                continue
            delta = np.column_stack([np.interp(after[mask], t, a[:, j]) -
                                     np.interp(before[mask], t, a[:, j]) for j in range(6)])
            speed = np.linalg.norm(delta, axis=1) if axis == 6 else np.abs(delta[:, axis])
            speed = gaussian_filter1d(speed, 1.0)
            corr = np.corrcoef(image[mask], speed)[0, 1]
            records.append({"lag_s": round(float(lag), 4),
                            "corr": round(float(corr), 4), "samples": int(mask.sum())})
        best.append({"axis": "norm" if axis == 6 else str(axis + 1),
                     "best": max(records, key=lambda row: row["corr"]),
                     "zero": min(records, key=lambda row: abs(row["lag_s"]))})
    # Compare all offsets on exactly the same central video transitions.
    common = (video_t >= 1.5) & (video_t <= 7.5)
    common_records = []
    for lag in np.arange(-1.5, 1.501, 1 / 24):
        before = video_t[common] - 1 / 24 + lag
        after = video_t[common] + lag
        if before.min() < t[0] or after.max() > t[-1]:
            continue
        delta = np.column_stack([np.interp(after, t, a[:, j]) -
                                 np.interp(before, t, a[:, j]) for j in range(6)])
        speed = gaussian_filter1d(np.linalg.norm(delta, axis=1), 1.0)
        corr = np.corrcoef(image[common], speed)[0, 1]
        common_records.append({"lag_s": round(float(lag), 4),
                               "corr": round(float(corr), 4), "samples": int(common.sum())})
    subwindows = []
    for lower, upper in ((1.5, 4.5), (4.5, 7.5)):
        window = (video_t >= lower) & (video_t <= upper)
        trials = []
        for lag in np.arange(-1.5, 1.501, 1 / 24):
            before = video_t[window] - 1 / 24 + lag
            after = video_t[window] + lag
            if before.min() < t[0] or after.max() > t[-1]:
                continue
            delta = np.column_stack([np.interp(after, t, a[:, j]) -
                                     np.interp(before, t, a[:, j]) for j in range(6)])
            speed = gaussian_filter1d(np.linalg.norm(delta, axis=1), 1.0)
            trials.append({"lag_s": round(float(lag), 4),
                           "corr": round(float(np.corrcoef(image[window], speed)[0, 1]), 4)})
        subwindows.append({"range_s": [lower, upper],
                           "best": max(trials, key=lambda row: row["corr"]),
                           "zero": min(trials, key=lambda row: abs(row["lag_s"]))})
    summary[name] = {"all_frame_overlap": best,
                     "fixed_central_window": {
                         "best": max(common_records, key=lambda row: row["corr"]),
                         "top5": sorted(common_records, key=lambda row: row["corr"], reverse=True)[:5],
                         "zero": min(common_records, key=lambda row: abs(row["lag_s"])),
                     }, "subwindows": subwindows}
(OUT / "lag_scan.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
